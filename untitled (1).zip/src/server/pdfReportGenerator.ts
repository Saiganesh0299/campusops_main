import PDFDocument from 'pdfkit';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { Response } from 'express';
import { MaintenanceTicket } from '../types/campus';
import { User, UserRole } from '../types/rbac';

const __dirname = path.resolve();

export function generateComplaintPdf(
  ticket: MaintenanceTicket,
  requestingUser: { id: string; name: string; email: string; role: UserRole },
  effectiveRole: UserRole,
  res: Response
) {
  const doc = new PDFDocument({
    size: 'A4',
    margin: 40,
    bufferPages: true,
    info: {
      Title: `CampusOps Complaint Report - ${ticket.id}`,
      Author: 'CampusOps Facilities Management',
      Subject: `Maintenance Lifecycle Report for ${ticket.buildingName} ${ticket.roomNumber || ''}`,
      Keywords: `CampusOps, Maintenance, Report, ${ticket.id}, ${ticket.category}`
    }
  });

  doc.pipe(res);

  const pageWidth = 595.28;
  const contentWidth = pageWidth - 80; // 515.28

  // -------------------------------------------------------------
  // 1. BRAND HEADER & REPORT IDENTIFIER
  // -------------------------------------------------------------
  const logoPath = path.join(__dirname, 'public', 'campusops-logo.png');
  let startY = 40;

  if (fs.existsSync(logoPath)) {
    try {
      doc.image(logoPath, 40, startY, { width: 44, height: 44 });
    } catch {
      // Fallback logo icon
      doc.rect(40, startY, 44, 44).fill('#0F172A');
      doc.fillColor('#8B5CF6').fontSize(14).font('Helvetica-Bold').text('CO', 50, startY + 12);
    }
  } else {
    doc.rect(40, startY, 44, 44).fill('#0F172A');
    doc.fillColor('#8B5CF6').fontSize(14).font('Helvetica-Bold').text('CO', 50, startY + 12);
  }

  // Header Title
  doc.fillColor('#0F172A').fontSize(15).font('Helvetica-Bold').text('CAMPUSOPS FACILITIES MANAGEMENT', 95, startY + 2);
  doc.fillColor('#475569').fontSize(9).font('Helvetica').text('EEC Engineering Complex • Infrastructure Operations & Audit Division', 95, startY + 20);
  doc.fillColor('#64748B').fontSize(8).font('Helvetica').text(`Official Incident Report Ref: REP-${ticket.id.toUpperCase()}`, 95, startY + 32);

  // Status Badge in Top-Right
  const statusColor = 
    ticket.status === 'resolved' ? '#059669' :
    ticket.status === 'in_progress' ? '#D97706' :
    ticket.status === 'assigned' ? '#2563EB' : '#DC2626';

  const statusLabel = ticket.status.replace('_', ' ').toUpperCase();
  const badgeWidth = 90;
  const badgeHeight = 22;
  const badgeX = pageWidth - 40 - badgeWidth;
  const badgeY = startY + 4;

  doc.roundedRect(badgeX, badgeY, badgeWidth, badgeHeight, 4).fill(statusColor);
  doc.fillColor('#FFFFFF').fontSize(9).font('Helvetica-Bold').text(statusLabel, badgeX, badgeY + 6, {
    width: badgeWidth,
    align: 'center'
  });

  // Timestamp of generation
  const genDateStr = new Date().toLocaleString('en-US', {
    timeZone: 'UTC',
    dateStyle: 'medium',
    timeStyle: 'short'
  });
  doc.fillColor('#64748B').fontSize(7.5).font('Helvetica').text(`Generated: ${genDateStr} UTC`, badgeX - 40, badgeY + 26, {
    width: badgeWidth + 40,
    align: 'right'
  });

  // Decorative Rule
  doc.strokeColor('#E2E8F0').lineWidth(1).moveTo(40, startY + 52).lineTo(pageWidth - 40, startY + 52).stroke();

  let curY = startY + 64;

  // -------------------------------------------------------------
  // 2. COMPLAINT SPECIFICATIONS & LOCATION DETAILS
  // -------------------------------------------------------------
  doc.fillColor('#1E293B').fontSize(11).font('Helvetica-Bold').text('1. COMPLAINT SPECIFICATIONS & LOCATION', 40, curY);
  curY += 18;

  // Key-value grid
  const col1X = 40;
  const col2X = 200;
  const col3X = 360;

  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('COMPLAINT ID', col1X, curY);
  doc.fillColor('#0F172A').fontSize(9).font('Helvetica').text(ticket.id, col1X, curY + 11);

  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('CATEGORY', col2X, curY);
  doc.fillColor('#0F172A').fontSize(9).font('Helvetica').text(ticket.category, col2X, curY + 11);

  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('PRIORITY / SEVERITY', col3X, curY);
  doc.fillColor(ticket.severity === 'critical' ? '#DC2626' : ticket.severity === 'high' ? '#D97706' : '#2563EB')
     .fontSize(9).font('Helvetica-Bold').text(ticket.severity.toUpperCase(), col3X, curY + 11);

  curY += 28;

  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('BUILDING & ZONE', col1X, curY);
  doc.fillColor('#0F172A').fontSize(9).font('Helvetica').text(ticket.buildingName, col1X, curY + 11);

  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('ROOM / SPACE', col2X, curY);
  doc.fillColor('#0F172A').fontSize(9).font('Helvetica').text(ticket.roomNumber ? `Room ${ticket.roomNumber}` : 'General Sector', col2X, curY + 11);

  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('AFFECTED ASSET', col3X, curY);
  const assetStr = ticket.assetName ? `${ticket.assetName}` : 'Facility Fixture / Structural Asset';
  doc.fillColor('#0F172A').fontSize(8.5).font('Helvetica').text(assetStr, col3X, curY + 11, { width: 190 });

  curY += 28;

  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('DATE & TIME REPORTED', col1X, curY);
  const repDateStr = new Date(ticket.reportedAt).toLocaleString('en-US', { timeZone: 'UTC', dateStyle: 'medium', timeStyle: 'short' });
  doc.fillColor('#0F172A').fontSize(9).font('Helvetica').text(`${repDateStr} UTC`, col1X, curY + 11);

  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('REPORTING SOURCE', col2X, curY);
  // Redact personal info if requester is unauthorized or sensitive role
  const redactReporter = (effectiveRole === 'TECHNICIAN' && !ticket.reportedBy.toLowerCase().includes(requestingUser.name.split(' ')[0].toLowerCase()));
  const reporterDisplay = redactReporter ? `${ticket.reportedBy.split(' ')[0]} [Verified Member]` : ticket.reportedBy;
  doc.fillColor('#0F172A').fontSize(9).font('Helvetica').text(reporterDisplay, col2X, curY + 11);

  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('CONTACT EMAIL', col3X, curY);
  const emailDisplay = redactReporter ? 'REDACTED (Privacy Policy)' : (ticket.reporterEmail || 'N/A');
  doc.fillColor('#0F172A').fontSize(8.5).font('Helvetica').text(emailDisplay, col3X, curY + 11);

  curY += 30;

  // Problem Description Box
  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('PROBLEM SUMMARY & OBSERVED SYMPTOMS', col1X, curY);
  curY += 12;

  const descBoxHeight = Math.max(38, doc.heightOfString(ticket.description, { width: contentWidth - 20 }) + 16);
  doc.roundedRect(40, curY, contentWidth, descBoxHeight, 4).fill('#F8FAFC');
  doc.rect(40, curY, 3, descBoxHeight).fill('#00F5FF');

  doc.fillColor('#1E293B').fontSize(8.5).font('Helvetica').text(ticket.description, 52, curY + 8, {
    width: contentWidth - 24,
    lineGap: 3
  });

  curY += descBoxHeight + 14;

  // -------------------------------------------------------------
  // 3. ASSIGNMENT & WORK ORDER DETAILS
  // -------------------------------------------------------------
  doc.fillColor('#1E293B').fontSize(11).font('Helvetica-Bold').text('2. ASSIGNMENT & DISPATCH DETAILS', 40, curY);
  curY += 16;

  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('WORK ORDER ID', col1X, curY);
  doc.fillColor('#0F172A').fontSize(9).font('Helvetica-Bold').text(ticket.workOrderId || 'WO-PENDING', col1X, curY + 11);

  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('ASSIGNED TECHNICIAN', col2X, curY);
  doc.fillColor('#0F172A').fontSize(9).font('Helvetica').text(ticket.assignedTechnicianName || 'Unassigned (Queue Pending)', col2X, curY + 11);

  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('DEPARTMENT / SPECIALTY', col3X, curY);
  doc.fillColor('#0F172A').fontSize(9).font('Helvetica').text(ticket.assignedDepartment || 'Facilities & Engineering', col3X, curY + 11);

  curY += 28;

  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('TECHNICIAN CONTACT', col1X, curY);
  doc.fillColor('#0F172A').fontSize(8.5).font('Helvetica').text(ticket.assignedTechnicianPhone || '+1 (555) 301-4421', col1X, curY + 11);

  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('EMAIL ADDRESS', col2X, curY);
  doc.fillColor('#0F172A').fontSize(8.5).font('Helvetica').text(ticket.assignedTechnicianEmail || 'dispatch@campusops.edu', col2X, curY + 11);

  doc.fillColor('#64748B').fontSize(8).font('Helvetica-Bold').text('DISPATCH STATUS', col3X, curY);
  doc.fillColor('#0F172A').fontSize(9).font('Helvetica-Bold').text(ticket.assignedTechnicianName ? 'Active Duty Dispatch' : 'Awaiting Assignment', col3X, curY + 11);

  curY += 32;

  // -------------------------------------------------------------
  // 4. EXPECTED RESOLUTION DETAILS
  // -------------------------------------------------------------
  doc.fillColor('#1E293B').fontSize(11).font('Helvetica-Bold').text('3. EXPECTED RESOLUTION DETAILS', 40, curY);
  curY += 16;

  if (ticket.estimatedResolution) {
    const estDateStr = new Date(ticket.estimatedResolution).toLocaleString('en-US', {
      timeZone: 'UTC',
      dateStyle: 'full',
      timeStyle: 'short'
    });

    doc.roundedRect(40, curY, contentWidth, 34, 4).fill('#EFF6FF');
    doc.rect(40, curY, 3, 34).fill('#2563EB');

    doc.fillColor('#1E40AF').fontSize(9).font('Helvetica-Bold').text('TARGET RESOLUTION SCHEDULE:', 52, curY + 7);
    doc.fillColor('#1E293B').fontSize(8.5).font('Helvetica').text(`${estDateStr} UTC (Authentic Engineering Estimate)`, 52, curY + 19);
    curY += 44;
  } else {
    // Explicit Notice: Never invent fake resolution dates
    doc.roundedRect(40, curY, contentWidth, 34, 4).fill('#F8FAFC');
    doc.rect(40, curY, 3, 34).fill('#64748B');

    doc.fillColor('#475569').fontSize(9).font('Helvetica-Bold').text('TARGET RESOLUTION SCHEDULE:', 52, curY + 7);
    doc.fillColor('#64748B').fontSize(8.5).font('Helvetica-Oblique').text('Resolution time not yet estimated.', 52, curY + 19);
    curY += 44;
  }

  // -------------------------------------------------------------
  // 5. RESOLUTION DETAILS
  // -------------------------------------------------------------
  doc.fillColor('#1E293B').fontSize(11).font('Helvetica-Bold').text('4. RESOLUTION DETAILS', 40, curY);
  curY += 16;

  if (ticket.status === 'resolved' || ticket.status === 'closed') {
    const resDateStr = ticket.resolvedAt 
      ? new Date(ticket.resolvedAt).toLocaleString('en-US', { timeZone: 'UTC', dateStyle: 'full', timeStyle: 'short' })
      : 'Completion Recorded';

    doc.roundedRect(40, curY, contentWidth, 74, 4).fill('#ECFDF5');
    doc.rect(40, curY, 3, 74).fill('#059669');

    doc.fillColor('#065F46').fontSize(9).font('Helvetica-Bold').text(`REPAIRS COMPLETED ON: ${resDateStr} UTC`, 52, curY + 8);
    doc.fillColor('#065F46').fontSize(8).font('Helvetica').text(`Verified By: ${ticket.verifiedBy || 'Sarah Jenkins (Facilities Admin)'} | Technician: ${ticket.assignedTechnicianName || 'Certified Engineer'}`, 52, curY + 20);

    doc.fillColor('#0F172A').fontSize(8).font('Helvetica-Bold').text('Action Taken:', 52, curY + 33);
    doc.fillColor('#334155').fontSize(8).font('Helvetica').text(ticket.repairActionTaken || ticket.resolutionNotes || 'Remediation completed and verified.', 115, curY + 33, { width: contentWidth - 125 });

    doc.fillColor('#0F172A').fontSize(8).font('Helvetica-Bold').text('Parts Replaced:', 52, curY + 47);
    const partsStr = ticket.partsUsed && ticket.partsUsed.length > 0 ? ticket.partsUsed.join(', ') : 'No inventory replacement required (Diagnostic / Calibration)';
    doc.fillColor('#334155').fontSize(8).font('Helvetica').text(partsStr, 115, curY + 47, { width: contentWidth - 125 });

    curY += 84;
  } else {
    // Explicit Notice: Problem not yet resolved
    doc.roundedRect(40, curY, contentWidth, 34, 4).fill('#FFFBEB');
    doc.rect(40, curY, 3, 34).fill('#D97706');

    doc.fillColor('#92400E').fontSize(9).font('Helvetica-Bold').text('RESOLUTION STATUS:', 52, curY + 7);
    doc.fillColor('#B45309').fontSize(8.5).font('Helvetica-Oblique').text('Problem not yet resolved.', 52, curY + 19);
    curY += 44;
  }

  // -------------------------------------------------------------
  // 6. CHRONOLOGICAL COMPLAINT AUDIT HISTORY
  // -------------------------------------------------------------
  // If remaining space on page 1 is too small for history table, start a new page
  if (curY > 640) {
    doc.addPage();
    curY = 40;
  }

  doc.fillColor('#1E293B').fontSize(11).font('Helvetica-Bold').text('5. CHRONOLOGICAL COMPLAINT AUDIT HISTORY', 40, curY);
  curY += 16;

  // History Table Headers
  const hCol1 = 40;
  const hCol2 = 145;
  const hCol3 = 245;
  const hCol4 = 345;

  doc.roundedRect(40, curY, contentWidth, 18, 2).fill('#F1F5F9');
  doc.fillColor('#475569').fontSize(7.5).font('Helvetica-Bold');
  doc.text('TIMESTAMP (UTC)', hCol1 + 6, curY + 5);
  doc.text('LIFECYCLE ACTION', hCol2, curY + 5);
  doc.text('ACTOR / ROLE', hCol3, curY + 5);
  doc.text('AUDIT NOTES & REMARKS', hCol4, curY + 5);

  curY += 20;

  const historyEvents = ticket.history && ticket.history.length > 0 ? ticket.history : [
    {
      id: 'default-1',
      timestamp: ticket.reportedAt,
      action: 'REPORTED',
      actorName: ticket.reportedBy,
      actorRole: 'Complainant',
      details: 'Initial complaint logged in system.'
    }
  ];

  historyEvents.forEach((evt, idx) => {
    if (curY > 740) {
      doc.addPage();
      curY = 40;
    }

    const rowBg = idx % 2 === 0 ? '#FFFFFF' : '#F8FAFC';
    const evtTime = new Date(evt.timestamp).toLocaleString('en-US', { timeZone: 'UTC', dateStyle: 'short', timeStyle: 'short' });

    doc.rect(40, curY, contentWidth, 22).fill(rowBg);
    doc.strokeColor('#E2E8F0').lineWidth(0.5).rect(40, curY, contentWidth, 22).stroke();

    doc.fillColor('#334155').fontSize(7.5).font('Helvetica').text(evtTime, hCol1 + 6, curY + 6);
    
    // Action tag
    doc.fillColor('#0F172A').fontSize(7.5).font('Helvetica-Bold').text(evt.action, hCol2, curY + 6);
    doc.fillColor('#475569').fontSize(7.5).font('Helvetica').text(`${evt.actorName} (${evt.actorRole})`, hCol3, curY + 6, { width: 95 });
    doc.fillColor('#1E293B').fontSize(7.5).font('Helvetica').text(evt.details, hCol4, curY + 6, { width: contentWidth - 310, height: 16 });

    curY += 23;
  });

  curY += 12;

  // -------------------------------------------------------------
  // 7. SECURITY SIGNATURE & AUDIT CERTIFICATION
  // -------------------------------------------------------------
  if (curY > 710) {
    doc.addPage();
    curY = 40;
  }

  const hashDigest = crypto.createHash('sha256').update(ticket.id + ticket.reportedAt + (ticket.resolvedAt || 'unresolved')).digest('hex');

  doc.roundedRect(40, curY, contentWidth, 36, 4).fill('#F8FAFC');
  doc.strokeColor('#CBD5E1').lineWidth(0.5).roundedRect(40, curY, contentWidth, 36, 4).stroke();

  doc.fillColor('#475569').fontSize(7).font('Helvetica-Bold').text('CRYPTOGRAPHIC INTEGRITY HASH (SHA-256):', 50, curY + 6);
  doc.fillColor('#0F172A').fontSize(7).font('Courier').text(hashDigest, 50, curY + 15);
  doc.fillColor('#64748B').fontSize(6.5).font('Helvetica').text('This document was dynamically compiled by CampusOps Intelligent Core. All timestamps are UTC certified.', 50, curY + 25);

  // -------------------------------------------------------------
  // 8. MULTI-PAGE FOOTER WITH PAGE NUMBERS
  // -------------------------------------------------------------
  const range = doc.bufferedPageRange();
  for (let i = range.start; i < range.start + range.count; i++) {
    doc.switchToPage(i);
    doc.strokeColor('#E2E8F0').lineWidth(0.5).moveTo(40, 792 - 35).lineTo(pageWidth - 40, 792 - 35).stroke();
    doc.fillColor('#94A3B8').fontSize(7.5).font('Helvetica').text(
      `CampusOps EEC Platform • Confidential Facility Record • Page ${i + 1} of ${range.count}`,
      40,
      792 - 26,
      { width: contentWidth, align: 'center' }
    );
  }

  doc.end();
}
