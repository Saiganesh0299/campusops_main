import { Building, Floor, Classroom } from '../types/campus';

export const ORDINAL_NAMES = [
  'Ground Floor',
  'First Floor',
  'Second Floor',
  'Third Floor',
  'Fourth Floor',
  'Fifth Floor',
  'Sixth Floor',
  'Seventh Floor',
  'Eighth Floor',
  'Ninth Floor',
  'Tenth Floor'
];

export function getFloorName(floorNumber: number): string {
  if (floorNumber >= 0 && floorNumber < ORDINAL_NAMES.length) {
    return ORDINAL_NAMES[floorNumber];
  }
  return `Floor ${floorNumber}`;
}

export function getFloorLevelLabel(floorNumber: number): string {
  if (floorNumber === 0) return 'Ground Floor';
  if (floorNumber === 1) return '1st Floor';
  if (floorNumber === 2) return '2nd Floor';
  if (floorNumber === 3) return '3rd Floor';
  return `${floorNumber}th Floor`;
}

/**
 * Creates a new Floor object for a building at the given floorNumber.
 */
export function createNewFloor(buildingId: string, floorNumber: number, existingCount?: number): Floor {
  const shortId = buildingId.replace('bldg-', '');
  return {
    id: `fl-${shortId}-${floorNumber}`,
    buildingId,
    floorNumber,
    name: getFloorName(floorNumber),
    levelLabel: getFloorLevelLabel(floorNumber),
    classroomCount: 3,
    activeIssuesCount: 0,
    occupancyRate: 60,
    svgLayoutDimensions: { width: 900, height: 500 }
  };
}

/**
 * Generates default classrooms for a newly added floor so booking, maintenance,
 * and 2D blueprint functionality work seamlessly.
 */
export function createDefaultRoomsForFloor(building: Building, floor: Floor): Classroom[] {
  const prefix = building.code.charAt(0) || 'R';
  const fNum = floor.floorNumber;
  const shortId = building.id.replace('bldg-', '');
  
  return [
    {
      id: `rm-${shortId}-${fNum}01`,
      buildingId: building.id,
      floorId: floor.id,
      name: `${building.name.split(' ')[0]} Lecture Room ${fNum}01`,
      roomNumber: `${prefix}-${fNum}01`,
      capacity: 55,
      type: 'Lecture Hall',
      status: 'available',
      equipment: ['Laser 4K Projector', 'Surround Audio', 'Wireless Mics', 'Digital Podium'],
      equipmentCondition: 'Excellent',
      lastMaintenanceDate: new Date().toISOString().split('T')[0],
      gridPosition: { x: 50, y: 50, width: 360, height: 180 },
      features: ['Tiered Seating', 'Acoustic Wall Panels', 'Dual HDMI/USB-C Inputs'],
      notes: `Active lecture space on ${floor.name}.`
    },
    {
      id: `rm-${shortId}-${fNum}02`,
      buildingId: building.id,
      floorId: floor.id,
      name: `${building.name.split(' ')[0]} Interactive Lab ${fNum}02`,
      roomNumber: `${prefix}-${fNum}02`,
      capacity: 40,
      type: 'Laboratory',
      status: 'available',
      equipment: ['86" Smart Interactive Board', 'Workstations with GPUs', 'Fiber Network Switch'],
      equipmentCondition: 'Good',
      lastMaintenanceDate: new Date().toISOString().split('T')[0],
      gridPosition: { x: 450, y: 50, width: 380, height: 180 },
      features: ['Modular Workbenches', 'Surge-Protected Power Grid', 'Air Quality Sensor'],
      notes: `Collaborative research and laboratory room on ${floor.name}.`
    },
    {
      id: `rm-${shortId}-${fNum}03`,
      buildingId: building.id,
      floorId: floor.id,
      name: `${building.name.split(' ')[0]} Seminar Suite ${fNum}03`,
      roomNumber: `${prefix}-${fNum}03`,
      capacity: 35,
      type: 'Seminar Hall',
      status: 'available',
      equipment: ['Direct-View LED Display', 'Ceiling Microphone Array', 'PTZ Conference Camera'],
      equipmentCondition: 'Excellent',
      lastMaintenanceDate: new Date().toISOString().split('T')[0],
      gridPosition: { x: 50, y: 270, width: 360, height: 180 },
      features: ['Sound Absorption Curtains', 'Motorized Blackout Blinds', 'Executive Seating'],
      notes: `Seminar and defense presentation suite on ${floor.name}.`
    }
  ];
}
