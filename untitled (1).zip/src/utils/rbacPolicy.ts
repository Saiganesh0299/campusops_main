import { User, UserRole, AccessScope } from '../types/rbac';
import { MaintenanceTicket } from '../types/campus';

export interface RolePolicy {
  scope: AccessScope;
  allowedTabs: string[];
  description: string;
  canManageUsers: boolean;
  canManageStaff: boolean;
  canManageInventory: boolean;
  canManageIncidents: boolean;
  canReassignWorkOrders: boolean;
  canUpdateWorkOrderStatus: boolean;
  canApprovePurchases: boolean;
  canSubmitPurchases: boolean;
  canAccessAnalytics: boolean;
  canAccessSystemSettings: boolean;
}

export const ROLE_POLICIES: Record<UserRole, RolePolicy> = {
  STUDENT_FACULTY: {
    scope: 'OWN',
    allowedTabs: ['3d-campus', 'floor-plan', 'maintenance', 'bookings', 'notifications', 'ai-chat'],
    description: 'Permitted to report complaints, view and track own complaints, download own complaint reports, view notifications, and book student-accessible spaces.',
    canManageUsers: false,
    canManageStaff: false,
    canManageInventory: false,
    canManageIncidents: false,
    canReassignWorkOrders: false,
    canUpdateWorkOrderStatus: false,
    canApprovePurchases: false,
    canSubmitPurchases: false,
    canAccessAnalytics: false,
    canAccessSystemSettings: false
  },
  TECHNICIAN: {
    scope: 'ASSIGNED',
    allowedTabs: ['3d-campus', 'floor-plan', 'maintenance', 'inventory', 'bookings', 'notifications', 'ai-chat'],
    description: 'Permitted to view assigned work orders, update repair progress/status, add repair notes, request parts, and inspect rooms/assets.',
    canManageUsers: false,
    canManageStaff: false,
    canManageInventory: false, // can view and request parts, not manage master catalog
    canManageIncidents: false,
    canReassignWorkOrders: false,
    canUpdateWorkOrderStatus: true,
    canApprovePurchases: false,
    canSubmitPurchases: true,
    canAccessAnalytics: false,
    canAccessSystemSettings: false
  },
  DEPT_MANAGER: {
    scope: 'DEPARTMENT',
    allowedTabs: ['3d-campus', 'floor-plan', 'maintenance', 'bookings', 'procurement', 'analytics', 'notifications', 'ai-chat'],
    description: 'Permitted to view department-scoped complaints, monitor department progress, manage department space bookings, submit purchase requests, and review department analytics.',
    canManageUsers: false,
    canManageStaff: false,
    canManageInventory: false,
    canManageIncidents: false,
    canReassignWorkOrders: false,
    canUpdateWorkOrderStatus: false,
    canApprovePurchases: false,
    canSubmitPurchases: true,
    canAccessAnalytics: true,
    canAccessSystemSettings: false
  },
  FACILITIES_ADMIN: {
    scope: 'CAMPUS',
    allowedTabs: ['3d-campus', 'dashboard', 'floor-plan', 'maintenance', 'bookings', 'inventory', 'staff', 'incidents', 'procurement', 'analytics', 'notifications', 'ai-chat'],
    description: 'Campus-wide operations: manage work orders, assign technicians, monitor buildings, rooms, staff, inventory, incidents, and purchase requests.',
    canManageUsers: false, // Only System Admin can alter user directory and roles
    canManageStaff: true,
    canManageInventory: true,
    canManageIncidents: true,
    canReassignWorkOrders: true,
    canUpdateWorkOrderStatus: true,
    canApprovePurchases: false,
    canSubmitPurchases: true,
    canAccessAnalytics: true,
    canAccessSystemSettings: false
  },
  PROCUREMENT: {
    scope: 'CAMPUS',
    allowedTabs: ['3d-campus', 'floor-plan', 'inventory', 'procurement', 'analytics', 'notifications', 'ai-chat'],
    description: 'Central procurement and supply chain: review, approve, reject, and track purchase requests, manage parts suppliers, and track inventory levels.',
    canManageUsers: false,
    canManageStaff: false,
    canManageInventory: true,
    canManageIncidents: false,
    canReassignWorkOrders: false,
    canUpdateWorkOrderStatus: false,
    canApprovePurchases: true,
    canSubmitPurchases: true,
    canAccessAnalytics: true,
    canAccessSystemSettings: false
  },
  SYSTEM_ADMIN: {
    scope: 'ALL',
    allowedTabs: ['3d-campus', 'dashboard', 'floor-plan', 'maintenance', 'bookings', 'inventory', 'staff', 'incidents', 'procurement', 'analytics', 'user-management', 'settings', 'notifications', 'ai-chat'],
    description: 'Full root access: user account lifecycle, role & permission assignments, audit logs, campus topology, and system AI policies.',
    canManageUsers: true,
    canManageStaff: true,
    canManageInventory: true,
    canManageIncidents: true,
    canReassignWorkOrders: true,
    canUpdateWorkOrderStatus: true,
    canApprovePurchases: true,
    canSubmitPurchases: true,
    canAccessAnalytics: true,
    canAccessSystemSettings: true
  }
};

/**
 * Check if a role can access a particular tab/module
 */
export function canAccessTab(role: UserRole, tabId: string): boolean {
  const policy = ROLE_POLICIES[role];
  if (!policy) return false;
  return policy.allowedTabs.includes(tabId);
}

/**
 * Human-readable required role for AccessDeniedView
 */
export function getRequiredRoleForTab(tabId: string): string {
  switch (tabId) {
    case 'dashboard':
      return 'FACILITIES_ADMIN or SYSTEM_ADMIN';
    case 'staff':
      return 'FACILITIES_ADMIN or SYSTEM_ADMIN';
    case 'incidents':
      return 'FACILITIES_ADMIN or SYSTEM_ADMIN';
    case 'inventory':
      return 'TECHNICIAN, PROCUREMENT, FACILITIES_ADMIN, or SYSTEM_ADMIN';
    case 'procurement':
      return 'DEPARTMENT_MANAGER, PROCUREMENT, FACILITIES_ADMIN, or SYSTEM_ADMIN';
    case 'analytics':
      return 'DEPARTMENT_MANAGER, PROCUREMENT, FACILITIES_ADMIN, or SYSTEM_ADMIN';
    case 'user-management':
      return 'SYSTEM_ADMIN';
    case 'settings':
      return 'SYSTEM_ADMIN';
    default:
      return 'FACILITIES_ADMIN or SYSTEM_ADMIN';
  }
}

/**
 * Filters tickets based on user role and data scope hierarchy:
 * - STUDENT_FACULTY: Strictly own complaints only (matches reporterEmail or user name)
 * - TECHNICIAN: Only assigned work orders
 * - DEPT_MANAGER: Only complaints within authorized department/buildings
 * - FACILITIES_ADMIN & SYSTEM_ADMIN: Campus-wide (all complaints)
 */
export function filterScopedTickets(tickets: MaintenanceTicket[], user: User): MaintenanceTicket[] {
  if (!user) return [];

  // System Admin and Facilities Admin see all campus tickets
  if (user.role === 'SYSTEM_ADMIN' || user.role === 'FACILITIES_ADMIN') {
    return tickets;
  }

  // Technician sees only assigned work orders
  if (user.role === 'TECHNICIAN') {
    const userFirstName = user.name.split(' ')[0].toLowerCase();
    return tickets.filter(t => {
      const matchId = t.assignedTechnicianId === user.id;
      const matchEmail = t.assignedTechnicianEmail && user.email && t.assignedTechnicianEmail.toLowerCase() === user.email.toLowerCase();
      const matchName = t.assignedTechnicianName && t.assignedTechnicianName.toLowerCase().includes(userFirstName);
      return matchId || matchEmail || matchName;
    });
  }

  // Department Manager sees tickets in their department jurisdiction
  if (user.role === 'DEPT_MANAGER') {
    if (user.departmentId === 'dept-cs') {
      return tickets.filter(t => 
        t.buildingId === 'bldg-acad' || 
        t.assignedDepartment === 'Computer Science & Engineering' ||
        t.category === 'Electrical' || 
        t.category === 'Network'
      );
    }
    if (user.departmentId === 'dept-ee') {
      return tickets.filter(t => 
        t.buildingId === 'bldg-mech' || 
        t.assignedDepartment === 'Electrical Engineering & IoT' ||
        t.category === 'Electrical' || 
        t.category === 'Audio/Visual'
      );
    }
    return tickets.filter(t => t.assignedDepartment === user.departmentName);
  }

  // Student / Faculty sees strictly their own complaints
  if (user.role === 'STUDENT_FACULTY') {
    const userFirstName = user.name.split(' ')[0].toLowerCase();
    const userFullName = user.name.toLowerCase();
    const userEmail = (user.email || '').toLowerCase();

    return tickets.filter(t => {
      const repEmail = (t.reporterEmail || '').toLowerCase();
      const repBy = (t.reportedBy || '').toLowerCase();

      // Exact email match
      if (userEmail && repEmail && userEmail === repEmail) return true;

      // Exact or partial name match
      if (repBy.includes(userFullName) || repBy.includes(userFirstName)) return true;

      // Demo accounts specific linkage
      if (user.id === 'usr-student-alex' && (repBy.includes('alex') || repEmail.includes('alex'))) {
        return true;
      }
      if (user.id === 'usr-faculty-rachel' && (repBy.includes('rachel') || repEmail.includes('rachel'))) {
        return true;
      }

      return false;
    });
  }

  // Procurement sees tickets with equipment or parts
  if (user.role === 'PROCUREMENT') {
    return tickets.filter(t => Boolean(t.assetName || t.assetTag || t.workOrderId));
  }

  return tickets;
}
