export type UserRole = 
  | 'STUDENT_FACULTY' 
  | 'TECHNICIAN' 
  | 'DEPT_MANAGER' 
  | 'FACILITIES_ADMIN' 
  | 'PROCUREMENT' 
  | 'SYSTEM_ADMIN';

export type AccessScope = 'OWN' | 'ASSIGNED' | 'DEPARTMENT' | 'CAMPUS' | 'ALL';

export interface Department {
  id: string;
  name: string;
  code: string;
  buildingId?: string;
  headName?: string;
}

export interface UserPermissionOverride {
  permissionName: string;
  granted: boolean;
  notes?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  departmentId?: string;
  departmentName?: string;
  isActive: boolean;
  isPrimaryAdmin?: boolean;
  phone?: string;
  avatarUrl?: string;
  lastLoginAt?: string;
  createdAt: string;
  permissions?: string[];
  overrides?: UserPermissionOverride[];
}

export type PurchaseStatus = 
  | 'PENDING_REVIEW' 
  | 'APPROVED' 
  | 'REJECTED' 
  | 'ORDERED' 
  | 'RECEIVED' 
  | 'CANCELLED';

export interface PurchaseItem {
  name: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  partNumber?: string;
}

export interface PurchaseApproval {
  id: string;
  approverId: string;
  approverName: string;
  approverRole: UserRole;
  action: 'APPROVED' | 'REJECTED';
  comments?: string;
  timestamp: string;
}

export interface PurchaseRequest {
  id: string;
  requestNumber: string;
  title: string;
  justification: string;
  departmentId: string;
  departmentName: string;
  requesterId: string;
  requesterName: string;
  requesterRole: UserRole;
  relatedTicketId?: string;
  items: PurchaseItem[];
  totalAmount: number;
  status: PurchaseStatus;
  urgency: 'LOW' | 'NORMAL' | 'HIGH' | 'EMERGENCY';
  createdAt: string;
  updatedAt: string;
  approvals: PurchaseApproval[];
}

export const ROLE_LABELS: Record<UserRole, string> = {
  STUDENT_FACULTY: 'Student / Faculty',
  TECHNICIAN: 'Technician',
  DEPT_MANAGER: 'Department Manager',
  FACILITIES_ADMIN: 'Facilities Admin',
  PROCUREMENT: 'Central Procurement',
  SYSTEM_ADMIN: 'System Admin'
};

export const ROLE_COLORS: Record<UserRole, { bg: string; text: string; border: string; glow: string }> = {
  STUDENT_FACULTY: {
    bg: 'bg-emerald-500/10',
    text: 'text-emerald-400',
    border: 'border-emerald-500/30',
    glow: 'shadow-emerald-500/20'
  },
  TECHNICIAN: {
    bg: 'bg-amber-500/10',
    text: 'text-amber-400',
    border: 'border-amber-500/30',
    glow: 'shadow-amber-500/20'
  },
  DEPT_MANAGER: {
    bg: 'bg-indigo-500/10',
    text: 'text-indigo-400',
    border: 'border-indigo-500/30',
    glow: 'shadow-indigo-500/20'
  },
  FACILITIES_ADMIN: {
    bg: 'bg-[#00F5FF]/10',
    text: 'text-[#00F5FF]',
    border: 'border-[#00F5FF]/30',
    glow: 'shadow-[#00F5FF]/20'
  },
  PROCUREMENT: {
    bg: 'bg-[#7B2CBF]/15',
    text: 'text-[#C084FC]',
    border: 'border-[#7B2CBF]/40',
    glow: 'shadow-[#7B2CBF]/20'
  },
  SYSTEM_ADMIN: {
    bg: 'bg-[#8B5CF6]/15',
    text: 'text-[#A78BFA]',
    border: 'border-[#8B5CF6]/40',
    glow: 'shadow-[#8B5CF6]/25'
  }
};
