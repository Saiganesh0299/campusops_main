import React, { useState, useEffect } from 'react';
import { User, PurchaseRequest, PurchaseStatus, Department, ROLE_LABELS } from '../types/rbac';
import { 
  ShoppingBag, 
  Plus, 
  Search, 
  Filter, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  DollarSign, 
  Building2, 
  User as UserIcon, 
  FileText, 
  X,
  ShieldAlert,
  Send,
  PackageCheck,
  Truck
} from 'lucide-react';

interface ProcurementViewProps {
  currentUser: User;
  onRefresh?: () => void;
}

export const ProcurementView: React.FC<ProcurementViewProps> = ({
  currentUser
}) => {
  const [purchases, setPurchases] = useState<PurchaseRequest[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [deptFilter, setDeptFilter] = useState<string>('ALL');

  // Modals
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [decisionModalItem, setDecisionModalItem] = useState<PurchaseRequest | null>(null);
  const [decisionAction, setDecisionAction] = useState<'APPROVE' | 'REJECT'>('APPROVE');
  const [decisionComments, setDecisionComments] = useState('');

  // Toast / Feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Create Form State
  const [createForm, setCreateForm] = useState<{
    title: string;
    justification: string;
    departmentId: string;
    urgency: 'LOW' | 'NORMAL' | 'HIGH' | 'EMERGENCY';
    items: { name: string; quantity: number; unitPrice: number; partNumber: string }[];
  }>({
    title: '',
    justification: '',
    departmentId: currentUser.departmentId || 'dept-cs',
    urgency: 'NORMAL',
    items: [
      { name: '', quantity: 1, unitPrice: 0, partNumber: '' }
    ]
  });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const showError = (msg: string) => {
    setErrorMessage(msg);
    setTimeout(() => setErrorMessage(null), 5000);
  };

  // Load Purchases
  const loadData = async () => {
    try {
      const [pRes, dRes] = await Promise.all([
        fetch('/api/purchases'),
        fetch('/api/departments')
      ]);

      if (pRes.ok) {
        const pData = await pRes.json();
        setPurchases(pData);
      }
      if (dRes.ok) {
        const dData = await dRes.json();
        setDepartments(dData);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Check if current user has approval permission
  const hasApprovalAuthority = () => {
    if (currentUser.role === 'SYSTEM_ADMIN' || currentUser.role === 'PROCUREMENT') return true;
    return !!currentUser.overrides?.some(o => o.permissionName === 'purchases:approve' && o.granted);
  };

  // Create Request Handler
  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!createForm.title || !createForm.items.length) {
      showError('Title and at least one item are required.');
      return;
    }

    const validItems = createForm.items.filter(i => i.name.trim() !== '');
    if (!validItems.length) {
      showError('Please specify valid line items.');
      return;
    }

    try {
      const payload = {
        title: createForm.title,
        justification: createForm.justification,
        departmentId: createForm.departmentId,
        requesterId: currentUser.id,
        items: validItems.map(i => ({
          ...i,
          totalPrice: i.quantity * i.unitPrice
        })),
        urgency: createForm.urgency
      };

      const res = await fetch('/api/purchases', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (!res.ok) {
        showError(data.error || 'Failed to submit purchase request.');
        return;
      }

      setPurchases(prev => [data, ...prev]);
      setShowCreateModal(false);
      setCreateForm({
        title: '',
        justification: '',
        departmentId: currentUser.departmentId || 'dept-cs',
        urgency: 'NORMAL',
        items: [{ name: '', quantity: 1, unitPrice: 0, partNumber: '' }]
      });
      showToast(`Purchase request ${data.requestNumber} submitted for authorization.`);
    } catch (err: any) {
      showError(err.message);
    }
  };

  // Submit Approval or Rejection Decision
  const handleDecisionSubmit = async () => {
    if (!decisionModalItem) return;

    // Anti-Self-Approval Check
    if (decisionModalItem.requesterId === currentUser.id) {
      showError('Anti-Self-Approval violation: You cannot approve or reject your own request.');
      return;
    }

    if (!hasApprovalAuthority()) {
      showError('Insufficient authority: Purchase approval rights required.');
      return;
    }

    const endpoint = decisionAction === 'APPROVE' 
      ? `/api/purchases/${decisionModalItem.id}/approve`
      : `/api/purchases/${decisionModalItem.id}/reject`;

    try {
      const res = await fetch(endpoint, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          approverId: currentUser.id,
          comments: decisionComments || (decisionAction === 'APPROVE' ? 'Approved as budgeted' : 'Rejected')
        })
      });

      const data = await res.json();
      if (!res.ok) {
        showError(data.error || 'Failed to process decision.');
        return;
      }

      setPurchases(prev => prev.map(p => p.id === decisionModalItem.id ? data : p));
      setDecisionModalItem(null);
      setDecisionComments('');
      showToast(`Purchase request ${data.requestNumber} was ${data.status}.`);
    } catch (err: any) {
      showError(err.message);
    }
  };

  // Add Item Line
  const handleAddItem = () => {
    setCreateForm(prev => ({
      ...prev,
      items: [...prev.items, { name: '', quantity: 1, unitPrice: 0, partNumber: '' }]
    }));
  };

  // Remove Item Line
  const handleRemoveItem = (index: number) => {
    if (createForm.items.length <= 1) return;
    setCreateForm(prev => ({
      ...prev,
      items: prev.items.filter((_, idx) => idx !== index)
    }));
  };

  // Update Item Line
  const handleItemChange = (index: number, field: string, val: any) => {
    setCreateForm(prev => {
      const newItems = [...prev.items];
      newItems[index] = { ...newItems[index], [field]: val };
      return { ...prev, items: newItems };
    });
  };

  // Calculated form total
  const estimatedTotal = createForm.items.reduce((s, it) => s + (Number(it.quantity || 0) * Number(it.unitPrice || 0)), 0);

  // Filtered List
  const filtered = purchases.filter(p => {
    const matchesSearch = 
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.requestNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.requesterName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.departmentName.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'ALL' || p.status === statusFilter;
    const matchesDept = deptFilter === 'ALL' || p.departmentId === deptFilter;

    return matchesSearch && matchesStatus && matchesDept;
  });

  // Financial KPIs
  const totalSpend = purchases.reduce((s, p) => s + p.totalAmount, 0);
  const pendingCount = purchases.filter(p => p.status === 'PENDING_REVIEW').length;
  const approvedCount = purchases.filter(p => p.status === 'APPROVED' || p.status === 'ORDERED' || p.status === 'RECEIVED').length;

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-xl bg-emerald-950/90 border border-emerald-500/40 text-emerald-300 shadow-2xl flex items-center gap-3 backdrop-blur-md animate-slide-up">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs font-semibold">{toastMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-xl bg-rose-950/90 border border-rose-500/40 text-rose-300 shadow-2xl flex items-center gap-3 backdrop-blur-md animate-slide-up">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
          <span className="text-xs font-semibold">{errorMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-[#0B0C14] border border-[#1E2030]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-xl font-extrabold text-white tracking-tight">
              Procurement & Purchase Approvals
            </h1>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-purple-500/15 text-purple-300 border border-purple-500/40">
              ANTI-SELF-APPROVAL SECURED
            </span>
          </div>
          <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
            Multi-tier acquisition workflow for equipment replacements, engineering components, and facility parts. Governed by Central Procurement with admin-delegated approval authority.
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#7B2CBF] to-[#9D4EDD] text-white text-xs font-bold shadow-[0_0_15px_rgba(123,44,191,0.35)] hover:brightness-110 transition-all cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          Request Purchase Parts
        </button>
      </div>

      {/* Financial KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-[#0B0C14] border border-[#1E2030]">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Total Requested Commitments</span>
          <div className="text-2xl font-extrabold text-white font-mono tabular-nums">
            ${totalSpend.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <span className="text-[10px] text-slate-500 mt-1 block">Active campus procurement ledger</span>
        </div>

        <div className="p-4 rounded-xl bg-[#0B0C14] border border-[#1E2030]">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Pending Authorizations</span>
          <div className="text-2xl font-extrabold text-amber-400 font-mono tabular-nums flex items-center gap-2">
            {pendingCount}
            <span className="text-xs font-bold px-1.5 py-0.5 rounded bg-amber-500/10 border border-amber-500/20">
              Needs Review
            </span>
          </div>
          <span className="text-[10px] text-slate-500 mt-1 block">Awaiting manager/procurement signoff</span>
        </div>

        <div className="p-4 rounded-xl bg-[#0B0C14] border border-[#1E2030]">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Approved & Fulfilled</span>
          <div className="text-2xl font-extrabold text-emerald-400 font-mono tabular-nums">
            {approvedCount}
          </div>
          <span className="text-[10px] text-slate-500 mt-1 block">Cleared for ordering / receipt</span>
        </div>

        <div className="p-4 rounded-xl bg-[#0B0C14] border border-[#1E2030]">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Your Approval Authority</span>
          <div className="text-sm font-bold font-mono mt-1">
            {hasApprovalAuthority() ? (
              <span className="text-purple-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-purple-400" />
                AUTHORIZED APPROVER
              </span>
            ) : (
              <span className="text-slate-500 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-slate-500" />
                REQUESTER ONLY
              </span>
            )}
          </div>
          <span className="text-[10px] text-slate-500 mt-1 block">
            Role: {ROLE_LABELS[currentUser.role]}
          </span>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="p-4 rounded-xl bg-[#0B0C14] border border-[#1E2030] flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search request #, equipment title, requester, or department..."
            className="w-full pl-10 pr-4 py-2 bg-[#0E101A] border border-[#1E2030] rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-[#0E101A] border border-[#1E2030] rounded-xl text-xs text-slate-200 focus:outline-none focus:border-purple-500 cursor-pointer"
          >
            <option value="ALL">All Statuses</option>
            <option value="PENDING_REVIEW">Pending Review</option>
            <option value="APPROVED">Approved</option>
            <option value="REJECTED">Rejected</option>
            <option value="ORDERED">Ordered</option>
            <option value="RECEIVED">Received</option>
          </select>

          {/* Department Filter */}
          <select
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value)}
            className="px-3 py-2 bg-[#0E101A] border border-[#1E2030] rounded-xl text-xs text-slate-200 focus:outline-none focus:border-purple-500 cursor-pointer"
          >
            <option value="ALL">All Departments</option>
            {departments.map(d => (
              <option key={d.id} value={d.id}>{d.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Requests List */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-[#0B0C14] border border-[#1E2030] text-slate-500 text-xs">
            No purchase requests found matching the current search and filter criteria.
          </div>
        ) : (
          filtered.map((pr) => {
            const isSelf = pr.requesterId === currentUser.id;
            const canApprove = hasApprovalAuthority() && !isSelf && pr.status === 'PENDING_REVIEW';

            return (
              <div
                key={pr.id}
                className="p-5 rounded-2xl bg-[#0B0C14] border border-[#1E2030] hover:border-slate-700 transition-all space-y-4"
              >
                {/* Header Row */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs font-bold text-purple-400 bg-purple-500/10 px-2.5 py-1 rounded-lg border border-purple-500/30">
                      {pr.requestNumber}
                    </span>
                    <h3 className="text-sm font-bold text-white tracking-wide">
                      {pr.title}
                    </h3>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Urgency */}
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      pr.urgency === 'EMERGENCY' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' :
                      pr.urgency === 'HIGH' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                      'bg-slate-800 text-slate-300'
                    }`}>
                      {pr.urgency}
                    </span>

                    {/* Status Badge */}
                    <span className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold border ${
                      pr.status === 'APPROVED' ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' :
                      pr.status === 'REJECTED' ? 'bg-rose-500/15 text-rose-400 border-rose-500/30' :
                      pr.status === 'ORDERED' ? 'bg-blue-500/15 text-blue-400 border-blue-500/30' :
                      pr.status === 'RECEIVED' ? 'bg-purple-500/15 text-purple-400 border-purple-500/30' :
                      'bg-amber-500/15 text-amber-400 border-amber-500/30 animate-pulse'
                    }`}>
                      {pr.status.replace('_', ' ')}
                    </span>
                  </div>
                </div>

                {/* Justification & Dept Info */}
                <p className="text-xs text-slate-300 leading-relaxed bg-[#0E101A] p-3 rounded-xl border border-[#1E2030]/60">
                  <span className="font-semibold text-slate-200">Justification: </span>
                  {pr.justification}
                </p>

                {/* Line Items Breakdown */}
                <div className="rounded-xl border border-[#1E2030]/60 bg-[#12131A] overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-[#1E2030] text-[10px] font-mono text-slate-400 uppercase bg-[#161722]">
                        <th className="py-2 px-3">Item Description</th>
                        <th className="py-2 px-3">Part #</th>
                        <th className="py-2 px-3 text-right">Quantity</th>
                        <th className="py-2 px-3 text-right">Unit Price</th>
                        <th className="py-2 px-3 text-right">Line Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#1E2030]/40 font-mono text-[11px]">
                      {pr.items.map((it, idx) => (
                        <tr key={idx} className="hover:bg-[#181926]/50">
                          <td className="py-2 px-3 font-sans text-white">{it.name}</td>
                          <td className="py-2 px-3 text-slate-400">{it.partNumber || '—'}</td>
                          <td className="py-2 px-3 text-right tabular-nums text-slate-200">{it.quantity}</td>
                          <td className="py-2 px-3 text-right tabular-nums text-slate-200">${it.unitPrice.toFixed(2)}</td>
                          <td className="py-2 px-3 text-right tabular-nums font-bold text-white">${it.totalPrice.toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Footer Metadata & Action Buttons */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 text-xs">
                  <div className="flex flex-wrap items-center gap-4 text-slate-400 text-[11px]">
                    <span className="flex items-center gap-1.5">
                      <UserIcon className="w-3.5 h-3.5 text-purple-400" />
                      Requester: <strong className="text-white ml-0.5">{pr.requesterName}</strong> ({ROLE_LABELS[pr.requesterRole]})
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-slate-500" />
                      {pr.departmentName}
                    </span>
                    <span className="font-mono text-slate-500">
                      Submitted: {new Date(pr.createdAt).toLocaleDateString()}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 self-end sm:self-auto">
                    <div className="text-right">
                      <span className="text-[10px] text-slate-500 uppercase block font-mono">Total Commitment</span>
                      <span className="text-base font-extrabold text-white font-mono tabular-nums">
                        ${pr.totalAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </div>

                    {/* Decision Buttons */}
                    {pr.status === 'PENDING_REVIEW' && (
                      <div className="flex items-center gap-1.5">
                        {isSelf ? (
                          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-[11px] font-mono">
                            <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                            <span>Anti-Self-Approval: Cannot approve own request</span>
                          </div>
                        ) : canApprove ? (
                          <>
                            <button
                              onClick={() => {
                                setDecisionModalItem(pr);
                                setDecisionAction('APPROVE');
                              }}
                              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-[0_0_10px_rgba(16,185,129,0.3)] transition-all cursor-pointer"
                            >
                              Approve
                            </button>
                            <button
                              onClick={() => {
                                setDecisionModalItem(pr);
                                setDecisionAction('REJECT');
                              }}
                              className="px-3 py-1.5 rounded-xl bg-rose-600/80 hover:bg-rose-600 text-white font-bold text-xs transition-all cursor-pointer"
                            >
                              Reject
                            </button>
                          </>
                        ) : (
                          <span className="text-[11px] text-slate-500 font-mono px-2 py-1 bg-slate-900 rounded-lg">
                            Awaiting Procurement Signoff
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Approvals Audit Trail */}
                {pr.approvals && pr.approvals.length > 0 && (
                  <div className="border-t border-[#1E2030]/60 pt-3 text-[11px] space-y-1">
                    <span className="font-mono text-[10px] uppercase text-slate-400 font-semibold block">
                      Authorization Audit Trail:
                    </span>
                    {pr.approvals.map((appr) => (
                      <div key={appr.id} className="flex items-center justify-between text-slate-300 bg-[#161722] px-3 py-1.5 rounded-lg">
                        <span className="flex items-center gap-1.5">
                          <CheckCircle2 className={`w-3.5 h-3.5 ${appr.action === 'APPROVED' ? 'text-emerald-400' : 'text-rose-400'}`} />
                          <strong className="text-white">{appr.approverName}</strong> ({ROLE_LABELS[appr.approverRole]}): "{appr.comments}"
                        </span>
                        <span className="font-mono text-[10px] text-slate-500">
                          {new Date(appr.timestamp).toLocaleString()}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* CREATE PURCHASE REQUEST MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-2xl bg-[#0B0C14] border border-[#1E2030] rounded-2xl p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-[#1E2030] mb-4">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-purple-400" />
                <h3 className="text-base font-bold text-white">New Purchase & Parts Request</h3>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Request Title *</label>
                <input
                  type="text"
                  required
                  value={createForm.title}
                  onChange={(e) => setCreateForm(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="e.g. Replacement Chilled Water Actuator Valves for Lovelace"
                  className="w-full px-3 py-2 bg-[#0E101A] border border-[#1E2030] rounded-xl text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Operational Justification *</label>
                <textarea
                  rows={2}
                  required
                  value={createForm.justification}
                  onChange={(e) => setCreateForm(prev => ({ ...prev, justification: e.target.value }))}
                  placeholder="Explain why these items are required, equipment affected, or incident relation..."
                  className="w-full px-3 py-2 bg-[#0E101A] border border-[#1E2030] rounded-xl text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Department Scope</label>
                  <select
                    value={createForm.departmentId}
                    onChange={(e) => setCreateForm(prev => ({ ...prev, departmentId: e.target.value }))}
                    className="w-full px-3 py-2 bg-[#0E101A] border border-[#1E2030] rounded-xl text-white focus:outline-none focus:border-purple-500"
                  >
                    {departments.map(d => (
                      <option key={d.id} value={d.id}>{d.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Urgency</label>
                  <select
                    value={createForm.urgency}
                    onChange={(e) => setCreateForm(prev => ({ ...prev, urgency: e.target.value as any }))}
                    className="w-full px-3 py-2 bg-[#0E101A] border border-[#1E2030] rounded-xl text-white focus:outline-none focus:border-purple-500"
                  >
                    <option value="LOW">Low - Standard restocking</option>
                    <option value="NORMAL">Normal - Routine maintenance</option>
                    <option value="HIGH">High - Equipment offline</option>
                    <option value="EMERGENCY">Emergency - Campus safety / outage</option>
                  </select>
                </div>
              </div>

              {/* Line Items Section */}
              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between">
                  <label className="text-slate-300 font-bold block">Line Items *</label>
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="text-purple-400 hover:text-purple-300 font-semibold flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Add Line
                  </button>
                </div>

                {createForm.items.map((item, idx) => (
                  <div key={idx} className="p-3 rounded-xl bg-[#0E101A] border border-[#1E2030] flex flex-col md:flex-row gap-2 items-center">
                    <input
                      type="text"
                      required
                      placeholder="Item name / spec"
                      value={item.name}
                      onChange={(e) => handleItemChange(idx, 'name', e.target.value)}
                      className="flex-1 px-2.5 py-1.5 bg-[#0B0C14] border border-[#1E2030] rounded-lg text-white text-xs"
                    />
                    <input
                      type="text"
                      placeholder="Part # / SKU"
                      value={item.partNumber}
                      onChange={(e) => handleItemChange(idx, 'partNumber', e.target.value)}
                      className="w-28 px-2.5 py-1.5 bg-[#0B0C14] border border-[#1E2030] rounded-lg text-white text-xs font-mono"
                    />
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min="1"
                        placeholder="Qty"
                        value={item.quantity}
                        onChange={(e) => handleItemChange(idx, 'quantity', parseInt(e.target.value, 10) || 1)}
                        className="w-16 px-2 py-1.5 bg-[#0B0C14] border border-[#1E2030] rounded-lg text-white text-xs font-mono text-right"
                      />
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        placeholder="Unit $"
                        value={item.unitPrice}
                        onChange={(e) => handleItemChange(idx, 'unitPrice', parseFloat(e.target.value) || 0)}
                        className="w-24 px-2 py-1.5 bg-[#0B0C14] border border-[#1E2030] rounded-lg text-white text-xs font-mono text-right"
                      />
                      {createForm.items.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(idx)}
                          className="p-1.5 text-slate-500 hover:text-rose-400"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Total Summary */}
              <div className="p-3 rounded-xl bg-[#0E101A] border border-[#1E2030] flex items-center justify-between font-mono">
                <span className="text-slate-400">Estimated Total Commitment:</span>
                <span className="text-base font-extrabold text-white tabular-nums">
                  ${estimatedTotal.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#7B2CBF] to-[#9D4EDD] text-white font-bold hover:brightness-110 shadow-[0_0_12px_rgba(123,44,191,0.35)]"
                >
                  Submit Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DECISION MODAL (APPROVE / REJECT) */}
      {decisionModalItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-[#0B0C14] border border-[#1E2030] rounded-2xl p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-[#1E2030] mb-4">
              <div className="flex items-center gap-2">
                {decisionAction === 'APPROVE' ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                ) : (
                  <XCircle className="w-5 h-5 text-rose-400" />
                )}
                <h3 className="text-base font-bold text-white">
                  {decisionAction === 'APPROVE' ? 'Approve Purchase Request' : 'Reject Purchase Request'}
                </h3>
              </div>
              <button
                onClick={() => setDecisionModalItem(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-3 rounded-xl bg-[#0E101A] border border-[#1E2030]">
                <div className="flex justify-between font-mono text-[11px] text-purple-400 mb-1">
                  <span>{decisionModalItem.requestNumber}</span>
                  <span className="text-white font-bold">${decisionModalItem.totalAmount.toFixed(2)}</span>
                </div>
                <h4 className="font-bold text-white mb-1">{decisionModalItem.title}</h4>
                <p className="text-slate-400 text-[11px]">{decisionModalItem.justification}</p>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Decision Comments / Accounting Code *
                </label>
                <textarea
                  rows={3}
                  value={decisionComments}
                  onChange={(e) => setDecisionComments(e.target.value)}
                  placeholder={
                    decisionAction === 'APPROVE'
                      ? 'e.g. Approved under FY26 Academic Department Equipment Fund'
                      : 'e.g. Exceeds budget or existing spares available in warehouse'
                  }
                  className="w-full px-3 py-2 bg-[#0E101A] border border-[#1E2030] rounded-xl text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDecisionModalItem(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleDecisionSubmit}
                  className={`px-4 py-2 rounded-xl text-white font-bold transition-all ${
                    decisionAction === 'APPROVE'
                      ? 'bg-emerald-600 hover:bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                      : 'bg-rose-600 hover:bg-rose-500 shadow-[0_0_12px_rgba(244,63,94,0.3)]'
                  }`}
                >
                  Confirm {decisionAction === 'APPROVE' ? 'Approval' : 'Rejection'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
