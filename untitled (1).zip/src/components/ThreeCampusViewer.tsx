import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { Building, Floor } from '../types/campus';
import { 
  Compass, 
  Maximize2, 
  Minimize2, 
  RotateCw, 
  Layers, 
  ChevronRight, 
  X, 
  Sparkles,
  Zap,
  Wrench,
  DoorOpen,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  Flame,
  Info
} from 'lucide-react';

interface ThreeCampusViewerProps {
  buildings: Building[];
  selectedBuilding: Building | null;
  selectedFloor?: Floor | null;
  onSelectBuilding: (building: Building) => void;
  onDeselectBuilding: () => void;
  onSelectFloor?: (floor: Floor) => void;
  onOpenFloorPlan?: (building: Building, floor?: Floor) => void;
  onAddFloor?: (buildingId: string) => void;
  onRemoveFloor?: (buildingId: string) => void;
}

interface BuildingUserData {
  type: 'building' | 'floor';
  buildingId: string;
  floorIndex?: number;
}

export const ThreeCampusViewer: React.FC<ThreeCampusViewerProps> = ({
  buildings,
  selectedBuilding,
  selectedFloor,
  onSelectBuilding,
  onDeselectBuilding,
  onSelectFloor,
  onOpenFloorPlan,
  onAddFloor,
  onRemoveFloor
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [hoveredBuilding, setHoveredBuilding] = useState<Building | null>(null);
  const [mousePos, setMousePos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [autoRotate, setAutoRotate] = useState(false);
  const [selectedFloorIndex, setSelectedFloorIndex] = useState<number | null>(null);
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);
  const [transitionFloor, setTransitionFloor] = useState<Floor | null>(null);

  // Transition & Animation Guards
  const isTransitioningRef = useRef<boolean>(false);
  const scriptedAnimRef = useRef<{
    active: boolean;
    startTime: number;
    duration: number;
    startPos: THREE.Vector3;
    endPos: THREE.Vector3;
    startLook: THREE.Vector3;
    endLook: THREE.Vector3;
    onComplete?: () => void;
  } | null>(null);

  // Three.js internal references
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const reqIdRef = useRef<number | null>(null);

  // Interactive meshes map for raycasting
  const buildingMeshesRef = useRef<Map<string, THREE.Group>>(new Map());
  const interactiveHitBoxesRef = useRef<THREE.Mesh[]>([]);

  // Camera animation target state
  const cameraTargetRef = useRef<{
    pos: THREE.Vector3;
    look: THREE.Vector3;
    currentLook: THREE.Vector3;
    isAnimating: boolean;
  }>({
    pos: new THREE.Vector3(0, 80, 110),
    look: new THREE.Vector3(0, 4, 0),
    currentLook: new THREE.Vector3(0, 4, 0),
    isAnimating: false
  });

  // Orbit controls state
  const orbitRef = useRef<{
    isDragging: boolean;
    dragType: 'rotate' | 'pan';
    startX: number;
    startY: number;
    hasDragged: boolean;
    theta: number; // horizontal angle
    phi: number;   // vertical angle
    radius: number;
    center: THREE.Vector3;
  }>({
    isDragging: false,
    dragType: 'rotate',
    startX: 0,
    startY: 0,
    hasDragged: false,
    theta: Math.PI * 0.25,
    phi: Math.PI * 0.32,
    radius: 135,
    center: new THREE.Vector3(0, 4, 0)
  });

  // Default campus overview camera config
  const DEFAULT_CAM_POS = new THREE.Vector3(0, 85, 115);
  const DEFAULT_LOOK_AT = new THREE.Vector3(0, 4, 0);

  // Initialize Three.js Scene
  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;

    // 1. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x050507);
    scene.fog = new THREE.FogExp2(0x050507, 0.0035);

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.5, 1000);
    camera.position.copy(DEFAULT_CAM_POS);
    camera.lookAt(DEFAULT_LOOK_AT);
    cameraRef.current = camera;
    cameraTargetRef.current.pos.copy(DEFAULT_CAM_POS);
    cameraTargetRef.current.look.copy(DEFAULT_LOOK_AT);
    cameraTargetRef.current.currentLook.copy(DEFAULT_LOOK_AT);

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 4. Lighting System
    const ambientLight = new THREE.AmbientLight(0x131422, 1.8);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xe2f0ff, 2.4);
    dirLight.position.set(70, 110, 60);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    dirLight.shadow.camera.near = 10;
    dirLight.shadow.camera.far = 350;
    dirLight.shadow.camera.left = -90;
    dirLight.shadow.camera.right = 90;
    dirLight.shadow.camera.top = 90;
    dirLight.shadow.camera.bottom = -90;
    dirLight.shadow.bias = -0.0005;
    scene.add(dirLight);

    // Secondary fill light with Royal Amethyst tint
    const fillLight = new THREE.DirectionalLight(0x8b5cf6, 0.55);
    fillLight.position.set(-80, 40, -50);
    scene.add(fillLight);

    // Electric Cyan underglow / ground bounce
    const bounceLight = new THREE.DirectionalLight(0x00f5ff, 0.75);
    bounceLight.position.set(0, -30, 20);
    scene.add(bounceLight);

    // 5. Environment & Campus Terrain
    createCampusEnvironment(scene);

    // 6. Build the 3D Campus Buildings
    createCampusBuildings(scene, buildings);

    // 7. Render Loop with smooth lerping
    // 7. Render Loop with smooth lerping & scripted transitions
    const clock = new THREE.Clock();

    const animate = () => {
      reqIdRef.current = requestAnimationFrame(animate);
      const delta = clock.getDelta();

      // Check if a scripted camera animation is active (e.g., zooming to selected floor)
      const anim = scriptedAnimRef.current;
      if (anim && anim.active && cameraRef.current) {
        const elapsed = performance.now() - anim.startTime;
        const t = Math.min(1, elapsed / anim.duration);
        // Smooth easeInOutCubic curve
        const ease = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

        cameraRef.current.position.lerpVectors(anim.startPos, anim.endPos, ease);
        cameraTargetRef.current.currentLook.lerpVectors(anim.startLook, anim.endLook, ease);
        cameraRef.current.lookAt(cameraTargetRef.current.currentLook);

        if (t >= 1) {
          anim.active = false;
          cameraRef.current.position.copy(anim.endPos);
          cameraRef.current.lookAt(anim.endLook);
          cameraTargetRef.current.pos.copy(anim.endPos);
          cameraTargetRef.current.look.copy(anim.endLook);
          cameraTargetRef.current.currentLook.copy(anim.endLook);
          const cb = anim.onComplete;
          scriptedAnimRef.current = null;
          if (cb) cb();
        }
      } else {
        // Standard lerping for overview/orbit camera updates
        const ct = cameraTargetRef.current;
        if (cameraRef.current) {
          cameraRef.current.position.lerp(ct.pos, 0.075);
          ct.currentLook.lerp(ct.look, 0.08);
          cameraRef.current.lookAt(ct.currentLook);
        }

        // Handle auto rotation when not dragging & overview mode
        if (autoRotate && !orbitRef.current.isDragging && !selectedBuilding) {
          orbitRef.current.theta += delta * 0.12;
          updateCameraFromOrbit();
        }
      }

      // Animate subtle pulsing features (e.g. cyber obelisk, beacon lines)
      const time = clock.getElapsedTime();
      const pulseGroup = scene.getObjectByName('cyber-beacon');
      if (pulseGroup) {
        pulseGroup.rotation.y = time * 0.5;
        const beaconLight = scene.getObjectByName('beacon-point-light') as THREE.PointLight;
        if (beaconLight) {
          beaconLight.intensity = 2.5 + Math.sin(time * 3) * 0.8;
        }
      }

      renderer.render(scene, cameraRef.current!);
    };

    animate();

    // 8. Resize listener
    const handleResize = () => {
      if (!containerRef.current || !rendererRef.current || !cameraRef.current) return;
      const w = containerRef.current.clientWidth;
      const h = containerRef.current.clientHeight;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (reqIdRef.current) cancelAnimationFrame(reqIdRef.current);
      if (scriptedAnimRef.current) scriptedAnimRef.current = null;
      isTransitioningRef.current = false;
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Update buildings if list changes
  useEffect(() => {
    if (sceneRef.current) {
      createCampusBuildings(sceneRef.current, buildings);
    }
  }, [buildings]);

  // Sync selectedFloor prop with selectedFloorIndex
  useEffect(() => {
    if (selectedFloor) {
      setSelectedFloorIndex(selectedFloor.floorNumber);
    }
  }, [selectedFloor]);

  // Handle selectedBuilding prop changes: animate camera to target building or reset to campus
  useEffect(() => {
    if (!cameraRef.current) return;

    // Do not disrupt an active floor scripted transition
    if (scriptedAnimRef.current?.active) return;

    if (selectedBuilding && selectedBuilding.campusPosition) {
      const pos = selectedBuilding.campusPosition;
      // Focus on selected building
      cameraTargetRef.current.pos.set(pos.x + 24, 25, pos.z + 32);
      cameraTargetRef.current.look.set(pos.x, 6, pos.z);
      cameraTargetRef.current.isAnimating = true;

      // Update orbit controls center
      orbitRef.current.center.set(pos.x, 6, pos.z);
      orbitRef.current.radius = 45;
      if (selectedFloor) {
        setSelectedFloorIndex(selectedFloor.floorNumber);
      } else if (selectedBuilding.floors && selectedBuilding.floors.length > 0) {
        setSelectedFloorIndex(selectedBuilding.floors[0].floorNumber);
      }
    } else {
      // Return to campus overview
      cameraTargetRef.current.pos.copy(DEFAULT_CAM_POS);
      cameraTargetRef.current.look.copy(DEFAULT_LOOK_AT);
      cameraTargetRef.current.isAnimating = true;

      orbitRef.current.center.copy(DEFAULT_LOOK_AT);
      orbitRef.current.radius = 135;
      setSelectedFloorIndex(null);
    }
  }, [selectedBuilding]);

  // Smoothly animate camera toward selected floor with mathematically accurate heightPerFloor
  const handleSelectFloorWithAnimation = useCallback((floor: Floor) => {
    // Prevent multiple rapid clicks from triggering overlapping transitions
    if (isTransitioningRef.current || !selectedBuilding || !cameraRef.current) {
      return;
    }

    isTransitioningRef.current = true;
    setIsTransitioning(true);
    setSelectedFloorIndex(floor.floorNumber);
    setTransitionFloor(floor);

    const b = selectedBuilding;
    const pos = b.campusPosition || { x: 0, z: 0, width: 28, depth: 20, heightPerFloor: 3.8, rotation: 0 };
    const heightPerFloor = pos.heightPerFloor || 3.8;

    // Calculate vertical position using the building's actual heightPerFloor:
    // Base slab height = 0.8
    // Floor starts at: floorY = 0.8 + floor.floorNumber * heightPerFloor
    // Center of floor is at: floorCenterY = floorY + heightPerFloor * 0.5
    const floorY = 0.8 + floor.floorNumber * heightPerFloor;
    const floorCenterY = floorY + heightPerFloor * 0.5;

    const camera = cameraRef.current;
    const startPos = camera.position.clone();
    const startLook = cameraTargetRef.current.currentLook.clone();

    // Target look position at the center of the selected floor
    const targetLook = new THREE.Vector3(pos.x, floorCenterY, pos.z);

    // Target camera position: close-up view focused on the selected floor
    const bldgRot = pos.rotation || 0;
    const angle = bldgRot + 0.55;
    const camDist = 20;
    const targetPos = new THREE.Vector3(
      pos.x + Math.sin(angle) * camDist,
      floorCenterY + 6.5,
      pos.z + Math.cos(angle) * camDist
    );

    // Update orbit controls center and radius consistently
    orbitRef.current.center.copy(targetLook);
    orbitRef.current.radius = camDist;
    orbitRef.current.theta = angle;
    orbitRef.current.phi = Math.acos(6.5 / Math.hypot(camDist, 6.5));

    cameraTargetRef.current.pos.copy(targetPos);
    cameraTargetRef.current.look.copy(targetLook);

    // Animate smoothly over 1100ms
    scriptedAnimRef.current = {
      active: true,
      startTime: performance.now(),
      duration: 1100,
      startPos,
      endPos: targetPos,
      startLook,
      endLook: targetLook,
      onComplete: () => {
        isTransitioningRef.current = false;
        setIsTransitioning(false);
        setTransitionFloor(null);
        if (onSelectFloor) {
          onSelectFloor(floor);
        }
      }
    };
  }, [selectedBuilding, onSelectFloor]);

  // Update building highlights when hovered or selected changes
  useEffect(() => {
    buildingMeshesRef.current.forEach((group, id) => {
      const isSelected = selectedBuilding?.id === id;
      const isHovered = hoveredBuilding?.id === id;

      group.traverse((child) => {
        if ((child as THREE.Mesh).isMesh || (child as THREE.LineSegments).isLineSegments) {
          const mesh = child as THREE.Mesh;
          const role = mesh.userData.role;
          const floorIndex = mesh.userData.floorIndex;
          const isThisFloorSelected = isSelected && selectedFloorIndex !== null && floorIndex === selectedFloorIndex;

          if (role === 'outline') {
            const mat = mesh.material as THREE.LineBasicMaterial;
            if (isSelected) {
              mat.color.setHex(0x8b5cf6); // Royal Amethyst
              mat.linewidth = 2;
            } else if (isHovered) {
              mat.color.setHex(0x00f5ff); // Electric Cyan
            } else {
              mat.color.setHex(0x00a3cc); // Muted Cyan
            }
          }

          if (role === 'floor-trim') {
            const mat = mesh.material as THREE.LineBasicMaterial;
            if (isThisFloorSelected) {
              mat.color.setHex(0x8b5cf6);
            } else if (isSelected) {
              mat.color.setHex(0x00f5ff);
            } else {
              mat.color.setHex(0x006688);
            }
          }

          if (role === 'wall') {
            const mat = mesh.material as THREE.MeshStandardMaterial;
            if (isThisFloorSelected) {
              mat.emissive.setHex(0x4c1d95); // Royal Amethyst glow
              mat.emissiveIntensity = 0.85;
            } else if (isSelected) {
              mat.emissive.setHex(0x2e1065);
              mat.emissiveIntensity = 0.35;
            } else if (isHovered) {
              mat.emissive.setHex(0x083344);
              mat.emissiveIntensity = 0.35;
            } else {
              mat.emissive.setHex(0x000000);
              mat.emissiveIntensity = 0;
            }
          }

          if (role === 'column') {
            const mat = mesh.material as THREE.MeshStandardMaterial;
            if (isThisFloorSelected) {
              mat.emissive.setHex(0x00f5ff);
              mat.emissiveIntensity = 0.6;
            } else if (isSelected) {
              mat.emissive.setHex(0x004455);
              mat.emissiveIntensity = 0.2;
            } else {
              mat.emissive.setHex(0x000000);
              mat.emissiveIntensity = 0;
            }
          }

          if (role === 'classroom-space') {
            const mat = mesh.material as THREE.MeshStandardMaterial;
            if (isThisFloorSelected) {
              mat.emissive.setHex(0x3b0764);
              mat.emissiveIntensity = 0.7;
            } else if (isSelected) {
              mat.emissive.setHex(0x1e1b4b);
              mat.emissiveIntensity = 0.2;
            } else {
              mat.emissive.setHex(0x000000);
              mat.emissiveIntensity = 0;
            }
          }

          if (role === 'window') {
            const mat = mesh.material as THREE.MeshStandardMaterial;
            if (isThisFloorSelected) {
              mat.color.setHex(0x8b5cf6);
              mat.emissive.setHex(0x8b5cf6);
              mat.emissiveIntensity = 1.35;
            } else if (isSelected) {
              mat.color.setHex(0xa855f7);
              mat.emissive.setHex(0x8b5cf6);
              mat.emissiveIntensity = 0.6;
            } else if (isHovered) {
              mat.color.setHex(0x22d3ee);
              mat.emissive.setHex(0x00f5ff);
              mat.emissiveIntensity = 0.7;
            } else {
              mat.color.setHex(0x00c4e6);
              mat.emissive.setHex(0x005577);
              mat.emissiveIntensity = 0.45;
            }
          }
        }
      });
    });
  }, [hoveredBuilding, selectedBuilding, selectedFloorIndex]);

  // Helper to recompute camera position based on spherical coordinates
  const updateCameraFromOrbit = useCallback(() => {
    const o = orbitRef.current;
    const x = o.center.x + o.radius * Math.sin(o.phi) * Math.sin(o.theta);
    const y = o.center.y + o.radius * Math.cos(o.phi);
    const z = o.center.z + o.radius * Math.sin(o.phi) * Math.cos(o.theta);

    cameraTargetRef.current.pos.set(x, y, z);
    cameraTargetRef.current.look.copy(o.center);
  }, []);

  // Raycast helper to find which building and floor was hovered/clicked
  const performRaycast = (clientX: number, clientY: number): { building: Building; floorIndex?: number } | null => {
    if (!containerRef.current || !cameraRef.current) return null;
    const rect = containerRef.current.getBoundingClientRect();
    const mouse = new THREE.Vector2(
      ((clientX - rect.left) / rect.width) * 2 - 1,
      -((clientY - rect.top) / rect.height) * 2 + 1
    );

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(mouse, cameraRef.current);

    const intersects = raycaster.intersectObjects(interactiveHitBoxesRef.current, false);
    if (intersects.length > 0) {
      const hit = intersects[0].object;
      const bId = hit.userData.buildingId;
      const bldg = buildings.find((b) => b.id === bId) || null;
      if (!bldg) return null;

      if (hit.userData.type === 'floor' && hit.userData.floorIndex !== undefined) {
        return { building: bldg, floorIndex: hit.userData.floorIndex };
      }

      // Compute floor index from intersection point height
      const pos = bldg.campusPosition || { x: 0, z: 0, width: 28, depth: 20, heightPerFloor: 3.8 };
      const floorH = pos.heightPerFloor || 3.8;
      const relY = intersects[0].point.y - 0.8;
      const computedFloorIdx = Math.max(0, Math.min(bldg.floorsCount - 1, Math.floor(relY / floorH)));

      return { building: bldg, floorIndex: computedFloorIdx };
    }
    return null;
  };

  // Mouse interaction handlers with transition lock guards
  const handlePointerDown = (e: React.PointerEvent) => {
    if (isTransitioningRef.current) return;
    if (e.button !== 0 && e.button !== 2) return;
    const o = orbitRef.current;
    o.isDragging = true;
    o.dragType = e.button === 2 || e.shiftKey ? 'pan' : 'rotate';
    o.startX = e.clientX;
    o.startY = e.clientY;
    o.hasDragged = false;
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (isTransitioningRef.current) return;
    const o = orbitRef.current;
    setMousePos({ x: e.clientX, y: e.clientY });

    if (o.isDragging) {
      const dx = e.clientX - o.startX;
      const dy = e.clientY - o.startY;

      if (Math.hypot(dx, dy) > 4) {
        o.hasDragged = true;
      }

      if (o.dragType === 'rotate') {
        o.theta -= dx * 0.007;
        o.phi = Math.max(0.12, Math.min(Math.PI / 2 - 0.05, o.phi - dy * 0.007));
        updateCameraFromOrbit();
      } else {
        // Pan
        const panSpeed = 0.08 * (o.radius / 100);
        o.center.x -= dx * panSpeed;
        o.center.z -= dy * panSpeed;
        updateCameraFromOrbit();
      }

      o.startX = e.clientX;
      o.startY = e.clientY;
    } else {
      // Hover detection
      const hitResult = performRaycast(e.clientX, e.clientY);
      const hitBuilding = hitResult?.building || null;
      if (hitBuilding !== hoveredBuilding) {
        setHoveredBuilding(hitBuilding);
      }
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    const o = orbitRef.current;
    if (isTransitioningRef.current) {
      o.isDragging = false;
      return;
    }
    if (o.isDragging && !o.hasDragged) {
      // Considered a click!
      const hitResult = performRaycast(e.clientX, e.clientY);
      if (hitResult) {
        if (!selectedBuilding || selectedBuilding.id !== hitResult.building.id) {
          onSelectBuilding(hitResult.building);
        } else if (hitResult.floorIndex !== undefined) {
          // Building is already focused, user clicked a specific floor
          const targetFloor = hitResult.building.floors[hitResult.floorIndex];
          if (targetFloor) {
            handleSelectFloorWithAnimation(targetFloor);
          }
        }
      } else {
        // Clicked ground outside any building
        if (selectedBuilding && !isTransitioningRef.current) {
          onDeselectBuilding();
        }
      }
    }
    o.isDragging = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const o = orbitRef.current;
    const zoomFactor = e.deltaY > 0 ? 1.08 : 0.92;
    o.radius = Math.max(22, Math.min(220, o.radius * zoomFactor));
    updateCameraFromOrbit();
  };

  // Reset to full campus overview
  const handleResetOverview = () => {
    onDeselectBuilding();
    orbitRef.current.center.copy(DEFAULT_LOOK_AT);
    orbitRef.current.radius = 135;
    orbitRef.current.theta = Math.PI * 0.25;
    orbitRef.current.phi = Math.PI * 0.32;
    cameraTargetRef.current.pos.copy(DEFAULT_CAM_POS);
    cameraTargetRef.current.look.copy(DEFAULT_LOOK_AT);
  };

  const handleZoomIn = () => {
    const o = orbitRef.current;
    o.radius = Math.max(22, o.radius * 0.85);
    updateCameraFromOrbit();
  };

  const handleZoomOut = () => {
    const o = orbitRef.current;
    o.radius = Math.min(220, o.radius * 1.15);
    updateCameraFromOrbit();
  };

  return (
    <div className="relative w-full h-full select-none overflow-hidden bg-[#050507]">
      {/* 3D Canvas Container */}
      <div
        ref={containerRef}
        className={`w-full h-full cursor-grab ${orbitRef.current.isDragging ? 'cursor-grabbing' : hoveredBuilding ? 'cursor-pointer' : ''}`}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onWheel={handleWheel}
        onContextMenu={(e) => e.preventDefault()}
      />

      {/* Top Floating Breadcrumb & Control Bar */}
      <div className="absolute top-4 left-4 z-20 flex items-center gap-2">
        <div className="flex items-center bg-[#07080D]/90 backdrop-blur-md border border-[#1E2030] rounded-xl px-4 py-2 shadow-2xl text-xs font-medium text-[#F8FAFC]">
          <button
            onClick={handleResetOverview}
            className="flex items-center gap-1.5 text-slate-400 hover:text-[#00F5FF] transition-colors cursor-pointer"
          >
            <Compass className="w-3.5 h-3.5 text-[#00F5FF]" />
            <span>Campus Overview</span>
          </button>

          {selectedBuilding && (
            <>
              <ChevronRight className="w-3.5 h-3.5 text-slate-600 mx-1" />
              <span className="text-[#A78BFA] font-semibold flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#8B5CF6] animate-pulse" />
                {selectedBuilding.name} ({selectedBuilding.code})
              </span>
            </>
          )}

          {selectedFloorIndex !== null && selectedBuilding && (
            <>
              <ChevronRight className="w-3.5 h-3.5 text-slate-600 mx-1" />
              <span className="text-[#00F5FF] font-semibold">
                Floor {selectedFloorIndex}
              </span>
            </>
          )}
        </div>

        {selectedBuilding && (
          <button
            onClick={handleResetOverview}
            disabled={isTransitioning}
            className="p-2 rounded-xl bg-[#07080D]/90 backdrop-blur-md border border-[#1E2030] text-slate-400 hover:text-white hover:border-[#8B5CF6]/50 transition-all cursor-pointer shadow-lg disabled:opacity-50"
            title="Return to campus overview"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Active Floor Transition Floating HUD */}
      {isTransitioning && transitionFloor && (
        <div className="absolute top-18 left-1/2 transform -translate-x-1/2 z-30 flex items-center gap-3 px-4 py-2.5 rounded-2xl bg-[#07080D]/95 backdrop-blur-xl border border-[#8B5CF6]/60 shadow-[0_0_30px_rgba(139,92,246,0.4)] text-xs text-white">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#8B5CF6] opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#8B5CF6]"></span>
          </span>
          <div className="flex flex-col">
            <span className="font-bold text-white tracking-wide">
              Focusing on Level {transitionFloor.floorNumber}: {transitionFloor.name}
            </span>
            <span className="text-[10px] text-[#00F5FF] font-mono">
              Gliding 3D camera to floor elevation • Opening 2D Blueprint...
            </span>
          </div>
        </div>
      )}

      {/* Top Right Quick Actions & Camera Controls */}
      <div className="absolute top-4 right-4 z-20 flex flex-col gap-2">
        <div className="flex items-center gap-1.5 bg-[#07080D]/90 backdrop-blur-md border border-[#1E2030] rounded-xl p-1.5 shadow-2xl">
          <button
            onClick={() => setAutoRotate(!autoRotate)}
            disabled={isTransitioning}
            className={`p-2 rounded-lg transition-colors cursor-pointer text-xs flex items-center gap-1.5 ${
              autoRotate ? 'bg-[#8B5CF6]/20 text-[#A78BFA] border border-[#8B5CF6]/40' : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
            title="Toggle Campus Orbit"
          >
            <RotateCw className={`w-3.5 h-3.5 ${autoRotate ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Orbit</span>
          </button>

          <div className="w-[1px] h-4 bg-slate-800" />

          <button
            onClick={handleZoomIn}
            disabled={isTransitioning}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800/50 rounded-lg transition-colors cursor-pointer"
            title="Zoom In"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={handleZoomOut}
            disabled={isTransitioning}
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800/50 rounded-lg transition-colors cursor-pointer"
            title="Zoom Out"
          >
            <Minimize2 className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={handleResetOverview}
            disabled={isTransitioning}
            className="p-2 text-slate-400 hover:text-[#00F5FF] hover:bg-slate-800/50 rounded-lg transition-colors cursor-pointer"
            title="Reset to Full Campus"
          >
            <Compass className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Floating Hover Tooltip (When hovering buildings in overview) */}
      {hoveredBuilding && !selectedBuilding && !isTransitioning && (
        <div
          className="fixed pointer-events-none z-30 transform -translate-x-1/2 -translate-y-full mb-3 px-3.5 py-2.5 rounded-xl bg-[#07080D]/95 backdrop-blur-md border border-[#00F5FF]/50 shadow-2xl shadow-[#00F5FF]/20 text-xs text-white"
          style={{
            left: `${mousePos.x}px`,
            top: `${mousePos.y - 12}px`
          }}
        >
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2 h-2 rounded-full bg-[#00F5FF] shadow-[0_0_8px_#00F5FF]" />
            <span className="font-bold text-white">{hoveredBuilding.name}</span>
            <span className="px-1.5 py-0.5 rounded text-[10px] bg-[#1E2030] text-[#00F5FF] font-mono">
              {hoveredBuilding.code}
            </span>
          </div>
          <div className="flex items-center gap-3 text-slate-400 text-[11px] mt-1">
            <span>{hoveredBuilding.floorsCount} Floors</span>
            <span>•</span>
            <span>{hoveredBuilding.classroomsCount} Classrooms</span>
            <span>•</span>
            <span className="text-emerald-400 font-medium">{hoveredBuilding.status}</span>
          </div>
          <div className="mt-1 text-[10px] text-slate-500 italic">
            Click to zoom in and inspect building
          </div>
        </div>
      )}

      {/* Floating Building Detail Card (When a building is selected) */}
      {selectedBuilding && (
        <div className="absolute left-4 bottom-24 md:bottom-20 z-20 w-84 sm:w-96 max-w-[calc(100vw-2rem)] rounded-2xl bg-[#080910]/95 backdrop-blur-xl border border-[#1E2030] shadow-[0_12px_40px_rgba(0,0,0,0.9)] p-5 text-[#F8FAFC] transition-all">
          {/* Header */}
          <div className="flex items-start justify-between gap-3 mb-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 rounded text-[10px] font-mono tracking-wider font-semibold bg-[#8B5CF6]/20 text-[#A78BFA] border border-[#8B5CF6]/30">
                  {selectedBuilding.code}
                </span>
                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium ${
                  selectedBuilding.status === 'Operational' 
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                }`}>
                  <ShieldCheck className="w-3 h-3" />
                  {selectedBuilding.status}
                </span>
              </div>
              <h3 className="text-lg font-bold text-white leading-tight">
                {selectedBuilding.name}
              </h3>
              <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                {selectedBuilding.description}
              </p>
            </div>
            <button
              onClick={handleResetOverview}
              disabled={isTransitioning}
              className="text-slate-500 hover:text-white p-1 rounded-lg hover:bg-slate-800/50 cursor-pointer disabled:opacity-50"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Metric Grid */}
          <div className="grid grid-cols-4 gap-2 mb-4 py-2 border-y border-[#1E2030]/80 text-center">
            <div className="bg-[#0D0E16] p-2 rounded-lg border border-[#1E2030]/60">
              <span className="text-[10px] text-slate-400 block">Floors</span>
              <span className="text-sm font-bold text-white font-mono">{selectedBuilding.floorsCount}</span>
            </div>
            <div className="bg-[#0D0E16] p-2 rounded-lg border border-[#1E2030]/60">
              <span className="text-[10px] text-slate-400 block">Rooms</span>
              <span className="text-sm font-bold text-white font-mono">{selectedBuilding.classroomsCount}</span>
            </div>
            <div className="bg-[#0D0E16] p-2 rounded-lg border border-[#1E2030]/60">
              <span className="text-[10px] text-slate-400 block">Assets</span>
              <span className="text-sm font-bold text-[#00F5FF] font-mono">{selectedBuilding.equipmentCount}</span>
            </div>
            <div className="bg-[#0D0E16] p-2 rounded-lg border border-[#1E2030]/60">
              <span className="text-[10px] text-slate-400 block">Issues</span>
              <span className={`text-sm font-bold font-mono ${
                selectedBuilding.openMaintenanceCount > 0 ? 'text-[#8B5CF6]' : 'text-emerald-400'
              }`}>
                {selectedBuilding.openMaintenanceCount}
              </span>
            </div>
          </div>

          {/* Floor Quick Switcher & Dynamic Floor Configuration */}
          <div className="mb-4">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-[#00F5FF]" />
                Building Floors
              </span>
              <div className="flex items-center gap-1">
                {onRemoveFloor && selectedBuilding.floors.length > 1 && (
                  <button
                    onClick={() => onRemoveFloor(selectedBuilding.id)}
                    disabled={isTransitioning}
                    className="px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-[#1A1B28] hover:bg-rose-950/50 text-slate-300 hover:text-rose-400 border border-[#25283D] hover:border-rose-500/40 transition-colors cursor-pointer disabled:opacity-50"
                    title="Remove top floor from this building"
                  >
                    - Floor
                  </button>
                )}
                {onAddFloor && (
                  <button
                    onClick={() => onAddFloor(selectedBuilding.id)}
                    disabled={isTransitioning}
                    className="px-2 py-0.5 rounded text-[10px] font-mono font-medium bg-[#00F5FF]/15 hover:bg-[#00F5FF]/25 text-[#00F5FF] border border-[#00F5FF]/40 transition-colors flex items-center gap-1 cursor-pointer disabled:opacity-50"
                    title="Add new floor to this building"
                  >
                    <span>+ Floor</span>
                  </button>
                )}
                <span className="text-[11px] text-slate-400 ml-1 font-mono font-medium">
                  {selectedBuilding.floors.length} levels
                </span>
              </div>
            </div>

            {/* Grid of All Available Floors */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 max-h-40 overflow-y-auto pr-0.5">
              {selectedBuilding.floors.map((fl, idx) => {
                const isSelected = selectedFloorIndex === fl.floorNumber || (selectedFloorIndex === null && idx === 0);
                return (
                  <button
                    key={fl.id}
                    disabled={isTransitioning}
                    onClick={() => handleSelectFloorWithAnimation(fl)}
                    className={`py-2 px-2.5 rounded-lg text-xs font-medium transition-all cursor-pointer border text-left flex flex-col justify-between ${
                      isSelected
                        ? 'bg-[#8B5CF6]/25 border-[#8B5CF6] text-white shadow-[0_0_12px_rgba(139,92,246,0.3)] font-semibold'
                        : 'bg-[#0E0F18] border-[#1E2030] text-slate-300 hover:border-slate-500 hover:bg-[#161726]'
                    } ${isTransitioning ? 'cursor-not-allowed opacity-80' : ''}`}
                  >
                    <div className="text-[10px] text-slate-400 flex items-center justify-between mb-1">
                      <span className="font-mono font-semibold text-[#00F5FF]">L{fl.floorNumber}</span>
                      {isTransitioning && selectedFloorIndex === fl.floorNumber && (
                        <span className="w-1.5 h-1.5 rounded-full bg-[#8B5CF6] animate-ping" />
                      )}
                    </div>
                    <div className="truncate font-semibold text-[11px] text-slate-200">
                      {fl.name}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Primary Action Button: Explore Floors (Triggers 2D Architectural Explorer) */}
          <div className="flex items-center gap-2">
            <button
              disabled={isTransitioning}
              onClick={() => {
                const targetFloor = (selectedFloorIndex !== null && selectedBuilding.floors.find(f => f.floorNumber === selectedFloorIndex))
                  ? selectedBuilding.floors.find(f => f.floorNumber === selectedFloorIndex)!
                  : selectedBuilding.floors[0];
                handleSelectFloorWithAnimation(targetFloor);
              }}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#7B2CBF] to-[#8B5CF6] text-white text-xs font-semibold hover:brightness-110 active:scale-[0.98] transition-all shadow-[0_0_20px_rgba(139,92,246,0.35)] cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed"
            >
              <DoorOpen className="w-4 h-4" />
              <span>{isTransitioning ? 'Focusing on Floor Elevation...' : 'Explore Floor Plans & Rooms'}</span>
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </button>
          </div>
        </div>
      )}

      {/* Bottom Buildings Quick Selector Dock (Positioned above mobile navigation dock) */}
      <div className="absolute bottom-20 md:bottom-4 left-1/2 transform -translate-x-1/2 z-20 flex items-center gap-2 bg-[#07080D]/95 backdrop-blur-md border border-[#1E2030] rounded-2xl p-2 shadow-2xl max-w-[calc(100vw-2rem)] overflow-x-auto no-scrollbar">
        <button
          onClick={handleResetOverview}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer shrink-0 ${
            !selectedBuilding
              ? 'bg-[#00F5FF] text-slate-950 font-bold shadow-[0_0_15px_rgba(0,245,255,0.4)]'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
          }`}
        >
          <Compass className="w-3.5 h-3.5" />
          <span>Full Campus</span>
        </button>

        <div className="w-[1px] h-4 bg-slate-800 shrink-0" />

        {buildings.map((b) => {
          const isSelected = selectedBuilding?.id === b.id;
          return (
            <button
              key={b.id}
              onClick={() => onSelectBuilding(b)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium transition-all cursor-pointer shrink-0 ${
                isSelected
                  ? 'bg-[#8B5CF6] text-white shadow-[0_0_15px_rgba(139,92,246,0.4)] font-bold'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${isSelected ? 'bg-white' : 'bg-[#00F5FF]'}`} />
              <span className="hidden md:inline">{b.name}</span>
              <span className="md:hidden font-mono">{b.code}</span>
            </button>
          );
        })}
      </div>

      {/* Cyber Grid Overlay / Compass Indicator */}
      <div className="absolute right-4 bottom-20 md:bottom-4 z-10 pointer-events-none hidden lg:flex flex-col items-end text-[10px] text-slate-500 font-mono">
        <div className="flex items-center gap-1 text-[#00F5FF]">
          <span className="w-1.5 h-1.5 rounded-full bg-[#00F5FF] animate-ping" />
          <span>3D UNIFIED SYSTEM • ACTIVE</span>
        </div>
        <span>COORD: 34.0522° N, 118.2437° W</span>
        <span>RENDERER: WEBGL2 / ACES FILMIC</span>
      </div>
    </div>
  );

  // -------------------------------------------------------------
  // THREE.JS SCENE PROCEDURAL BUILDERS
  // -------------------------------------------------------------

  function createCampusEnvironment(scene: THREE.Scene) {
    // Ground plane with custom dark cyberpunk aesthetic
    const groundGeo = new THREE.PlaneGeometry(280, 240, 32, 32);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x0c0d12,
      roughness: 0.85,
      metalness: 0.15
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    ground.name = 'campus-terrain';
    scene.add(ground);

    // Subtle technological grid lines across terrain
    const gridHelper = new THREE.GridHelper(260, 52, 0x00f5ff, 0x141524);
    gridHelper.position.y = 0.05;
    (gridHelper.material as THREE.Material).opacity = 0.35;
    (gridHelper.material as THREE.Material).transparent = true;
    scene.add(gridHelper);

    // Main Campus Roads matching EEC Blueprint
    createRoads(scene);

    // EEC Main Entrance Gate Archway
    createEecMainGate(scene);

    // Playgrounds 1 and 2
    createPlaygrounds(scene);

    // Central Lawn & Landscaping Trees
    createCentralLawnAndTrees(scene);
  }

  function createRoads(scene: THREE.Scene) {
    const roadMat = new THREE.MeshStandardMaterial({
      color: 0x14151c,
      roughness: 0.9,
      metalness: 0.1
    });

    const roadLineMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.75
    });

    const arrowMat = new THREE.MeshBasicMaterial({
      color: 0x10b981, // Emerald green directional arrow
      transparent: true,
      opacity: 0.9
    });

    // 1. Main North-South Entrance Highway (from EEC Main Gate up to North edge)
    const northSouthRoad = new THREE.Mesh(new THREE.PlaneGeometry(14, 110), roadMat);
    northSouthRoad.rotation.x = -Math.PI / 2;
    northSouthRoad.position.set(38, 0.08, 0);
    northSouthRoad.receiveShadow = true;
    scene.add(northSouthRoad);

    // Center divider dash on North-South road
    const nsLine = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 106), roadLineMat);
    nsLine.rotation.x = -Math.PI / 2;
    nsLine.position.set(38, 0.09, 0);
    scene.add(nsLine);

    // 2. Trans-Campus Connecting Roadway (curving West around Central Lawn)
    const westCrossRoad = new THREE.Mesh(new THREE.PlaneGeometry(86, 12), roadMat);
    westCrossRoad.rotation.x = -Math.PI / 2;
    westCrossRoad.position.set(-5, 0.08, -16);
    westCrossRoad.receiveShadow = true;
    scene.add(westCrossRoad);

    // Curved turn linking Main Gate Road to West Cross Road
    const turnRoad = new THREE.Mesh(new THREE.PlaneGeometry(16, 26), roadMat);
    turnRoad.rotation.x = -Math.PI / 2;
    turnRoad.position.set(32, 0.08, -14);
    scene.add(turnRoad);

    // 3. West feeder to Academic Block & Main Block
    const westFeederRoad = new THREE.Mesh(new THREE.PlaneGeometry(12, 44), roadMat);
    westFeederRoad.rotation.x = -Math.PI / 2;
    westFeederRoad.position.set(-42, 0.08, -16);
    westFeederRoad.receiveShadow = true;
    scene.add(westFeederRoad);

    // 4. Directional Route Indicators (Green Arrows like in Blueprint)
    for (let i = 0; i < 4; i++) {
      const arrowGeo = new THREE.ConeGeometry(0.8, 2.2, 3);
      const arrowMesh = new THREE.Mesh(arrowGeo, arrowMat);
      arrowMesh.rotation.x = -Math.PI / 2;
      arrowMesh.rotation.z = Math.PI; // pointing North
      arrowMesh.position.set(38, 0.12, 30 - i * 16);
      scene.add(arrowMesh);
    }

    // Directional curve arrows heading West
    for (let j = 0; j < 3; j++) {
      const arrowGeo = new THREE.ConeGeometry(0.8, 2.2, 3);
      const arrowMesh = new THREE.Mesh(arrowGeo, arrowMat);
      arrowMesh.rotation.x = -Math.PI / 2;
      arrowMesh.rotation.z = Math.PI / 2; // pointing West
      arrowMesh.position.set(20 - j * 20, 0.12, -16);
      scene.add(arrowMesh);
    }
  }

  function createEecMainGate(scene: THREE.Scene) {
    const gateGroup = new THREE.Group();
    gateGroup.position.set(38, 0, 48);

    const pillarMat = new THREE.MeshStandardMaterial({
      color: 0xd4af37, // Golden stone aesthetic
      roughness: 0.35,
      metalness: 0.4
    });

    const beamMat = new THREE.MeshStandardMaterial({
      color: 0x0f382c, // Dark emerald green banner
      roughness: 0.4,
      metalness: 0.5
    });

    // Left and Right Archway Pillars
    [-7, 7].forEach(offset => {
      const pillar = new THREE.Mesh(new THREE.BoxGeometry(2.4, 9, 2.4), pillarMat);
      pillar.position.set(offset, 4.5, 0);
      pillar.castShadow = true;
      gateGroup.add(pillar);

      // Capital atop pillar
      const cap = new THREE.Mesh(new THREE.BoxGeometry(3.2, 1, 3.2), pillarMat);
      cap.position.set(offset, 9.4, 0);
      gateGroup.add(cap);

      // Lantern on top
      const lantern = new THREE.PointLight(0xffea9f, 2.2, 16);
      lantern.position.set(offset, 10.5, 0);
      gateGroup.add(lantern);
    });

    // Cross Arch Beam
    const crossBeam = new THREE.Mesh(new THREE.BoxGeometry(17, 2.6, 2.2), beamMat);
    crossBeam.position.set(0, 8.8, 0);
    crossBeam.castShadow = true;
    gateGroup.add(crossBeam);

    // Archway Crown
    const crown = new THREE.Mesh(new THREE.CylinderGeometry(7, 7, 1.8, 16, 1, false, 0, Math.PI), pillarMat);
    crown.rotation.z = Math.PI;
    crown.position.set(0, 9.8, 0);
    gateGroup.add(crown);

    // 3D Gate Text Billboard
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 128;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = '#0a2318';
      ctx.roundRect(10, 10, 492, 108, 16);
      ctx.fill();
      ctx.lineWidth = 4;
      ctx.strokeStyle = '#d4af37';
      ctx.stroke();

      ctx.fillStyle = '#ffd700';
      ctx.font = 'bold 36px "Plus Jakarta Sans", sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('EEC MAIN GATE', 256, 72);

      const tex = new THREE.CanvasTexture(canvas);
      const spriteMat = new THREE.SpriteMaterial({ map: tex, transparent: true });
      const sprite = new THREE.Sprite(spriteMat);
      sprite.scale.set(13, 3.4, 1);
      sprite.position.set(0, 9, 1.6);
      gateGroup.add(sprite);
    }

    scene.add(gateGroup);
  }

  function createPlaygrounds(scene: THREE.Scene) {
    const courtMat = new THREE.MeshStandardMaterial({
      color: 0xdf8453, // Warm terracotta orange court surface
      roughness: 0.75,
      metalness: 0.1
    });

    const lineMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.9
    });

    // --- PLAYGROUND 1 (East side next to road and central lawn) ---
    const p1Group = new THREE.Group();
    p1Group.position.set(32, 0.1, 2);

    const p1Base = new THREE.Mesh(new THREE.BoxGeometry(18, 0.25, 20), courtMat);
    p1Base.receiveShadow = true;
    p1Group.add(p1Base);

    // Outer boundary line
    const p1Boundary = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.BoxGeometry(16.5, 0.28, 18.5)),
      lineMat
    );
    p1Group.add(p1Boundary);

    // Floating label: PLAYGROUND 1
    createGroundLabel(p1Group, 'PLAYGROUND 1', 0, 1.2, 0, '#ea580c');
    scene.add(p1Group);

    // --- PLAYGROUND 2 (North-West between Main Block and Admin Block) ---
    const p2Group = new THREE.Group();
    p2Group.position.set(-12, 0.1, -36);

    const p2Base = new THREE.Mesh(new THREE.BoxGeometry(16, 0.25, 16), courtMat);
    p2Base.receiveShadow = true;
    p2Group.add(p2Base);

    const p2Boundary = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.BoxGeometry(14.5, 0.28, 14.5)),
      lineMat
    );
    p2Group.add(p2Boundary);

    // Floating label: PLAYGROUND 2
    createGroundLabel(p2Group, 'PLAYGROUND 2', 0, 1.2, 0, '#ea580c');
    scene.add(p2Group);
  }

  function createGroundLabel(parent: THREE.Group, text: string, x: number, y: number, z: number, color: string) {
    const canvas = document.createElement('canvas');
    canvas.width = 384;
    canvas.height = 96;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = 'rgba(15, 18, 25, 0.92)';
    ctx.roundRect(8, 8, 368, 80, 16);
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = color;
    ctx.stroke();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 26px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(text, 192, 54);

    const texture = new THREE.CanvasTexture(canvas);
    const spriteMat = new THREE.SpriteMaterial({ map: texture, transparent: true });
    const sprite = new THREE.Sprite(spriteMat);
    sprite.scale.set(9, 2.3, 1);
    sprite.position.set(x, y, z);
    parent.add(sprite);
  }

  function createCentralLawnAndTrees(scene: THREE.Scene) {
    // Large central open green lawn as shown on EEC blueprint
    const lawnMat = new THREE.MeshStandardMaterial({
      color: 0x18422e, // Lush emerald lawn
      roughness: 0.85,
      metalness: 0.05
    });

    const centralLawn = new THREE.Mesh(new THREE.BoxGeometry(46, 0.25, 34), lawnMat);
    centralLawn.position.set(-6, 0.12, 4);
    centralLawn.receiveShadow = true;
    scene.add(centralLawn);

    // Perimeter jogging track / path around central lawn
    const trackMat = new THREE.MeshStandardMaterial({
      color: 0x3d271d, // Terracotta red clay track
      roughness: 0.8
    });
    const track = new THREE.Mesh(new THREE.BoxGeometry(49, 0.18, 37), trackMat);
    track.position.set(-6, 0.09, 4);
    scene.add(track);

    // Landscaped trees positioned around perimeter matching blueprint
    const treePositions = [
      // Along West road border
      { x: -30, z: 22 },
      { x: -30, z: 12 },
      { x: -30, z: -2 },
      { x: -30, z: -14 },
      // North of Main Block
      { x: -48, z: -48 },
      { x: -48, z: -38 },
      { x: -48, z: -28 },
      // Between Playground 1 and East border
      { x: 44, z: 12 },
      { x: 44, z: 2 },
      { x: 44, z: -8 },
      { x: 22, z: 12 },
      { x: 22, z: -8 },
      // Near Mechanical Block & Entrance Gate
      { x: 12, z: 46 },
      { x: 22, z: 46 }
    ];

    treePositions.forEach(p => {
      createCyberTree(scene, p.x, p.z);
    });
  }

  function createCyberTree(scene: THREE.Scene, x: number, z: number) {
    const treeGroup = new THREE.Group();
    treeGroup.position.set(x, 0, z);

    // Trunk
    const trunkGeo = new THREE.CylinderGeometry(0.3, 0.45, 3.2, 5);
    const trunkMat = new THREE.MeshStandardMaterial({
      color: 0x1f232b,
      roughness: 0.9
    });
    const trunk = new THREE.Mesh(trunkGeo, trunkMat);
    trunk.position.y = 1.6;
    trunk.castShadow = true;
    treeGroup.add(trunk);

    // Low-poly faceted canopy
    const foliageGeo = new THREE.ConeGeometry(2.1, 4.5, 6);
    const foliageMat = new THREE.MeshStandardMaterial({
      color: 0x0f402c,
      emissive: 0x005533,
      emissiveIntensity: 0.25,
      roughness: 0.6,
      flatShading: true
    });
    const foliage = new THREE.Mesh(foliageGeo, foliageMat);
    foliage.position.y = 4.4;
    foliage.castShadow = true;
    treeGroup.add(foliage);

    scene.add(treeGroup);
  }

  function createParkingArea(scene: THREE.Scene) {
    // Located near Turing Engineering Hub (east quad, around x: 74, z: 14)
    const parkingMat = new THREE.MeshStandardMaterial({
      color: 0x111219,
      roughness: 0.85
    });
    const parkingLot = new THREE.Mesh(new THREE.BoxGeometry(20, 0.2, 28), parkingMat);
    parkingLot.position.set(74, 0.1, 14);
    parkingLot.receiveShadow = true;
    scene.add(parkingLot);

    // Parked cyber transport vehicles
    const carColors = [0x007ba7, 0xff2e88, 0x475569, 0x0284c7, 0x1e293b];
    for (let row = 0; row < 4; row++) {
      for (let side = -1; side <= 1; side += 2) {
        if (Math.random() > 0.25) {
          const carGroup = new THREE.Group();
          const bodyGeo = new THREE.BoxGeometry(2.4, 1.2, 4.2);
          const bodyMat = new THREE.MeshStandardMaterial({
            color: carColors[(row + side + 10) % carColors.length],
            metalness: 0.7,
            roughness: 0.3
          });
          const body = new THREE.Mesh(bodyGeo, bodyMat);
          body.position.y = 0.7;
          body.castShadow = true;
          carGroup.add(body);

          // Headlights
          const lightGeo = new THREE.BoxGeometry(1.8, 0.2, 0.2);
          const lightMat = new THREE.MeshBasicMaterial({ color: 0x00d2ff });
          const light = new THREE.Mesh(lightGeo, lightMat);
          light.position.set(0, 0.7, side > 0 ? 2.15 : -2.15);
          carGroup.add(light);

          carGroup.position.set(74 + side * 5, 0.1, 4 + row * 6);
          scene.add(carGroup);
        }
      }
    }
  }

  function createCampusBuildings(scene: THREE.Scene, bldgs: Building[]) {
    // Clear previous building meshes
    buildingMeshesRef.current.forEach((g) => scene.remove(g));
    buildingMeshesRef.current.clear();
    interactiveHitBoxesRef.current = [];

    bldgs.forEach((b) => {
      const pos = b.campusPosition || { x: 0, z: 0, width: 28, depth: 20, heightPerFloor: 3.8 };
      const group = new THREE.Group();
      group.name = `bldg-group-${b.id}`;
      group.position.set(pos.x, 0, pos.z);
      if (pos.rotation) {
        group.rotation.y = pos.rotation;
      }

      const floorsCount = (b.floors && b.floors.length > 0) ? b.floors.length : (b.floorsCount || 3);
      const floorH = pos.heightPerFloor || 3.8;
      const totalH = floorsCount * floorH;

      // 1. Building Base Foundation Slab
      const baseGeo = new THREE.BoxGeometry(pos.width + 2, 0.8, pos.depth + 2);
      const baseMat = new THREE.MeshStandardMaterial({
        color: 0x12141c,
        roughness: 0.6,
        metalness: 0.4
      });
      const baseMesh = new THREE.Mesh(baseGeo, baseMat);
      baseMesh.position.y = 0.4;
      baseMesh.receiveShadow = true;
      group.add(baseMesh);

      // 2. Individual Architectural Floors
      for (let f = 0; f < floorsCount; f++) {
        const floorY = f * floorH + 0.8;
        const currentFloorObj = b.floors?.[f];
        const actualFloorNum = currentFloorObj ? currentFloorObj.floorNumber : f;

        // Concrete Floor Slab
        const slabGeo = new THREE.BoxGeometry(pos.width + 0.6, 0.5, pos.depth + 0.6);
        const slabMat = new THREE.MeshStandardMaterial({
          color: 0x1e202c,
          roughness: 0.5,
          metalness: 0.5
        });
        const slab = new THREE.Mesh(slabGeo, slabMat);
        slab.position.y = floorY + 0.25;
        slab.castShadow = true;
        slab.receiveShadow = true;
        group.add(slab);

        // Core building structure for this floor
        const wallGeo = new THREE.BoxGeometry(pos.width - 1.2, floorH - 0.5, pos.depth - 1.2);
        const wallMat = new THREE.MeshStandardMaterial({
          color: 0x0d0e14,
          roughness: 0.4,
          metalness: 0.6
        });
        const wall = new THREE.Mesh(wallGeo, wallMat);
        wall.position.y = floorY + 0.5 + (floorH - 0.5) / 2;
        wall.castShadow = true;
        wall.receiveShadow = true;
        wall.userData = { role: 'wall', floorIndex: actualFloorNum, buildingId: b.id };
        group.add(wall);

        // Structural Columns (Corner & Support Columns connecting floor slabs)
        const colSize = 0.65;
        const colH = floorH - 0.5;
        const colGeo = new THREE.BoxGeometry(colSize, colH, colSize);
        const colMat = new THREE.MeshStandardMaterial({
          color: 0x1c1f2b,
          roughness: 0.35,
          metalness: 0.7
        });

        const columnCoords = [
          // 4 Corner structural columns
          [-pos.width / 2 + colSize / 2 + 0.1, -pos.depth / 2 + colSize / 2 + 0.1],
          [pos.width / 2 - colSize / 2 - 0.1, -pos.depth / 2 + colSize / 2 + 0.1],
          [-pos.width / 2 + colSize / 2 + 0.1, pos.depth / 2 - colSize / 2 - 0.1],
          [pos.width / 2 - colSize / 2 - 0.1, pos.depth / 2 - colSize / 2 - 0.1],
          // Facade support columns along front and rear
          [-pos.width * 0.22, pos.depth / 2 - colSize / 2 - 0.1],
          [pos.width * 0.22, pos.depth / 2 - colSize / 2 - 0.1],
          [-pos.width * 0.22, -pos.depth / 2 + colSize / 2 + 0.1],
          [pos.width * 0.22, -pos.depth / 2 + colSize / 2 + 0.1]
        ];

        columnCoords.forEach(([cx, cz]) => {
          const colMesh = new THREE.Mesh(colGeo, colMat);
          colMesh.position.set(cx, floorY + 0.5 + colH / 2, cz);
          colMesh.castShadow = true;
          colMesh.receiveShadow = true;
          colMesh.userData = { role: 'column', floorIndex: actualFloorNum, buildingId: b.id };
          group.add(colMesh);
        });

        // Classroom Spaces / Internal layout compartments within this floor
        const roomPodGeo = new THREE.BoxGeometry(pos.width * 0.4, floorH * 0.58, pos.depth * 0.35);
        const roomPodMat = new THREE.MeshStandardMaterial({
          color: 0x141622,
          roughness: 0.55,
          metalness: 0.35
        });

        const roomPodLeft = new THREE.Mesh(roomPodGeo, roomPodMat);
        roomPodLeft.position.set(-pos.width * 0.22, floorY + 0.5 + (floorH * 0.58) / 2, 0);
        roomPodLeft.userData = { role: 'classroom-space', floorIndex: actualFloorNum, buildingId: b.id };
        group.add(roomPodLeft);

        const roomPodRight = new THREE.Mesh(roomPodGeo, roomPodMat);
        roomPodRight.position.set(pos.width * 0.22, floorY + 0.5 + (floorH * 0.58) / 2, 0);
        roomPodRight.userData = { role: 'classroom-space', floorIndex: actualFloorNum, buildingId: b.id };
        group.add(roomPodRight);

        // Glass curtain facade bands (Front & Back)
        const windowGeoFB = new THREE.BoxGeometry(pos.width, floorH * 0.55, 0.4);
        const floorWindowMat = new THREE.MeshStandardMaterial({
          color: 0x00a3cc,
          emissive: 0x005577,
          emissiveIntensity: 0.45,
          roughness: 0.1,
          metalness: 0.8,
          transparent: true,
          opacity: 0.85
        });

        const windowFront = new THREE.Mesh(windowGeoFB, floorWindowMat);
        windowFront.position.set(0, floorY + floorH * 0.55, pos.depth / 2);
        windowFront.userData = { role: 'window', floorIndex: actualFloorNum, buildingId: b.id };
        group.add(windowFront);

        const windowBack = new THREE.Mesh(windowGeoFB, floorWindowMat);
        windowBack.position.set(0, floorY + floorH * 0.55, -pos.depth / 2);
        windowBack.userData = { role: 'window', floorIndex: actualFloorNum, buildingId: b.id };
        group.add(windowBack);

        // Glass curtain bands (Sides)
        const windowGeoSides = new THREE.BoxGeometry(0.4, floorH * 0.55, pos.depth - 1.5);
        const windowLeft = new THREE.Mesh(windowGeoSides, floorWindowMat);
        windowLeft.position.set(-pos.width / 2, floorY + floorH * 0.55, 0);
        windowLeft.userData = { role: 'window', floorIndex: actualFloorNum, buildingId: b.id };
        group.add(windowLeft);

        const windowRight = new THREE.Mesh(windowGeoSides, floorWindowMat);
        windowRight.position.set(pos.width / 2, floorY + floorH * 0.55, 0);
        windowRight.userData = { role: 'window', floorIndex: actualFloorNum, buildingId: b.id };
        group.add(windowRight);

        // Floor accent trim line (illuminates when floor is active)
        const trimGeo = new THREE.EdgesGeometry(new THREE.BoxGeometry(pos.width + 0.4, 0.08, pos.depth + 0.4));
        const trimMat = new THREE.LineBasicMaterial({
          color: 0x005577,
          linewidth: 1
        });
        const trimMesh = new THREE.LineSegments(trimGeo, trimMat);
        trimMesh.position.y = floorY + 0.5;
        trimMesh.userData = { role: 'floor-trim', floorIndex: actualFloorNum, buildingId: b.id };
        group.add(trimMesh);

        // Interactive floor hitbox for direct 3D floor clicking
        const floorHitGeo = new THREE.BoxGeometry(pos.width + 1.2, floorH, pos.depth + 1.2);
        const floorHitMat = new THREE.MeshBasicMaterial({ visible: false });
        const floorHit = new THREE.Mesh(floorHitGeo, floorHitMat);
        floorHit.position.y = floorY + floorH / 2;
        floorHit.userData = {
          type: 'floor',
          buildingId: b.id,
          floorIndex: actualFloorNum
        };
        group.add(floorHit);
        interactiveHitBoxesRef.current.push(floorHit);
      }

      // 3. Rooftop Architectural Details (Solar Array, HVAC, Helipad/Antenna)
      const roofY = totalH + 0.8;
      createRooftopFeatures(group, b, pos, roofY);

      // 4. Outer Wireframe Outline (Electric Cyan by default)
      const edges = new THREE.EdgesGeometry(new THREE.BoxGeometry(pos.width + 0.2, totalH + 0.5, pos.depth + 0.2));
      const lineMat = new THREE.LineBasicMaterial({
        color: 0x00f5ff,
        linewidth: 1.5
      });
      const outline = new THREE.LineSegments(edges, lineMat);
      outline.position.y = (totalH + 0.5) / 2 + 0.4;
      outline.userData = { role: 'outline' };
      group.add(outline);

      // 5. Grand Architectural Entrance Canopy at Ground
      const canopyGeo = new THREE.BoxGeometry(10, 0.4, 4);
      const canopyMat = new THREE.MeshStandardMaterial({
        color: 0x8b5cf6,
        emissive: 0x7b2cbf,
        emissiveIntensity: 0.35,
        roughness: 0.3
      });
      const canopy = new THREE.Mesh(canopyGeo, canopyMat);
      canopy.position.set(0, 3.2, pos.depth / 2 + 2);
      group.add(canopy);

      // Entrance light
      const entranceLight = new THREE.PointLight(0x00f5ff, 2.0, 18);
      entranceLight.position.set(0, 2.8, pos.depth / 2 + 2);
      group.add(entranceLight);

      // 6. Floating 3D Building Billboard Label
      createBuildingFloatingLabel(group, b, roofY + 6);

      // 7. Raycast HitBox for crisp interaction detection
      const hitBoxGeo = new THREE.BoxGeometry(pos.width + 4, totalH + 4, pos.depth + 4);
      const hitBoxMat = new THREE.MeshBasicMaterial({
        visible: false,
        wireframe: true
      });
      const hitBox = new THREE.Mesh(hitBoxGeo, hitBoxMat);
      hitBox.position.y = (totalH + 4) / 2;
      hitBox.userData = {
        type: 'building',
        buildingId: b.id
      };
      group.add(hitBox);
      interactiveHitBoxesRef.current.push(hitBox);

      scene.add(group);
      buildingMeshesRef.current.set(b.id, group);
    });
  }

  function createRooftopFeatures(group: THREE.Group, b: Building, pos: any, roofY: number) {
    // Rooftop parapet
    const parapetGeo = new THREE.BoxGeometry(pos.width + 0.4, 0.8, pos.depth + 0.4);
    const parapetMat = new THREE.MeshStandardMaterial({ color: 0x191b26 });
    const parapet = new THREE.Mesh(parapetGeo, parapetMat);
    parapet.position.y = roofY + 0.4;
    group.add(parapet);

    // HVAC cooling towers
    for (let i = 0; i < 2; i++) {
      const hvacGeo = new THREE.BoxGeometry(3.5, 2, 3.5);
      const hvacMat = new THREE.MeshStandardMaterial({ color: 0x242838, metalness: 0.8 });
      const hvac = new THREE.Mesh(hvacGeo, hvacMat);
      hvac.position.set(pos.width / 4 - i * 6, roofY + 1.4, -pos.depth / 4);
      group.add(hvac);
    }

    // Specific features by building
    if (b.id === 'bldg-turing' || b.id === 'bldg-block3') {
      // Antenna mast with blinking beacon
      const mastGeo = new THREE.CylinderGeometry(0.15, 0.4, 10, 8);
      const mastMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9 });
      const mast = new THREE.Mesh(mastGeo, mastMat);
      mast.position.set(-pos.width / 3, roofY + 5.5, pos.depth / 4);
      group.add(mast);

      const beacon = new THREE.PointLight(0x8b5cf6, 2.0, 16);
      beacon.position.set(-pos.width / 3, roofY + 10.6, pos.depth / 4);
      group.add(beacon);
    } else if (b.id === 'bldg-lovelace') {
      // Glass observatory dome / bio-research dome
      const domeGeo = new THREE.SphereGeometry(3.8, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2);
      const domeMat = new THREE.MeshStandardMaterial({
        color: 0x00f5ff,
        emissive: 0x00a3cc,
        emissiveIntensity: 0.4,
        roughness: 0.1,
        transparent: true,
        opacity: 0.75
      });
      const dome = new THREE.Mesh(domeGeo, domeMat);
      dome.position.set(-pos.width / 4, roofY + 0.8, pos.depth / 4);
      group.add(dome);
    } else {
      // Solar panel matrix
      const solarMat = new THREE.MeshStandardMaterial({
        color: 0x1e1b4b,
        emissive: 0x00f5ff,
        emissiveIntensity: 0.15,
        metalness: 0.9,
        roughness: 0.2
      });
      for (let s = 0; s < 3; s++) {
        const solar = new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.2, 7), solarMat);
        solar.rotation.x = 0.2;
        solar.position.set(-pos.width / 4 + s * 5.5, roofY + 1.2, 0);
        group.add(solar);
      }
    }
  }

  function createBuildingFloatingLabel(group: THREE.Group, b: Building, yPos: number) {
    // Canvas billboard texture with building name & code
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 140;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background badge (Jet Black)
    ctx.fillStyle = 'rgba(5, 5, 7, 0.94)';
    ctx.roundRect(10, 10, 492, 120, 24);
    ctx.fill();

    // Border (Electric Cyan)
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#00F5FF';
    ctx.stroke();

    // Code Pill (Royal Amethyst)
    ctx.fillStyle = '#8B5CF6';
    ctx.roundRect(30, 32, 80, 36, 10);
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 22px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText(b.code, 70, 58);

    // Building Title
    ctx.fillStyle = '#F8FAFC';
    ctx.font = 'bold 30px "Plus Jakarta Sans", sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(b.name, 126, 60);

    // Subtitle / Stats
    const totalFloorsForLabel = b.floors?.length || b.floorsCount || 3;
    ctx.fillStyle = '#94A3B8';
    ctx.font = '20px "Plus Jakarta Sans", sans-serif';
    ctx.fillText(`${totalFloorsForLabel} Floors • ${b.classroomsCount} Rooms • ${b.status}`, 32, 104);

    const texture = new THREE.CanvasTexture(canvas);
    const spriteMat = new THREE.SpriteMaterial({ map: texture, transparent: true });
    const sprite = new THREE.Sprite(spriteMat);
    sprite.scale.set(16, 4.4, 1);
    sprite.position.set(0, yPos, 0);
    group.add(sprite);
  }
};
