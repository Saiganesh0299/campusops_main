import React, { useState, useEffect } from 'react';
import { User, ROLE_LABELS } from '../types/rbac';
import { CampusNotification } from '../types/campus';
import { 
  Bell, 
  CheckCircle2, 
  Clock, 
  Wrench, 
  Calendar, 
  ShoppingBag, 
  AlertTriangle, 
  Check, 
  X,
  Filter,
  RefreshCw,
  Mail,
  Smartphone,
  ShieldAlert,
  ArrowUpRight,
  ExternalLink
} from 'lucide-react';

interface NotificationsViewProps {
  currentUser: User;
  onNavigateToComplaint?: (ticketId: string) => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({ 
  currentUser,
  onNavigateToComplaint 
}) => {
  const [notifications, setNotifications] = useState<CampusNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterUnreadOnly, setFilterUnreadOnly] = useState(false);
  const [channelFilter, setChannelFilter] = useState<'all' | 'in_app' | 'email'>('all');
  const [retryingId, setRetryingId] = useState<string | null>(null);
  const [sseConnected, setSseConnected] = useState(false);
  const [newToast, setNewToast] = useState<string | null>(null);

  // Load notifications from backend REST API
  const fetchNotifications = async () => {
    try {
      const res = await fetch(`/api/notifications?userId=${currentUser.id}&role=${currentUser.role}`);
      if (res.ok) {
        const data = await res.json();
        setNotifications(data);
      }
    } catch {
      // fallback
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, [currentUser]);

  // Connect to Real-Time SSE Stream (Task 7 A)
  useEffect(() => {
    const sse = new EventSource(`/api/notifications/stream?userId=${currentUser.id}`);

    sse.onopen = () => {
      setSseConnected(true);
    };

    sse.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data && data.id) {
          setNotifications(prev => [data, ...prev.filter(n => n.id !== data.id)]);
          setNewToast(data.title);
          setTimeout(() => setNewToast(null), 4500);
        }
      } catch {}
    };

    sse.onerror = () => {
      setSseConnected(false);
    };

    return () => {
      sse.close();
    };
  }, [currentUser.id]);

  const handleMarkRead = async (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    try {
      await fetch(`/api/notifications/${id}/read`, { method: 'PATCH' });
    } catch {}
  };

  const handleMarkAllRead = async () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    try {
      await fetch('/api/notifications/mark-all-read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: currentUser.id })
      });
    } catch {}
  };

  const handleRetryDelivery = async (id: string) => {
    setRetryingId(id);
    try {
      const res = await fetch(`/api/notifications/${id}/retry`, { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        if (data.notification) {
          setNotifications(prev => prev.map(n => n.id === id ? data.notification : n));
        }
      }
    } catch {
      //
    } finally {
      setRetryingId(null);
    }
  };

  const filtered = notifications.filter(n => {
    if (filterUnreadOnly && n.read) return false;
    if (channelFilter !== 'all' && n.channel !== channelFilter) return false;
    return true;
  });

  const unreadCount = notifications.filter(n => !n.read).length;
  const failedCount = notifications.filter(n => n.deliveryStatus === 'failed').length;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Toast Alert on Real-time arrival */}
      {newToast && (
        <div className="fixed top-20 right-6 z-50 p-4 rounded-xl bg-[#0F101A] border border-[#8B5CF6] text-white shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-4">
          <div className="w-8 h-8 rounded-lg bg-[#8B5CF6]/20 flex items-center justify-center shrink-0">
            <Bell className="w-4 h-4 text-[#8B5CF6] animate-bounce" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-mono font-bold text-[#8B5CF6] block">Live Dispatch Alert</span>
            <span className="text-xs font-semibold text-slate-100">{newToast}</span>
          </div>
        </div>
      )}

      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-[#0B0C14] border border-[#1E2030]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-xl font-extrabold text-white tracking-tight flex items-center gap-2">
              <Bell className="w-5 h-5 text-[#8B5CF6]" />
              Technician & Operations Notifications
            </h1>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#00F5FF]/15 text-[#00F5FF] border border-[#00F5FF]/40">
              REAL-TIME DISPATCH
            </span>
            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
              sseConnected ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${sseConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
              {sseConnected ? 'LIVE STREAM' : 'POLLING'}
            </span>
          </div>
          <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
            Instant assignment alerts, dispatch updates, multi-channel verification (In-App & Email), and failed delivery retry queue.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {unreadCount > 0 && (
            <button
              onClick={handleMarkAllRead}
              className="px-3 py-1.5 rounded-xl bg-[#141524] hover:bg-[#1E2036] text-xs font-semibold text-slate-200 border border-[#25283D] transition-colors cursor-pointer"
            >
              Mark All as Read ({unreadCount})
            </button>
          )}

          <button
            onClick={fetchNotifications}
            className="p-2 rounded-xl bg-[#141524] hover:bg-[#1E2036] text-slate-300 hover:text-white border border-[#25283D] transition-colors cursor-pointer"
            title="Refresh from server"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filter Chips Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-xl bg-[#0D0E16] border border-[#1E2030]">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5 mr-1">
            <Filter className="w-3.5 h-3.5" />
            Filters:
          </span>

          <button
            onClick={() => setFilterUnreadOnly(false)}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              !filterUnreadOnly
                ? 'bg-[#8B5CF6] text-white shadow-lg shadow-[#8B5CF6]/25'
                : 'bg-[#121320] text-slate-400 hover:text-white border border-[#1E2030]'
            }`}
          >
            All ({notifications.length})
          </button>

          <button
            onClick={() => setFilterUnreadOnly(true)}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              filterUnreadOnly
                ? 'bg-[#8B5CF6] text-white shadow-lg shadow-[#8B5CF6]/25'
                : 'bg-[#121320] text-slate-400 hover:text-white border border-[#1E2030]'
            }`}
          >
            Unread ({unreadCount})
          </button>

          <div className="h-4 w-[1px] bg-slate-800 mx-1" />

          <button
            onClick={() => setChannelFilter('all')}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
              channelFilter === 'all' ? 'bg-[#00F5FF] text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            All Channels
          </button>
          <button
            onClick={() => setChannelFilter('in_app')}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer ${
              channelFilter === 'in_app' ? 'bg-[#00F5FF] text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3 h-3" />
            In-App
          </button>
          <button
            onClick={() => setChannelFilter('email')}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer ${
              channelFilter === 'email' ? 'bg-[#00F5FF] text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Mail className="w-3 h-3" />
            Email Records
          </button>
        </div>

        {failedCount > 0 && (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-semibold">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>{failedCount} Failed Dispatch Attempts</span>
          </div>
        )}
      </div>

      {/* Notifications List */}
      <div className="space-y-3">
        {loading ? (
          <div className="p-12 text-center rounded-2xl bg-[#0B0C14] border border-[#1E2030]">
            <RefreshCw className="w-6 h-6 text-slate-500 animate-spin mx-auto mb-2" />
            <p className="text-xs text-slate-400">Loading notifications...</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-[#0B0C14] border border-[#1E2030]">
            <Bell className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-300">No notifications match your filter</p>
            <p className="text-xs text-slate-500 mt-1">New maintenance tickets and updates will appear here automatically in real time.</p>
          </div>
        ) : (
          filtered.map(notif => (
            <div
              key={notif.id}
              className={`p-4 rounded-xl border transition-all ${
                !notif.read
                  ? 'bg-[#121324] border-[#00F5FF]/60 shadow-[0_0_15px_rgba(0,245,255,0.12)]'
                  : 'bg-[#0B0C14] border-[#1E2030] opacity-85 hover:opacity-100'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
                    notif.priority === 'critical' ? 'bg-red-500/15 border-red-500/40 text-red-400' :
                    notif.priority === 'high' ? 'bg-amber-500/15 border-amber-500/40 text-amber-400' :
                    notif.channel === 'email' ? 'bg-purple-500/15 border-purple-500/40 text-purple-400' :
                    'bg-[#00F5FF]/15 border-[#00F5FF]/40 text-[#00F5FF]'
                  }`}>
                    {notif.channel === 'email' ? <Mail className="w-4 h-4" /> : <Wrench className="w-4 h-4" />}
                  </div>

                  <div className="flex-1 space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h4 className="text-sm font-bold text-white">
                        {notif.title}
                      </h4>
                      {!notif.read && (
                        <span className="w-2 h-2 rounded-full bg-[#00F5FF] animate-pulse" />
                      )}
                      <span className={`px-2 py-0.2 rounded text-[9px] font-mono font-bold uppercase ${
                        notif.priority === 'critical' ? 'bg-red-500/20 text-red-400' :
                        notif.priority === 'high' ? 'bg-amber-500/20 text-amber-400' :
                        'bg-slate-800 text-slate-300'
                      }`}>
                        {notif.priority}
                      </span>
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-mono text-slate-400 bg-slate-800/60 border border-slate-700">
                        {notif.channel === 'email' ? 'EMAIL CHANNEL' : 'IN-APP'}
                      </span>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed">
                      {notif.message}
                    </p>

                    <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500 pt-1">
                      <span className="flex items-center gap-1 font-mono">
                        <Clock className="w-3 h-3" />
                        {new Date(notif.timestamp).toLocaleString('en-US', { timeZone: 'UTC', dateStyle: 'short', timeStyle: 'short' })} UTC
                      </span>

                      {notif.complaintId && (
                        <span className="font-mono text-slate-400">
                          Complaint: <strong>{notif.complaintId}</strong>
                        </span>
                      )}

                      {notif.workOrderId && (
                        <span className="font-mono text-slate-400">
                          Work Order: <strong>{notif.workOrderId}</strong>
                        </span>
                      )}

                      {/* Delivery Status Badge */}
                      <span className={`px-2 py-0.2 rounded text-[10px] font-mono flex items-center gap-1 ${
                        notif.deliveryStatus === 'delivered' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' :
                        notif.deliveryStatus === 'retrying' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' :
                        'bg-red-500/10 text-red-400 border border-red-500/30'
                      }`}>
                        {notif.deliveryStatus === 'delivered' ? <CheckCircle2 className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                        {notif.deliveryStatus === 'delivered' ? 'Confirmed Delivered' : `Failed (${notif.failureReason || 'Carrier Error'})`}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Actions: Mark read, Retry, Navigate */}
                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  {notif.deliveryStatus === 'failed' && (
                    <button
                      onClick={() => handleRetryDelivery(notif.id)}
                      disabled={retryingId === notif.id}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-semibold transition-all cursor-pointer shadow-lg shadow-red-600/30"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${retryingId === notif.id ? 'animate-spin' : ''}`} />
                      <span>{retryingId === notif.id ? 'Retrying...' : 'Retry Delivery'}</span>
                    </button>
                  )}

                  {!notif.read && (
                    <button
                      onClick={() => handleMarkRead(notif.id)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                      title="Mark as read"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  )}

                  {notif.complaintId && onNavigateToComplaint && (
                    <button
                      onClick={() => onNavigateToComplaint(notif.complaintId!)}
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#252630] hover:bg-slate-700 text-slate-200 text-xs font-medium cursor-pointer"
                    >
                      <span>View Ticket</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
