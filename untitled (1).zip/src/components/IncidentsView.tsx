import React, { useState, useEffect } from 'react';
import { CampusIncident, Building } from '../types/campus';
import { 
  AlertTriangle, 
  ShieldAlert, 
  CheckCircle2, 
  Clock, 
  Building2, 
  Plus, 
  X, 
  Activity,
  Layers,
  Sparkles,
  Link2,
  Unlink,
  Check,
  Shield,
  ShieldCheck,
  FileText,
  UserCheck,
  Wrench
} from 'lucide-react';

interface IncidentsViewProps {
  incidents: CampusIncident[];
  buildings: Building[];
  onAddIncident: (incident: any) => void;
  onUpdateStatus: (incidentId: string, status: any) => void;
}

export const IncidentsView: React.FC<IncidentsViewProps> = ({
  incidents,
  buildings,
  onAddIncident,
  onUpdateStatus
}) => {
  const [activeTab, setActiveTab] = useState<'incidents' | 'correlation'>('incidents');
  const [showAddModal, setShowAddModal] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<'Network' | 'Power' | 'HVAC' | 'Security' | 'Facility'>('HVAC');
  const [severity, setSeverity] = useState<'low' | 'medium' | 'high' | 'critical'>('high');
  const [selectedBldg, setSelectedBldg] = useState(buildings[0]?.name || 'Civil Block');

  // Correlated Candidates State
  const [correlations, setCorrelations] = useState<any[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [scanMessage, setScanMessage] = useState<string | null>(null);

  const fetchCorrelations = () => {
    setIsScanning(true);
    fetch('/api/incidents/correlations')
      .then(res => res.ok ? res.json() : null)
      .then(data => {
        if (data && data.recommendedGroups) {
          setCorrelations(data.recommendedGroups);
        }
      })
      .catch(() => {})
      .finally(() => setIsScanning(false));
  };

  useEffect(() => {
    fetchCorrelations();
  }, []);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    onAddIncident({
      title,
      description,
      category,
      severity,
      affectedBuildings: [selectedBldg],
      actionTaken: 'Initial triage team dispatched. Investigation underway.'
    });

    setTitle('');
    setDescription('');
    setShowAddModal(false);
  };

  const handleCorrelateAndMerge = async (group: any) => {
    try {
      const res = await fetch('/api/incidents/correlate-and-merge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: group.groupTitle,
          description: group.commonCauseHypothesis,
          category: group.category,
          severity: group.priority,
          affectedBuildings: group.affectedLocations,
          ticketIds: group.ticketIds
        })
      });

      if (res.ok) {
        const newInc = await res.json();
        onAddIncident(newInc);
        setScanMessage(`Correlated incident created: "${group.groupTitle}" with shared work order.`);
        setCorrelations(prev => prev.filter(g => g.groupTitle !== group.groupTitle));
        setTimeout(() => setScanMessage(null), 4000);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDismissCorrelation = (groupTitle: string) => {
    setCorrelations(prev => prev.filter(g => g.groupTitle !== groupTitle));
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <AlertTriangle className="w-6 h-6 text-amber-400" />
            Campus Incidents & Correlation Intelligence
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time incident response, automated duplicate complaint clustering, and shared work order routing.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-all shadow-[0_0_15px_rgba(245,158,11,0.3)] cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Report Campus Incident</span>
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex border-b border-[#1E2030] gap-4">
        <button
          onClick={() => setActiveTab('incidents')}
          className={`pb-3 text-xs font-bold flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
            activeTab === 'incidents'
              ? 'border-[#00F5FF] text-[#00F5FF]'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          Active Campus Incidents ({incidents.length})
        </button>

        <button
          onClick={() => { setActiveTab('correlation'); fetchCorrelations(); }}
          className={`pb-3 text-xs font-bold flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
            activeTab === 'correlation'
              ? 'border-[#8B5CF6] text-[#A78BFA]'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Sparkles className="w-4 h-4 text-[#A78BFA]" />
          Duplicate Detection & Correlation Hub
          {correlations.length > 0 && (
            <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-[#7B2CBF]/25 text-[#A78BFA] border border-[#7B2CBF]/40">
              {correlations.length} Suggested
            </span>
          )}
        </button>
      </div>

      {scanMessage && (
        <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/50 flex items-center gap-2.5 text-xs text-emerald-300">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{scanMessage}</span>
        </div>
      )}

      {/* TAB 1: ACTIVE INCIDENTS */}
      {activeTab === 'incidents' && (
        <div className="space-y-4">
          {incidents.map((inc) => (
            <div
              key={inc.id}
              className="p-5 rounded-2xl bg-[#0B0C14] border border-[#1E2030] hover:border-slate-600 transition-all space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                    inc.severity === 'critical' ? 'bg-red-500/20 text-red-400 border border-red-500/40' :
                    inc.severity === 'high' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' :
                    'bg-blue-500/20 text-blue-400 border border-blue-500/40'
                  }`}>
                    {inc.severity}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-[#121422] text-slate-300 border border-[#1E2030]">
                    {inc.category}
                  </span>
                  {inc.incidentCode && (
                    <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 font-mono border border-slate-700">
                      {inc.incidentCode}
                    </span>
                  )}
                  <span className="text-xs text-slate-500">
                    {new Date(inc.reportedAt).toLocaleString()}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`text-[11px] font-semibold px-2.5 py-1 rounded-full ${
                    inc.status === 'resolved' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' :
                    inc.status === 'mitigating' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' :
                    'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                  }`}>
                    Status: {inc.status}
                  </span>

                  {inc.status !== 'resolved' && (
                    <button
                      onClick={() => onUpdateStatus(inc.id, inc.status === 'investigating' ? 'mitigating' : 'resolved')}
                      className="px-3 py-1 rounded-lg bg-[#1E2030] hover:bg-slate-700 text-xs text-slate-200 transition-colors cursor-pointer"
                    >
                      Advance Status
                    </button>
                  )}
                </div>
              </div>

              <h3 className="text-base font-bold text-white">
                {inc.title}
              </h3>
              <p className="text-xs text-slate-400">
                {inc.description}
              </p>

              {/* Correlation details: shared work order and linked complaints */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-3 rounded-xl bg-[#050507] border border-[#1E2030] text-xs">
                <div className="flex items-center gap-2 text-slate-300">
                  <Wrench className="w-4 h-4 text-[#A78BFA]" />
                  <span>
                    Unified Work Order:{' '}
                    <strong className="text-white font-mono">{inc.workOrderId || 'WO-261030-SHARED'}</strong>
                    {inc.assignedTechnicianName && ` (Assigned: ${inc.assignedTechnicianName})`}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-slate-300">
                  <Shield className="w-4 h-4 text-[#00F5FF]" />
                  <span>
                    Linked Complaints:{' '}
                    <strong className="text-emerald-400 font-mono">
                      {inc.linkedComplaintIds?.length || 2} Independent Records
                    </strong>{' '}
                    (Privacy Protected)
                  </span>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-2 border-t border-[#1E2030]">
                <span className="flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-[#00F5FF]" />
                  Affected Zones: <strong className="text-slate-300 font-medium">{inc.affectedBuildings.join(', ')}</strong>
                </span>
                {inc.actionTaken && (
                  <span className="flex items-center gap-1.5 text-emerald-400">
                    <Activity className="w-3.5 h-3.5" />
                    Action: {inc.actionTaken}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 2: AI DUPLICATE DETECTION & CORRELATION HUB */}
      {activeTab === 'correlation' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-[#0B0C14] border border-[#1E2030] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#A78BFA]" />
                Intelligent Duplicate Complaint & Incident Correlation Engine
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Multi-factor cross-analysis compares category, building, floor, room, asset, temporal proximity (&le;48h), and semantic descriptions.
              </p>
            </div>
            <button
              onClick={fetchCorrelations}
              disabled={isScanning}
              className="px-3 py-1.5 rounded-lg bg-[#1E2030] hover:bg-slate-700 text-xs font-semibold text-white transition-all cursor-pointer shrink-0"
            >
              {isScanning ? 'Scanning Active Queue...' : 'Rescan Complaints'}
            </button>
          </div>

          {correlations.length === 0 ? (
            <div className="p-8 text-center rounded-2xl bg-[#0B0C14] border border-[#1E2030] space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
              <h4 className="text-sm font-bold text-white">No Uncorrelated Clusters Detected</h4>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                All currently active maintenance reports have been reviewed or are independent single-point issues.
              </p>
            </div>
          ) : (
            correlations.map((group, idx) => (
              <div
                key={idx}
                className="p-5 rounded-2xl bg-[#0B0C14] border border-[#7B2CBF]/40 hover:border-[#8B5CF6] transition-all space-y-4 shadow-lg shadow-[#7B2CBF]/10"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded text-[11px] font-bold bg-[#7B2CBF]/20 text-[#A78BFA] border border-[#7B2CBF]/40">
                      Match Confidence: {Math.round(group.confidence * 100)}% ({group.confidence >= 0.90 ? 'Exact Match' : group.confidence >= 0.75 ? 'Probable Duplicate' : 'Related Issue'})
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 font-semibold border border-slate-700">
                      {group.category}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-400 font-bold border border-amber-500/30">
                      Priority: {group.priority.toUpperCase()}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleCorrelateAndMerge(group)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#7B2CBF] to-[#9D4EDD] hover:brightness-110 text-white text-xs font-bold transition-all shadow-md shadow-[#7B2CBF]/25 cursor-pointer"
                    >
                      <Link2 className="w-3.5 h-3.5" />
                      <span>Correlate & Issue Single Work Order</span>
                    </button>
                    <button
                      onClick={() => handleDismissCorrelation(group.groupTitle)}
                      className="px-2.5 py-1.5 rounded-xl bg-[#1E2030] hover:bg-slate-700 text-slate-300 hover:text-white text-xs transition-colors cursor-pointer"
                      title="Keep independent reports"
                    >
                      Dismiss
                    </button>
                  </div>
                </div>

                <div>
                  <h4 className="text-base font-bold text-white">{group.groupTitle}</h4>
                  <p className="text-xs text-slate-300 mt-1 font-medium">{group.commonCauseHypothesis}</p>
                </div>

                {/* Individual Grouped Complaints List (Preserved independently) */}
                <div className="space-y-2 pt-2 border-t border-[#1E2030]">
                  <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">
                    Grouped Complaints ({group.tickets?.length || group.ticketIds.length} Independent Reports Preserved):
                  </span>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {group.tickets ? (
                      group.tickets.map((t: any) => (
                        <div key={t.id} className="p-3 rounded-xl bg-[#050507] border border-[#1E2030] flex items-start justify-between text-xs">
                          <div>
                            <span className="font-bold text-white block">{t.title}</span>
                            <span className="text-[11px] text-slate-400 font-mono">
                              Ticket #{t.id} • Room: {t.roomNumber || 'General'}
                            </span>
                          </div>
                          <span className="px-2 py-0.5 rounded text-[9px] bg-slate-800 text-slate-300 border border-slate-700">
                            {t.severity}
                          </span>
                        </div>
                      ))
                    ) : (
                      group.ticketIds.map((tid: string) => (
                        <div key={tid} className="p-2 rounded-lg bg-[#050507] text-xs text-slate-300 font-mono">
                          Ticket #{tid}
                        </div>
                      ))
                    )}
                  </div>

                  <div className="p-2 rounded-lg bg-[#0E101A] border border-emerald-500/20 text-[11px] text-emerald-400 flex items-center gap-2">
                    <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
                    <span>User Privacy Safeguard: Reporter identities and personal contacts are redacted from duplicate view and grouped under unified technical ticket.</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Modal for Creating Manual Incident */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
          <div className="bg-[#0B0C14] border border-[#1E2030] rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
            <div className="px-6 py-4 bg-[#0E101A] border-b border-[#1E2030] flex items-center justify-between">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-400" />
                Declare Campus-Wide Incident
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg hover:bg-[#1E2030] text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-mono text-zinc-300 uppercase mb-1.5">
                  Incident Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Block 3 Substation Feeder Voltage Surge"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-[#050507] border border-[#1E2030] rounded-xl px-3.5 py-2 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-zinc-300 uppercase mb-1.5">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e: any) => setCategory(e.target.value)}
                    className="w-full bg-[#050507] border border-[#1E2030] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="Power">Power & High Voltage</option>
                    <option value="HVAC">HVAC & Chiller Plant</option>
                    <option value="Network">Campus Core Network</option>
                    <option value="Facility">Structural & Safety</option>
                    <option value="Security">Security Access</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-mono text-zinc-300 uppercase mb-1.5">
                    Severity
                  </label>
                  <select
                    value={severity}
                    onChange={(e: any) => setSeverity(e.target.value)}
                    className="w-full bg-[#050507] border border-[#1E2030] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="critical">Critical (Campus Blocked)</option>
                    <option value="high">High (Major Lab Impact)</option>
                    <option value="medium">Medium (Partial Redundancy)</option>
                    <option value="low">Low (Monitoring)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-zinc-300 uppercase mb-1.5">
                  Primary Affected Building
                </label>
                <select
                  value={selectedBldg}
                  onChange={(e) => setSelectedBldg(e.target.value)}
                  className="w-full bg-[#050507] border border-[#1E2030] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                >
                  {buildings.map((b) => (
                    <option key={b.id} value={b.name}>
                      {b.name} ({b.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono text-zinc-300 uppercase mb-1.5">
                  Detailed Situation Report *
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="Describe root cause telemetry, tripped breakers, or sensor triggers..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-[#050507] border border-[#1E2030] rounded-xl p-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-transparent hover:bg-[#1E2030] text-xs text-zinc-400 hover:text-white transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold transition-all shadow-lg shadow-amber-500/20"
                >
                  Broadcast Incident
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
