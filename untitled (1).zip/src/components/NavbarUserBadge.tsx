import React, { useState, useEffect, useRef } from 'react';
import { User, ROLE_LABELS, ROLE_COLORS, UserRole } from '../types/rbac';
import { initialUsers } from '../data/rbacSeedData';
import { 
  ChevronDown, 
  Check, 
  UserCheck, 
  KeyRound, 
  Sparkles, 
  ShieldAlert,
  Loader2,
  ExternalLink
} from 'lucide-react';

interface NavbarUserBadgeProps {
  currentUser: User;
  onOpenAuthModal: () => void;
  onSwitchUser?: (user: User) => void;
}

export const NavbarUserBadge: React.FC<NavbarUserBadgeProps> = ({
  currentUser,
  onOpenAuthModal,
  onSwitchUser
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [usersList, setUsersList] = useState<User[]>(initialUsers);
  const [isSwitching, setIsSwitching] = useState<string | null>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);


  // Fetch current provisioned users from the backend directory to reflect database state
  useEffect(() => {
    let isMounted = true;
    fetch('/api/users')
      .then(res => res.ok ? res.json() : Promise.reject())
      .then((data: User[]) => {
        if (isMounted && Array.isArray(data) && data.length > 0) {
          setUsersList(data);
        }
      })
      .catch(() => {
        // Fallback to initialUsers on network error
      });
    return () => { isMounted = false; };
  }, []);

  // Click outside and escape key handling
  useEffect(() => {
    if (!isOpen) return;

    const handlePointerDown = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handlePointerDown);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handlePointerDown);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  // Development / Demo fast persona switcher state
  const handleBadgeClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsOpen(prev => !prev);
  };

  const handleSwitchAccount = async (targetUser: User) => {
    if (targetUser.id === currentUser.id) {
      setIsOpen(false);
      return;
    }

    if (!targetUser.isActive) {
      alert(`Account ${targetUser.name} is deactivated.`);
      return;
    }

    setIsSwitching(targetUser.id);

    try {
      // Authenticate switch via backend dev-switch route
      const res = await fetch('/api/auth/dev-switch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: targetUser.id })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.user && onSwitchUser) {
          onSwitchUser(data.user);
        }
      } else {
        // Fallback to local switch if offline
        if (onSwitchUser) onSwitchUser(targetUser);
      }
    } catch {
      if (onSwitchUser) onSwitchUser(targetUser);
    } finally {
      setIsSwitching(null);
      setIsOpen(false);
    }
  };

  const roleStyle = ROLE_COLORS[currentUser.role] || {
    bg: 'bg-slate-800',
    text: 'text-slate-300',
    border: 'border-slate-700'
  };

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Trigger Button */}
      <button
        onClick={handleBadgeClick}
        aria-expanded={isOpen}
        aria-haspopup="menu"
        className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-[#0B0C14] hover:bg-[#121422] border border-[#1E2030] hover:border-[#8B5CF6]/50 transition-all cursor-pointer group text-left shadow-sm select-none"
        title="Role & Account Persona Switcher (Click to toggle)"
      >
        <div className="relative">
          <img
            src={currentUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
            alt={currentUser.name}
            className="w-7 h-7 rounded-full object-cover border border-[#1E2030] group-hover:border-[#00F5FF] transition-colors"
          />
          <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 border border-[#050507]" />
        </div>

        <div className="hidden sm:block">
          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-white group-hover:text-slate-100 transition-colors">
              {currentUser.name}
            </span>
            <span className={`px-1.5 py-0.2 rounded text-[9px] font-mono font-bold border ${roleStyle.bg} ${roleStyle.text} ${roleStyle.border}`}>
              {ROLE_LABELS[currentUser.role]}
            </span>
          </div>
          <span className="text-[10px] text-slate-400 block font-mono -mt-0.5 truncate max-w-[140px]">
            {currentUser.departmentName || 'Campus Administration'}
          </span>
        </div>

        <ChevronDown className={`w-3.5 h-3.5 text-slate-500 group-hover:text-slate-300 transition-transform duration-200 ${isOpen ? 'rotate-180 text-[#00F5FF]' : ''}`} />
      </button>

      {/* Role & Account Switcher Dropdown (Available in Preview and Published environments) */}
      {isOpen && (
        <div
          role="menu"
          aria-label="Development & Demo Account Switcher"
          className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-[#08090F]/95 backdrop-blur-2xl border border-[#1E2030] shadow-[0_20px_50px_rgba(0,0,0,0.85)] z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-150"
        >
          {/* Header */}
          <div className="p-3.5 bg-[#0C0E18] border-b border-[#1E2030] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 flex items-center justify-center text-[#A78BFA]">
                <UserCheck className="w-3.5 h-3.5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h4 className="text-xs font-bold text-white">Switch Test Persona</h4>
                  <span className="px-1.5 py-0.2 text-[9px] font-mono font-bold bg-[#00F5FF]/15 text-[#00F5FF] border border-[#00F5FF]/30 rounded">
                    DEMO RBAC
                  </span>
                </div>
                <p className="text-[10px] text-slate-400">
                  Switch persona to test role-based permissions & data scopes
                </p>
              </div>
            </div>
          </div>

          {/* User List */}
          <div className="max-h-80 overflow-y-auto p-2 space-y-1 no-scrollbar">
            {usersList.map((user) => {
              const isCurrent = user.id === currentUser.id;
              const isPending = isSwitching === user.id;
              const userRoleStyle = ROLE_COLORS[user.role as UserRole] || {
                bg: 'bg-slate-800',
                text: 'text-slate-300',
                border: 'border-slate-700'
              };

              return (
                <button
                  key={user.id}
                  onClick={() => handleSwitchAccount(user)}
                  disabled={isSwitching !== null}
                  className={`w-full text-left p-2.5 rounded-xl border transition-all flex items-center justify-between group cursor-pointer ${
                    isCurrent
                      ? 'bg-[#121422] border-[#8B5CF6]/50 shadow-[0_0_12px_rgba(139,92,246,0.2)]'
                      : 'bg-[#0B0C14]/60 border-transparent hover:border-[#1E2030] hover:bg-[#10121C]'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="relative shrink-0">
                      <img
                        src={user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
                        alt={user.name}
                        className={`w-8 h-8 rounded-full object-cover border ${
                          isCurrent ? 'border-[#00F5FF]' : 'border-[#1E2030]'
                        }`}
                      />
                      {user.isActive && (
                        <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 border border-[#050507]" />
                      )}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-xs font-bold text-white truncate group-hover:text-[#00F5FF] transition-colors">
                          {user.name}
                        </span>
                        {user.isPrimaryAdmin && (
                          <span className="text-[9px] bg-red-500/20 text-red-400 px-1 py-0.2 rounded font-mono font-bold">
                            ROOT
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1 text-[10px] text-slate-400 truncate">
                        <span>{user.departmentName || 'Campus Wide'}</span>
                        <span>•</span>
                        <span className="font-mono text-slate-500">{user.email}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 ml-2">
                    <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold border uppercase tracking-wider ${userRoleStyle.bg} ${userRoleStyle.text} ${userRoleStyle.border}`}>
                      {ROLE_LABELS[user.role as UserRole]}
                    </span>

                    {isPending ? (
                      <Loader2 className="w-3.5 h-3.5 text-[#00F5FF] animate-spin" />
                    ) : isCurrent ? (
                      <div className="w-5 h-5 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </div>
                    ) : null}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Footer Action */}
          <div className="p-2.5 bg-[#0A0B14] border-t border-[#1E2030] flex items-center justify-between text-xs">
            <span className="text-[10px] text-slate-500 font-mono">
              6 RBAC Roles Available
            </span>
            <button
              onClick={() => {
                setIsOpen(false);
                onOpenAuthModal();
              }}
              className="text-[11px] font-semibold text-[#00F5FF] hover:underline flex items-center gap-1 cursor-pointer"
            >
              <KeyRound className="w-3 h-3" />
              <span>Full Auth Portal</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
