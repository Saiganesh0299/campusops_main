import React, { useState } from 'react';
import { User, UserRole, ROLE_COLORS, ROLE_LABELS } from '../types/rbac';
import { initialUsers } from '../data/rbacSeedData';
import { 
  ShieldCheck, 
  X, 
  Lock, 
  Mail, 
  AlertCircle, 
  CheckCircle2, 
  UserCheck, 
  KeyRound, 
  Info,
  Building2,
  Users
} from 'lucide-react';

interface AuthModalProps {
  currentUser: User | null;
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  currentUser,
  onClose,
  onLoginSuccess
}) => {
  const [activeTab, setActiveTab] = useState<'password' | 'switch'>('password');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  // Captcha state
  const [captchaChecked, setCaptchaChecked] = useState(false);
  const [captchaLoading, setCaptchaLoading] = useState(false);
  const [captchaVerified, setCaptchaVerified] = useState(false);
  
  // Feedback
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleCaptchaClick = () => {
    if (captchaVerified || captchaLoading) return;
    setCaptchaLoading(true);
    setErrorMessage(null);

    setTimeout(() => {
      setCaptchaLoading(false);
      setCaptchaChecked(true);
      setCaptchaVerified(true);
    }, 600);
  };

  const handlePasswordLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setErrorMessage('Email and password are required.');
      return;
    }

    if (!captchaVerified) {
      setErrorMessage('Security verification required: Please complete the CAPTCHA check.');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), password, captchaVerified: true })
      });

      const data = await res.json();
      if (!res.ok) {
        setErrorMessage(data.error || data.message || 'Invalid credentials or account deactivated.');
        setIsSubmitting(false);
        return;
      }

      setSuccessMessage(`Welcome back, ${data.user.name} (${ROLE_LABELS[data.user.role as UserRole]})`);
      setTimeout(() => {
        onLoginSuccess(data.user);
        onClose();
      }, 500);
    } catch {
      setErrorMessage('Unable to connect to authentication server. Please check your network connection.');
      setIsSubmitting(false);
    }
  };

  const handleDevSwitchRole = async (user: User) => {
    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/auth/dev-switch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id })
      });

      const data = await res.json();
      if (!res.ok) {
        setErrorMessage(data.error || 'Failed to switch account.');
        setIsSubmitting(false);
        return;
      }

      setSuccessMessage(`Authenticated as ${data.user.name} (${ROLE_LABELS[data.user.role as UserRole]})`);
      setTimeout(() => {
        onLoginSuccess(data.user);
        onClose();
      }, 400);
    } catch {
      handleQuickFillRole(user);
      setIsSubmitting(false);
    }
  };

  const handleQuickFillRole = (user: User) => {
    setEmail(user.email);
    setPassword('CampusOps@2026');
    setCaptchaVerified(true);
    setCaptchaChecked(true);
    setErrorMessage(null);
    setActiveTab('password');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg bg-[#0B0C14] border border-[#1E2030] rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header with CampusOps Logo */}
        <div className="flex items-center justify-between p-5 border-b border-[#1E2030] bg-[#0E101A]">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-[#050507] border border-[#1E2030] flex items-center justify-center p-1.5 shadow-lg shadow-[#00F5FF]/10 shrink-0">
              <img 
                src="/campusops-logo.png" 
                alt="CampusOps Logo" 
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <h2 className="text-base font-bold text-white tracking-wide flex items-center gap-2">
                CampusOps Access Portal
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#7B2CBF]/20 text-[#A78BFA] border border-[#7B2CBF]/30">
                  6-ROLE RBAC
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Admin-Controlled Identity & Role-Based Access Control
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-[#1E2030] bg-[#050507]">
          <button
            onClick={() => { setActiveTab('password'); setErrorMessage(null); }}
            className={`flex-1 py-3 text-xs font-semibold flex items-center justify-center gap-2 border-b-2 transition-all cursor-pointer ${
              activeTab === 'password'
                ? 'border-[#7B2CBF] text-white bg-[#0E101A]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5 text-[#A78BFA]" />
            Secure Email Login
          </button>
          <button
            onClick={() => { setActiveTab('switch'); setErrorMessage(null); }}
            className={`flex-1 py-3 text-xs font-semibold flex items-center justify-center gap-2 border-b-2 transition-all cursor-pointer ${
              activeTab === 'switch'
                ? 'border-[#00F5FF] text-white bg-[#0E101A]'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="w-3.5 h-3.5 text-[#00F5FF]" />
            Role Credentials Directory (6 Roles)
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto max-h-[70vh]">
          {/* Security Notice: Public Registration Disabled */}
          <div className="mb-4 p-3 rounded-xl bg-[#0E101A] border border-[#1E2030] flex items-start gap-2.5 text-xs text-slate-300">
            <Info className="w-4 h-4 text-[#00F5FF] shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white block">Admin-Only User Provisioning</span>
              <span>Public registration is disabled. Only the System Administrator can provision credentials and assign roles.</span>
            </div>
          </div>

          {/* Feedback Alerts */}
          {errorMessage && (
            <div className="mb-4 p-3 rounded-xl bg-red-950/40 border border-red-500/50 flex items-start gap-2 text-xs text-red-300 animate-shake">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="mb-4 p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/50 flex items-center gap-2 text-xs text-emerald-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {activeTab === 'password' && (
            <form onSubmit={handlePasswordLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>Institutional Email Address</span>
                  <span className="text-[10px] text-slate-500 font-mono">admin@campusops.edu</span>
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 transform -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g., admin@campusops.edu"
                    className="w-full bg-[#050507] border border-[#1E2030] focus:border-[#00F5FF] rounded-xl pl-10 pr-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none transition-colors"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  Account Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 transform -translate-y-1/2" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter password assigned by admin"
                    className="w-full bg-[#050507] border border-[#1E2030] focus:border-[#00F5FF] rounded-xl pl-10 pr-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none transition-colors"
                    required
                  />
                </div>
              </div>

              {/* Bot Detection Challenge (CAPTCHA) */}
              <div className="p-3.5 rounded-xl bg-[#0E101A] border border-[#1E2030] flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={handleCaptchaClick}
                    disabled={captchaVerified || captchaLoading}
                    className={`w-6 h-6 rounded border flex items-center justify-center transition-all cursor-pointer ${
                      captchaVerified
                        ? 'bg-emerald-500 border-emerald-400 text-slate-950'
                        : captchaLoading
                        ? 'border-[#00F5FF] bg-slate-800'
                        : 'border-slate-600 bg-slate-900 hover:border-slate-400'
                    }`}
                  >
                    {captchaVerified && <CheckCircle2 className="w-4 h-4 stroke-[3]" />}
                    {captchaLoading && <div className="w-3.5 h-3.5 border-2 border-[#00F5FF] border-t-transparent rounded-full animate-spin" />}
                  </button>
                  <div>
                    <span className="text-xs font-medium text-slate-200 block">
                      I'm not a robot
                    </span>
                    <span className="text-[10px] text-slate-500">
                      Automated anti-bot & brute-force safeguard
                    </span>
                  </div>
                </div>

                <div className="flex flex-col items-end">
                  <ShieldCheck className="w-5 h-5 text-[#00F5FF]" />
                  <span className="text-[9px] text-slate-500 font-mono">reCAPTCHA v3</span>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#7B2CBF] to-[#9D4EDD] hover:brightness-110 active:scale-[0.99] text-white text-xs font-bold transition-all shadow-lg shadow-[#7B2CBF]/30 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <KeyRound className="w-4 h-4" />
                    <span>Authenticate & Access CampusOps</span>
                  </>
                )}
              </button>

              <div className="pt-2 text-center">
                <button
                  type="button"
                  onClick={() => setActiveTab('switch')}
                  className="text-xs text-[#00F5FF] hover:underline"
                >
                  View credentials for all 6 roles & quick testing &rarr;
                </button>
              </div>
            </form>
          )}

          {activeTab === 'switch' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-400 mb-2">
                Select any provisioned user to test permissions and dashboards. Click a role to prefill email & password:
              </p>

              {initialUsers.map((user) => {
                const colorConfig = ROLE_COLORS[user.role as UserRole] || {
                  bg: 'bg-slate-800',
                  text: 'text-slate-300',
                  border: 'border-slate-700',
                  glow: ''
                };
                const isCurrent = currentUser?.id === user.id;

                return (
                  <div
                    key={user.id}
                    onClick={() => handleDevSwitchRole(user)}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between group ${
                      isCurrent
                        ? 'bg-[#121422] border-[#7B2CBF]/60 shadow-[0_0_15px_rgba(123,44,191,0.25)]'
                        : 'bg-[#07080E] border-[#1E2030] hover:border-[#00F5FF]/50 hover:bg-[#0E101A]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-lg bg-slate-850 flex items-center justify-center font-bold text-xs text-slate-300 border border-slate-700 shrink-0">
                        {user.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-white group-hover:text-[#00F5FF] transition-colors">
                            {user.name}
                          </span>
                          {user.isPrimaryAdmin && (
                            <span className="text-[9px] bg-red-500/20 text-red-400 px-1.5 py-0.2 rounded font-mono">
                              PRIMARY
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-slate-400 block font-mono">
                          {user.email}
                        </span>
                        <span className="text-[10px] text-slate-500 block">
                          Dept: {user.departmentName || 'Campus Wide'}
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-1.5">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase tracking-wider ${colorConfig.bg} ${colorConfig.text} ${colorConfig.border}`}>
                        {ROLE_LABELS[user.role as UserRole]}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono group-hover:text-white">
                        {isDev ? 'Switch Now →' : 'Prefill →'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 bg-[#050507] border-t border-[#1E2030] flex items-center justify-between text-[11px] text-slate-500">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>FastAPI REST & JWT Auth Active</span>
          </div>
          <span>EEC Campus Operations</span>
        </div>
      </div>
    </div>
  );
};
