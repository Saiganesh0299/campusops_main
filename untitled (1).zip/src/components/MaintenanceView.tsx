import React, { useState } from 'react';
import { MaintenanceTicket, StaffTechnician } from '../types/campus';
import { User, ROLE_LABELS } from '../types/rbac';
import { 
  Wrench, 
  Plus, 
  Search, 
  Filter, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  User as UserIcon, 
  Building2, 
  Check, 
  MessageSquare,
  Sparkles,
  FileText,
  Download,
  ShieldAlert,
  History,
  Tag,
  CheckCircle,
  XCircle,
  ExternalLink,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

interface MaintenanceViewProps {
  tickets: MaintenanceTicket[];
  technicians: StaffTechnician[];
  currentUser: User;
  onOpenReportModal: () => void;
  onUpdateTicketStatus: (ticketId: string, newStatus: any, notes?: string) => void;
}

export const MaintenanceView: React.FC<MaintenanceViewProps> = ({
  tickets,
  technicians,
  currentUser,
  onOpenReportModal,
  onUpdateTicketStatus
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [selectedTicket, setSelectedTicket] = useState<MaintenanceTicket | null>(null);
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [repairAction, setRepairAction] = useState('');
  const [partsUsedInput, setPartsUsedInput] = useState('');

  // Downloading state
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [rbacError, setRbacError] = useState<{ ticketId: string; message: string } | null>(null);
  const [expandedAuditId, setExpandedAuditId] = useState<string | null>(null);

  const filteredTickets = tickets.filter(t => {
    const matchesSearch = 
      t.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.buildingName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (t.roomNumber && t.roomNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (t.workOrderId && t.workOrderId.toLowerCase().includes(searchTerm.toLowerCase())) ||
      t.category.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || t.status === statusFilter;
    const matchesSeverity = severityFilter === 'all' || t.severity === severityFilter;

    return matchesSearch && matchesStatus && matchesSeverity;
  });

  const criticalCount = tickets.filter(t => t.severity === 'critical' && t.status !== 'resolved').length;
  const inProgressCount = tickets.filter(t => t.status === 'in_progress').length;
  const resolvedCount = tickets.filter(t => t.status === 'resolved').length;

  // Handle PDF report download (Task 7 B, D, E)
  const handleDownloadPdf = async (ticket: MaintenanceTicket) => {
    setDownloadingId(ticket.id);
    setRbacError(null);

    try {
      const res = await fetch(`/api/complaints/${ticket.id}/report?userId=${currentUser.id}&userRole=${currentUser.role}`, {
        headers: {
          'x-user-id': currentUser.id,
          'x-user-role': currentUser.role
        }
      });

      if (!res.ok) {
        if (res.status === 403) {
          const errData = await res.json().catch(() => ({}));
          setRbacError({
            ticketId: ticket.id,
            message: errData.error || 'Access Denied: You do not have permission to view or download this complaint report under your role.'
          });
          return;
        }
        throw new Error('Failed to generate PDF report');
      }

      // Convert to blob and download
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `CampusOps_Complaint_${ticket.id}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (err: any) {
      alert(`Download Error: ${err.message}`);
    } finally {
      setDownloadingId(null);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* RBAC Access Denied Modal */}
      {rbacError && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-[#12131A] border border-red-500/40 rounded-2xl w-full max-w-md shadow-2xl p-6 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-red-500/15 border border-red-500/30 flex items-center justify-center mx-auto text-red-400">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">RBAC Access Control Violation (HTTP 403)</h3>
              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                {rbacError.message}
              </p>
              <div className="mt-3 p-2.5 rounded-xl bg-[#181A24] border border-[#252630] text-[11px] text-slate-300 font-mono">
                Your Active Role: <strong className="text-white">{ROLE_LABELS[currentUser.role]}</strong>
              </div>
            </div>
            <button
              onClick={() => setRbacError(null)}
              className="w-full py-2.5 rounded-xl bg-[#252630] hover:bg-slate-700 text-white text-xs font-semibold cursor-pointer transition-colors"
            >
              Acknowledge & Close
            </button>
          </div>
        </div>
      )}

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <Wrench className="w-6 h-6 text-[#8B5CF6]" />
            Maintenance & Facility Complaints
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time technician auto-dispatch, verifiable audit logs, and downloadable official PDF complaint reports.
          </p>
        </div>

        <button
          onClick={onOpenReportModal}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#7B2CBF] to-[#8B5CF6] text-white text-xs font-semibold hover:brightness-110 active:scale-95 transition-all shadow-[0_0_15px_rgba(139,92,246,0.35)] cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Complaint Ticket</span>
        </button>
      </div>

      {/* Stats Counter Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-xl bg-[#0B0C14] border border-[#1E2030]">
          <span className="text-[11px] text-slate-400 block">Total Tickets</span>
          <span className="text-xl font-bold text-white font-mono">{tickets.length}</span>
        </div>
        <div className="p-3.5 rounded-xl bg-[#0B0C14] border border-[#1E2030]">
          <span className="text-[11px] text-slate-400 block">Critical Pending</span>
          <span className="text-xl font-bold text-red-400 font-mono">{criticalCount}</span>
        </div>
        <div className="p-3.5 rounded-xl bg-[#0B0C14] border border-[#1E2030]">
          <span className="text-[11px] text-slate-400 block">In Progress</span>
          <span className="text-xl font-bold text-amber-400 font-mono">{inProgressCount}</span>
        </div>
        <div className="p-3.5 rounded-xl bg-[#0B0C14] border border-[#1E2030]">
          <span className="text-[11px] text-slate-400 block">Resolved</span>
          <span className="text-xl font-bold text-emerald-400 font-mono">{resolvedCount}</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 transform -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search tickets by title, building, room, WO number, or category..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#0B0C14] border border-[#1E2030] text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#00F5FF]"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2.5 rounded-xl bg-[#0B0C14] border border-[#1E2030] text-xs text-slate-200 focus:outline-none focus:border-[#00F5FF] cursor-pointer"
          >
            <option value="all">All Statuses</option>
            <option value="open">Open / Pending</option>
            <option value="assigned">Assigned</option>
            <option value="in_progress">In Progress</option>
            <option value="resolved">Resolved</option>
          </select>

          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="px-3 py-2.5 rounded-xl bg-[#0B0C14] border border-[#1E2030] text-xs text-slate-200 focus:outline-none focus:border-[#00F5FF] cursor-pointer"
          >
            <option value="all">All Severities</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
      </div>

      {/* Tickets List */}
      <div className="space-y-3">
        {filteredTickets.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-[#0B0C14] border border-[#1E2030]">
            <Wrench className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-300">No maintenance tickets found</p>
            <p className="text-xs text-slate-500 mt-1">Adjust filters or submit a new report</p>
          </div>
        ) : (
          filteredTickets.map((t) => (
            <div
              key={t.id}
              className={`p-5 rounded-2xl border transition-all ${
                selectedTicket?.id === t.id
                  ? 'bg-[#141526] border-[#8B5CF6] shadow-[0_0_20px_rgba(139,92,246,0.2)]'
                  : 'bg-[#0B0C14] border-[#1E2030] hover:border-slate-600'
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                <div className="flex-1 space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                      t.severity === 'critical' ? 'bg-red-500/20 text-red-400 border border-red-500/40' :
                      t.severity === 'high' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' :
                      'bg-blue-500/20 text-blue-400 border border-blue-500/40'
                    }`}>
                      {t.severity}
                    </span>

                    <span className="px-2 py-0.5 rounded text-[10px] bg-[#121320] text-slate-300 border border-slate-700 font-mono">
                      {t.id}
                    </span>

                    {t.workOrderId && (
                      <span className="px-2 py-0.5 rounded text-[10px] bg-[#00F5FF]/15 text-[#00F5FF] border border-[#00F5FF]/40 font-mono font-bold">
                        {t.workOrderId}
                      </span>
                    )}

                    <span className="px-2 py-0.5 rounded text-[10px] bg-[#8B5CF6]/15 text-[#A78BFA] border border-[#8B5CF6]/30">
                      {t.category}
                    </span>

                    <span className="text-[11px] text-slate-500">
                      Reported: {new Date(t.reportedAt).toLocaleDateString()}
                    </span>

                    {t.isDuplicate && (
                      <span className="px-2 py-0.5 rounded text-[10px] bg-purple-500/20 text-purple-400 border border-purple-500/30">
                        Duplicate Merged
                      </span>
                    )}

                    {t.incidentId && (
                      <span className="px-2 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-400 border border-amber-500/30 font-mono">
                        Incident Linked
                      </span>
                    )}
                  </div>

                  <h3 className="text-base font-bold text-white">
                    {t.title}
                  </h3>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {t.description}
                  </p>

                  {/* Location & Technician Meta */}
                  <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-slate-400 pt-1">
                    <span className="flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-[#00F5FF]" />
                      {t.buildingName} {t.roomNumber ? `• Room ${t.roomNumber}` : ''}
                    </span>

                    <span className="flex items-center gap-1.5">
                      <UserIcon className="w-3.5 h-3.5 text-slate-500" />
                      Assigned: <strong className="text-slate-200 font-medium">{t.assignedTechnicianName || 'Unassigned (Pending Dispatch)'}</strong>
                    </span>

                    {t.assetName && (
                      <span className="flex items-center gap-1.5">
                        <Tag className="w-3.5 h-3.5 text-slate-500" />
                        Asset: <strong className="text-slate-300">{t.assetName}</strong>
                      </span>
                    )}
                  </div>

                  {/* Target Completion / Resolution Banner */}
                  <div className="pt-1">
                    {t.status === 'resolved' ? (
                      <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center justify-between">
                        <span className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 shrink-0" />
                          <span>Resolved on {new Date(t.resolvedAt || t.reportedAt).toLocaleDateString()} by {t.assignedTechnicianName || 'Technician'}</span>
                        </span>
                        {t.verifiedBy && <span className="text-[11px] text-emerald-300">Verified by {t.verifiedBy}</span>}
                      </div>
                    ) : t.estimatedResolution ? (
                      <div className="p-2 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-300 text-xs flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                        <span>Target Resolution: <strong>{new Date(t.estimatedResolution).toLocaleString()}</strong></span>
                      </div>
                    ) : (
                      <div className="p-2 rounded-xl bg-[#181A24] border border-[#252630] text-slate-400 text-xs flex items-center gap-2 italic">
                        <Clock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                        <span>Resolution time not yet estimated.</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Right Action Buttons */}
                <div className="flex flex-wrap lg:flex-col items-end gap-2 shrink-0 pt-2 lg:pt-0">
                  {/* Download PDF Report Button (Task 7 B, D, E) */}
                  <button
                    onClick={() => handleDownloadPdf(t)}
                    disabled={downloadingId === t.id}
                    className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#121320] hover:bg-[#1A1C2E] text-white text-xs font-semibold border border-[#25283D] hover:border-[#00F5FF]/60 transition-all shadow-md cursor-pointer group"
                    title="Generate and download official PDF complaint report"
                  >
                    <Download className={`w-3.5 h-3.5 text-[#00F5FF] group-hover:scale-110 transition-transform ${downloadingId === t.id ? 'animate-bounce' : ''}`} />
                    <span>{downloadingId === t.id ? 'Generating PDF...' : 'Download PDF Report'}</span>
                  </button>

                  {/* Toggle Audit History Drawer */}
                  <button
                    onClick={() => setExpandedAuditId(expandedAuditId === t.id ? null : t.id)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#0F1018] hover:bg-[#151624] text-slate-300 text-xs font-medium border border-[#1E2030] transition-colors cursor-pointer"
                  >
                    <History className="w-3.5 h-3.5 text-slate-400" />
                    <span>Audit Trail ({t.history?.length || 1})</span>
                    {expandedAuditId === t.id ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>

                  {/* Status Action Buttons (Restricted to Authorized Repair Roles) */}
                  {t.status !== 'resolved' && (currentUser.role === 'TECHNICIAN' || currentUser.role === 'FACILITIES_ADMIN' || currentUser.role === 'SYSTEM_ADMIN') && (
                    <div className="flex items-center gap-2 mt-1">
                      {t.status !== 'in_progress' && (
                        <button
                          onClick={() => onUpdateTicketStatus(t.id, 'in_progress')}
                          className="px-3 py-1.5 rounded-xl bg-[#1A1B28] hover:bg-[#25283D] text-slate-200 text-xs font-semibold transition-colors cursor-pointer"
                        >
                          Mark In Progress
                        </button>
                      )}
                      <button
                        onClick={() => {
                          setSelectedTicket(t);
                          setResolutionNotes('');
                          setRepairAction('');
                          setPartsUsedInput('');
                        }}
                        className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 text-xs font-semibold border border-emerald-500/40 transition-colors cursor-pointer"
                      >
                        Resolve Ticket
                      </button>
                    </div>
                  )}

                  {t.status === 'resolved' && (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/10 text-emerald-400 text-xs font-semibold border border-emerald-500/30">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Resolved & Signed
                    </span>
                  )}
                </div>
              </div>

              {/* Chronological Audit Trail Drawer */}
              {expandedAuditId === t.id && (
                <div className="mt-4 pt-4 border-t border-[#1E2030] space-y-2.5 animate-in fade-in">
                  <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <History className="w-3.5 h-3.5 text-[#00F5FF]" />
                    Chronological Lifecycle Audit History (Complaint #{t.id})
                  </span>

                  <div className="space-y-1.5">
                    {(t.history && t.history.length > 0 ? t.history : [
                      {
                        id: 'hist-def',
                        timestamp: t.reportedAt,
                        action: 'REPORTED',
                        actorName: t.reportedBy,
                        actorRole: 'Complainant',
                        details: 'Initial complaint filed.'
                      }
                    ]).map((h, i) => (
                      <div key={h.id || i} className="p-2.5 rounded-xl bg-[#0B0C10] border border-[#1E202B] flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-2">
                        <div className="flex items-center gap-2.5">
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-[#1C1E2A] text-slate-300 border border-slate-700">
                            {h.action}
                          </span>
                          <span className="text-white font-medium">{h.details}</span>
                        </div>
                        <div className="flex items-center gap-3 text-[11px] text-slate-400 shrink-0">
                          <span>{h.actorName} ({h.actorRole})</span>
                          <span className="font-mono text-slate-500">
                            {new Date(h.timestamp).toLocaleString('en-US', { timeZone: 'UTC', dateStyle: 'short', timeStyle: 'short' })} UTC
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Resolution Notes Modal Drawer when clicking Resolve Ticket */}
              {selectedTicket?.id === t.id && (
                <div className="mt-4 pt-4 border-t border-[#252630] space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-200 block">
                      Technician Resolution & Sign-Off Certification
                    </label>
                    <span className="text-[11px] text-slate-400">Verifying as: {currentUser.name}</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">Repair Actions Taken</label>
                      <input
                        type="text"
                        value={repairAction}
                        onChange={(e) => setRepairAction(e.target.value)}
                        placeholder="e.g. Recalibrated differential sensor & replaced fuse"
                        className="w-full p-2.5 rounded-lg bg-[#0d0e14] border border-[#252630] text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">Replacement Parts Used (Optional)</label>
                      <input
                        type="text"
                        value={partsUsedInput}
                        onChange={(e) => setPartsUsedInput(e.target.value)}
                        placeholder="e.g. 1x HDMI Switcher, 2x Cable Ties (comma-separated)"
                        className="w-full p-2.5 rounded-lg bg-[#0d0e14] border border-[#252630] text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Technician Resolution Summary</label>
                    <textarea
                      rows={2}
                      value={resolutionNotes}
                      onChange={(e) => setResolutionNotes(e.target.value)}
                      placeholder="Describe how the repair was completed and verified operational..."
                      className="w-full p-2.5 rounded-lg bg-[#0d0e14] border border-[#252630] text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      onClick={() => setSelectedTicket(null)}
                      className="px-3 py-1.5 rounded-lg text-xs text-slate-400 hover:text-white cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => {
                        const finalNotes = resolutionNotes || repairAction || 'Repairs completed and verified operational.';
                        onUpdateTicketStatus(t.id, 'resolved', finalNotes);
                        setSelectedTicket(null);
                      }}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-all shadow-lg shadow-emerald-600/20 cursor-pointer"
                    >
                      Confirm Resolution & Update Report
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
