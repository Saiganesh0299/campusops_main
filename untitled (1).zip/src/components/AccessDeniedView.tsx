import React from 'react';
import { User, ROLE_LABELS, ROLE_COLORS } from '../types/rbac';
import { ShieldAlert, ArrowLeft, Lock, UserCheck } from 'lucide-react';

interface AccessDeniedViewProps {
  currentUser: User;
  requiredRole?: string;
  moduleName: string;
  onNavigateHome: () => void;
  onOpenAuth: () => void;
}

export const AccessDeniedView: React.FC<AccessDeniedViewProps> = ({
  currentUser,
  requiredRole,
  moduleName,
  onNavigateHome,
  onOpenAuth
}) => {
  const roleStyle = ROLE_COLORS[currentUser.role];

  return (
    <div className="min-h-[75vh] flex items-center justify-center p-6">
      <div className="w-full max-w-lg p-8 rounded-3xl bg-[#0F1015] border border-rose-500/30 shadow-[0_0_50px_rgba(244,63,94,0.15)] text-center space-y-6 relative overflow-hidden">
        {/* Glow Accent */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-2 bg-gradient-to-r from-transparent via-rose-500 to-transparent blur-sm" />

        <div className="w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center mx-auto text-rose-400 shadow-lg shadow-rose-500/20">
          <ShieldAlert className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <span className="font-mono text-xs font-bold px-3 py-1 rounded-full bg-rose-500/15 text-rose-400 border border-rose-500/30">
            HTTP 403 • ACCESS RESTRICTED
          </span>
          <h2 className="text-2xl font-black text-white tracking-tight">
            Role Permission Insufficient
          </h2>
          <p className="text-xs text-slate-400 leading-relaxed max-w-md mx-auto">
            You do not have authorization to view the <strong className="text-white">{moduleName}</strong> module under the current CampusOps zero-trust RBAC policy.
          </p>
        </div>

        {/* Current Identity vs Requirement Card */}
        <div className="p-4 rounded-2xl bg-[#14151E] border border-[#252630] text-left space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Current Logged-in Identity:</span>
            <span className="font-bold text-white">{currentUser.name}</span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Assigned Operational Role:</span>
            <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${roleStyle.bg} ${roleStyle.text} ${roleStyle.border}`}>
              {ROLE_LABELS[currentUser.role]}
            </span>
          </div>

          {requiredRole && (
            <div className="flex items-center justify-between text-xs border-t border-[#252630]/60 pt-2">
              <span className="text-slate-400">Required Authorization:</span>
              <span className="font-mono text-xs font-bold text-purple-400">
                {requiredRole}
              </span>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <button
            onClick={onNavigateHome}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 text-white text-xs font-semibold flex items-center justify-center gap-2 border border-[#1E2030] transition-all cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Unified Campus
          </button>

          <button
            onClick={onOpenAuth}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#7B2CBF] to-[#00F5FF] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(123,44,191,0.35)] hover:brightness-110 transition-all cursor-pointer"
          >
            <UserCheck className="w-4 h-4" />
            Switch Account / Role
          </button>
        </div>
      </div>
    </div>
  );
};
