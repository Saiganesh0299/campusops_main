import React, { useState, useEffect } from 'react';
import { User, ROLE_LABELS, ROLE_COLORS } from '../types/rbac';
import { 
  FileText, 
  Search, 
  Filter, 
  Clock, 
  ShieldCheck, 
  UserCheck, 
  ShoppingBag, 
  Wrench, 
  KeyRound, 
  RefreshCw,
  Calendar,
  AlertTriangle
} from 'lucide-react';

export interface AuditLogItem {
  id: string;
  userId?: string;
  userName?: string;
  userRole?: string;
  action: string;
  entityType: string;
  entityId: string;
  description: string;
  timestamp: string;
  ipAddress?: string;
}

const INITIAL_MOCK_LOGS: AuditLogItem[] = [
  {
    id: 'log-101',
    userName: 'Dr. Marcus Vance',
    userRole: 'SYSTEM_ADMIN',
    action: 'INITIALIZE_RBAC',
    entityType: 'Security',
    entityId: 'POLICY_ROOT',
    description: 'CampusOps 6-Role Hierarchical RBAC and Department Scopes initialized.',
    timestamp: '2026-10-30T09:45:00Z',
    ipAddress: '10.0.4.1 (Campus Core Gateway)'
  },
  {
    id: 'log-102',
    userName: 'Arthur Pendelton',
    userRole: 'PROCUREMENT',
    action: 'APPROVE_PURCHASE',
    entityType: 'PurchaseRequest',
    entityId: 'PR-2026-0042',
    description: 'Approved acquisition of Tektronix Oscilloscope Probes ($3,750.00) under FY26 EE Lab Budget.',
    timestamp: '2026-10-30T09:20:00Z',
    ipAddress: '10.0.12.84 (Procurement Workstation)'
  },
  {
    id: 'log-103',
    userName: 'Dr. Marcus Vance',
    userRole: 'SYSTEM_ADMIN',
    action: 'CONFIGURE_PERMISSION',
    entityType: 'User',
    entityId: 'usr-manager-ee',
    description: 'Delegated purchase approval authority (purchases:approve, DEPARTMENT scope) to Prof. Elena Rostova.',
    timestamp: '2026-10-30T09:05:00Z',
    ipAddress: '10.0.4.1 (Admin Console)'
  },
  {
    id: 'log-104',
    userName: 'Dennis Ritchie',
    userRole: 'TECHNICIAN',
    action: 'CREATE_PURCHASE_REQUEST',
    entityType: 'PurchaseRequest',
    entityId: 'PR-2026-0041',
    description: 'Submitted purchase request for 4x Optoma 4K UHD Solid-State Laser Lamp Units ($1,310.00).',
    timestamp: '2026-10-28T10:30:00Z',
    ipAddress: '10.0.18.22 (Facilities Mobile Node)'
  },
  {
    id: 'log-105',
    userName: 'Sarah Jenkins',
    userRole: 'FACILITIES_ADMIN',
    action: 'ASSIGN_WORK_ORDER',
    entityType: 'WorkOrder',
    entityId: 'WO-261030-0001',
    description: 'Assigned electrical repair in ACAD-101 to Senior Technician Dennis Ritchie.',
    timestamp: '2026-10-27T08:15:00Z',
    ipAddress: '10.0.8.14 (Operations Center)'
  },
  {
    id: 'log-106',
    userName: 'Alex Rivera',
    userRole: 'STUDENT_FACULTY',
    action: 'CREATE_COMPLAINT',
    entityType: 'Complaint',
    entityId: 'CMP-261030-0001',
    description: 'Reported ceiling lighting panel flickering rapidly in Computer Vision Studio (ACAD-101).',
    timestamp: '2026-10-26T14:30:00Z',
    ipAddress: '10.128.44.102 (Student Wi-Fi)'
  }
];

export const ActivityLogsView: React.FC<{ currentUser: User }> = ({ currentUser }) => {
  const [logs, setLogs] = useState<AuditLogItem[]>(INITIAL_MOCK_LOGS);
  const [searchQuery, setSearchQuery] = useState('');
  const [actionFilter, setActionFilter] = useState('ALL');

  // Filter logs according to role scope: System Admin sees ALL, others see their own or department
  const filteredLogs = logs.filter(log => {
    const matchesSearch = 
      log.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (log.userName && log.userName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      log.action.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.entityId.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesAction = actionFilter === 'ALL' || log.action.includes(actionFilter);

    if (currentUser.role === 'SYSTEM_ADMIN') {
      return matchesSearch && matchesAction;
    }
    // Scope check: Student sees only own logs
    if (currentUser.role === 'STUDENT_FACULTY') {
      return matchesSearch && matchesAction && log.userName?.toLowerCase().includes(currentUser.name.toLowerCase());
    }
    return matchesSearch && matchesAction;
  });

  const getActionBadge = (action: string) => {
    if (action.includes('USER') || action.includes('ROLE')) {
      return 'bg-rose-500/15 text-rose-400 border-rose-500/30';
    }
    if (action.includes('PURCHASE') || action.includes('APPROVE')) {
      return 'bg-purple-500/15 text-purple-400 border-purple-500/30';
    }
    if (action.includes('WORK_ORDER') || action.includes('ASSIGN')) {
      return 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30';
    }
    if (action.includes('COMPLAINT')) {
      return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
    }
    return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-[#0B0C14] border border-[#1E2030]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-xl font-extrabold text-white tracking-tight">
              Security Audit & Activity Logs
            </h1>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#7B2CBF]/20 text-[#A78BFA] border border-[#7B2CBF]/40">
              IMMUTABLE AUDIT TRAIL
            </span>
          </div>
          <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
            Tamper-evident chronological audit log recording authentication challenges, role adjustments, permission delegations, work order dispatches, and purchase authorizations.
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="p-4 rounded-xl bg-[#0B0C14] border border-[#1E2030] flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search audit records by actor, action, entity code, or keywords..."
            className="w-full pl-10 pr-4 py-2 bg-[#0E101A] border border-[#1E2030] rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#00F5FF]"
          />
        </div>
        <div className="flex items-center gap-2">
          <select
            value={actionFilter}
            onChange={(e) => setActionFilter(e.target.value)}
            className="px-3 py-2 bg-[#0E101A] border border-[#1E2030] rounded-xl text-xs text-slate-200 focus:outline-none focus:border-[#00F5FF] cursor-pointer"
          >
            <option value="ALL">All Event Types</option>
            <option value="USER">User & Identity Events</option>
            <option value="PURCHASE">Procurement & Approvals</option>
            <option value="WORK_ORDER">Work Order Dispatches</option>
            <option value="COMPLAINT">Complaint Reports</option>
          </select>
        </div>
      </div>

      {/* Log Entries */}
      <div className="rounded-2xl bg-[#0B0C14] border border-[#1E2030] overflow-hidden shadow-xl">
        <div className="divide-y divide-[#1E2030]/60">
          {filteredLogs.length === 0 ? (
            <div className="p-12 text-center text-slate-500 text-xs">
              No audit logs recorded matching current criteria.
            </div>
          ) : (
            filteredLogs.map((log) => (
              <div key={log.id} className="p-4 hover:bg-[#0E101A] transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="space-y-1.5 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${getActionBadge(log.action)}`}>
                      {log.action}
                    </span>
                    <span className="font-mono text-[11px] text-slate-400 bg-slate-900 px-1.5 py-0.2 rounded border border-slate-800">
                      {log.entityType} #{log.entityId}
                    </span>
                    <span className="text-[11px] font-bold text-white flex items-center gap-1">
                      <UserCheck className="w-3.5 h-3.5 text-[#00F5FF]" />
                      {log.userName}
                    </span>
                  </div>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    {log.description}
                  </p>
                </div>
                <div className="text-right sm:text-right flex flex-col sm:items-end gap-1 shrink-0">
                  <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-500" />
                    {new Date(log.timestamp).toLocaleString()}
                  </span>
                  {log.ipAddress && (
                    <span className="text-[10px] font-mono text-slate-400">
                      {log.ipAddress}
                    </span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
