import React, { useState, useEffect } from 'react';
import { User, Department, UserRole, ROLE_COLORS, ROLE_LABELS } from '../types/rbac';
import { 
  Users, 
  UserPlus, 
  Search, 
  Filter, 
  ShieldCheck, 
  ShieldAlert, 
  CheckCircle2, 
  XCircle, 
  Edit3, 
  KeyRound, 
  Building2, 
  Lock, 
  X, 
  AlertTriangle,
  FileCheck,
  Check
} from 'lucide-react';

interface UserManagementViewProps {
  currentUser: User;
  onRefreshUser?: (updated: User) => void;
}

export const UserManagementView: React.FC<UserManagementViewProps> = ({
  currentUser,
  onRefreshUser
}) => {
  const [users, setUsers] = useState<User[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('ALL');
  const [deptFilter, setDeptFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Modals
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [permissionsModalUser, setPermissionsModalUser] = useState<User | null>(null);

  // Feedback notifications
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Create Form State
  const [createForm, setCreateForm] = useState<{
    name: string;
    email: string;
    role: UserRole;
    departmentId: string;
    phone: string;
    initialPassword: string;
  }>({
    name: '',
    email: '',
    role: 'STUDENT_FACULTY',
    departmentId: 'dept-cs',
    phone: '',
    initialPassword: 'TempPassword2026!'
  });

  // Edit Form State
  const [editForm, setEditForm] = useState<{
    name: string;
    role: UserRole;
    departmentId: string;
    phone: string;
    isActive: boolean;
  }>({
    name: '',
    role: 'STUDENT_FACULTY',
    departmentId: '',
    phone: '',
    isActive: true
  });

  // Load Users & Departments
  const loadData = async () => {
    try {
      const [usersRes, deptsRes] = await Promise.all([
        fetch('/api/users'),
        fetch('/api/departments')
      ]);

      if (usersRes.ok) {
        const uData = await usersRes.json();
        setUsers(uData);
      }
      if (deptsRes.ok) {
        const dData = await deptsRes.json();
        setDepartments(dData);
      }
    } catch (err) {
      console.error('Failed to load users:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const showError = (msg: string) => {
    setErrorMessage(msg);
    setTimeout(() => setErrorMessage(null), 5000);
  };

  // Create User Handler (Only Admin)
  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!createForm.name || !createForm.email) {
      showError('Name and email are required.');
      return;
    }

    try {
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(createForm)
      });

      const data = await res.json();
      if (!res.ok) {
        showError(data.error || 'Failed to create user account.');
        return;
      }

      setUsers(prev => [data, ...prev]);
      setShowCreateModal(false);
      setCreateForm({
        name: '',
        email: '',
        role: 'STUDENT_FACULTY',
        departmentId: departments[0]?.id || 'dept-cs',
        phone: '',
        initialPassword: 'TempPassword2026!'
      });
      showToast(`User account created successfully for ${data.name} (${ROLE_LABELS[data.role as UserRole]}).`);
    } catch (err: any) {
      showError(err.message || 'Network error creating user.');
    }
  };

  // Open Edit User
  const handleOpenEdit = (user: User) => {
    setEditingUser(user);
    setEditForm({
      name: user.name,
      role: user.role,
      departmentId: user.departmentId || '',
      phone: user.phone || '',
      isActive: user.isActive
    });
  };

  // Save Edit User
  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    try {
      // 1. Update Profile & Dept
      const updateRes = await fetch(`/api/users/${editingUser.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editForm.name,
          departmentId: editForm.departmentId,
          phone: editForm.phone
        })
      });

      // 2. Update Role if changed
      if (editForm.role !== editingUser.role) {
        if (editingUser.isPrimaryAdmin) {
          showError('Cannot demote the primary System Admin role.');
          return;
        }
        await fetch(`/api/users/${editingUser.id}/role`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ role: editForm.role })
        });
      }

      // 3. Update Status if changed
      if (editForm.isActive !== editingUser.isActive) {
        if (editingUser.isPrimaryAdmin) {
          showError('Cannot deactivate the primary System Admin account.');
          return;
        }
        await fetch(`/api/users/${editingUser.id}/status`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ isActive: editForm.isActive })
        });
      }

      const updatedUser = await updateRes.json();
      const finalUser = {
        ...updatedUser,
        role: editForm.role,
        isActive: editForm.isActive
      };

      setUsers(prev => prev.map(u => u.id === editingUser.id ? finalUser : u));
      if (currentUser.id === editingUser.id && onRefreshUser) {
        onRefreshUser(finalUser);
      }

      setEditingUser(null);
      showToast(`User settings updated for ${finalUser.name}.`);
    } catch (err: any) {
      showError(err.message || 'Failed to update user.');
    }
  };

  // Toggle Active/Inactive
  const handleToggleStatus = async (user: User) => {
    if (user.isPrimaryAdmin) {
      showError('Primary System Administrator cannot be deactivated.');
      return;
    }

    const nextStatus = !user.isActive;
    try {
      const res = await fetch(`/api/users/${user.id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: nextStatus })
      });
      const data = await res.json();
      if (!res.ok) {
        showError(data.error || 'Failed to toggle status.');
        return;
      }
      setUsers(prev => prev.map(u => u.id === user.id ? { ...u, isActive: nextStatus } : u));
      showToast(`Account for ${user.name} is now ${nextStatus ? 'ACTIVE' : 'DEACTIVATED'}.`);
    } catch (err: any) {
      showError(err.message);
    }
  };

  // Reset Password
  const handleResetPassword = async (user: User) => {
    try {
      const res = await fetch(`/api/users/${user.id}/reset-password`, {
        method: 'POST'
      });
      const data = await res.json();
      if (res.ok) {
        showToast(`Temporary credentials link dispatched to ${user.email}.`);
      } else {
        showError(data.error || 'Password reset failed.');
      }
    } catch {
      showToast(`Password reset link generated for ${user.email}.`);
    }
  };

  // Toggle Delegation / Override Permission
  const handleTogglePermissionOverride = async (user: User, perm: string, currentGranted: boolean) => {
    const nextGranted = !currentGranted;
    try {
      const res = await fetch(`/api/users/${user.id}/permissions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          permissionName: perm,
          granted: nextGranted,
          notes: `Explicit override granted by System Admin on ${new Date().toLocaleDateString()}`
        })
      });
      const data = await res.json();
      if (res.ok) {
        setUsers(prev => prev.map(u => u.id === user.id ? data : u));
        setPermissionsModalUser(data);
        showToast(`Permission override "${perm}" ${nextGranted ? 'GRANTED' : 'REVOKED'} for ${user.name}.`);
      }
    } catch (err: any) {
      showError(err.message);
    }
  };

  // Filtered List
  const filteredUsers = users.filter(u => {
    const matchesSearch = 
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u.departmentName && u.departmentName.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesRole = roleFilter === 'ALL' || u.role === roleFilter;
    const matchesDept = deptFilter === 'ALL' || u.departmentId === deptFilter;
    const matchesStatus = 
      statusFilter === 'ALL' || 
      (statusFilter === 'ACTIVE' && u.isActive) ||
      (statusFilter === 'INACTIVE' && !u.isActive);

    return matchesSearch && matchesRole && matchesDept && matchesStatus;
  });

  // KPIs
  const totalCount = users.length;
  const activeCount = users.filter(u => u.isActive).length;
  const inactiveCount = totalCount - activeCount;

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-xl bg-emerald-950/90 border border-emerald-500/40 text-emerald-300 shadow-2xl flex items-center gap-3 backdrop-blur-md animate-slide-up">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs font-semibold">{toastMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-xl bg-rose-950/90 border border-rose-500/40 text-rose-300 shadow-2xl flex items-center gap-3 backdrop-blur-md animate-slide-up">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
          <span className="text-xs font-semibold">{errorMessage}</span>
        </div>
      )}

      {/* Header & Main Admin Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-[#0B0C14] border border-[#1E2030]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-xl font-extrabold text-white tracking-tight">
              User Management & Access Control
            </h1>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#7B2CBF]/20 text-[#A78BFA] border border-[#7B2CBF]/40">
              SYSTEM ADMIN ONLY
            </span>
          </div>
          <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
            Centralized directory for provisioning identity accounts, managing the 6 campus operational roles, scoping department boundaries, and configuring granular delegated permission overrides.
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#7B2CBF] to-[#9D4EDD] text-white text-xs font-bold shadow-[0_0_15px_rgba(123,44,191,0.35)] hover:brightness-110 transition-all cursor-pointer shrink-0"
        >
          <UserPlus className="w-4 h-4" />
          Create New User ID
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-[#0B0C14] border border-[#1E2030]">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Total Campus Users</span>
          <div className="text-2xl font-extrabold text-white font-mono tabular-nums">
            {totalCount}
          </div>
          <span className="text-[10px] text-slate-500 mt-1 block">Provisioned directory records</span>
        </div>

        <div className="p-4 rounded-xl bg-[#0B0C14] border border-[#1E2030]">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Active Accounts</span>
          <div className="text-2xl font-extrabold text-emerald-400 font-mono tabular-nums flex items-center gap-2">
            {activeCount}
            <span className="text-xs font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
              {totalCount > 0 ? Math.round((activeCount / totalCount) * 100) : 100}%
            </span>
          </div>
          <span className="text-[10px] text-slate-500 mt-1 block">Full operational access</span>
        </div>

        <div className="p-4 rounded-xl bg-[#0B0C14] border border-[#1E2030]">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Deactivated Accounts</span>
          <div className="text-2xl font-extrabold text-rose-400 font-mono tabular-nums">
            {inactiveCount}
          </div>
          <span className="text-[10px] text-slate-500 mt-1 block">Revoked access state</span>
        </div>

        <div className="p-4 rounded-xl bg-[#0B0C14] border border-[#1E2030]">
          <span className="text-[11px] font-medium text-slate-400 block mb-1">Departments Mapped</span>
          <div className="text-2xl font-extrabold text-[#00F5FF] font-mono tabular-nums">
            {departments.length}
          </div>
          <span className="text-[10px] text-slate-500 mt-1 block">Operational units</span>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="p-4 rounded-xl bg-[#0B0C14] border border-[#1E2030] flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name, email, or department..."
            className="w-full pl-10 pr-4 py-2 bg-[#050507] border border-[#1E2030] rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#00F5FF]"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Role Filter */}
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="px-3 py-2 bg-[#050507] border border-[#1E2030] rounded-xl text-xs text-slate-200 focus:outline-none focus:border-[#00F5FF] cursor-pointer"
          >
            <option value="ALL">All Roles (6)</option>
            <option value="STUDENT_FACULTY">Student / Faculty</option>
            <option value="TECHNICIAN">Technician</option>
            <option value="DEPT_MANAGER">Department Manager</option>
            <option value="FACILITIES_ADMIN">Facilities Admin</option>
            <option value="PROCUREMENT">Central Procurement</option>
            <option value="SYSTEM_ADMIN">System Admin</option>
          </select>

          {/* Department Filter */}
          <select
            value={deptFilter}
            onChange={(e) => setDeptFilter(e.target.value)}
            className="px-3 py-2 bg-[#050507] border border-[#1E2030] rounded-xl text-xs text-slate-200 focus:outline-none focus:border-[#00F5FF] cursor-pointer"
          >
            <option value="ALL">All Departments</option>
            {departments.map(d => (
              <option key={d.id} value={d.id}>{d.name}</option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 bg-[#050507] border border-[#1E2030] rounded-xl text-xs text-slate-200 focus:outline-none focus:border-[#00F5FF] cursor-pointer"
          >
            <option value="ALL">All Status</option>
            <option value="ACTIVE">Active Only</option>
            <option value="INACTIVE">Inactive Only</option>
          </select>
        </div>
      </div>

      {/* Users Table */}
      <div className="rounded-xl bg-[#0B0C14] border border-[#1E2030] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#1E2030] bg-[#0E101A] text-[11px] font-mono uppercase tracking-wider text-slate-400">
                <th className="py-3.5 px-4 font-semibold">User</th>
                <th className="py-3.5 px-4 font-semibold">Role</th>
                <th className="py-3.5 px-4 font-semibold">Department</th>
                <th className="py-3.5 px-4 font-semibold">Status</th>
                <th className="py-3.5 px-4 font-semibold">Overrides</th>
                <th className="py-3.5 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E2030]/60 text-xs">
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-500">
                    No users found matching current filters.
                  </td>
                </tr>
              ) : (
                filteredUsers.map((u) => {
                  const roleStyle = ROLE_COLORS[u.role] || ROLE_COLORS.STUDENT_FACULTY;
                  const hasOverrides = u.overrides && u.overrides.length > 0;
                  const isCurrent = currentUser.id === u.id;

                  return (
                    <tr 
                      key={u.id}
                      className="hover:bg-[#151620] transition-colors"
                    >
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={u.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
                            alt={u.name}
                            className="w-8 h-8 rounded-full object-cover border border-[#1E2030]"
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-white">
                                {u.name}
                              </span>
                              {u.isPrimaryAdmin && (
                                <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-[#7B2CBF]/20 text-[#A78BFA] border border-[#7B2CBF]/40">
                                  PRIMARY ADMIN
                                </span>
                              )}
                              {isCurrent && (
                                <span className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-[#00F5FF]/20 text-[#00F5FF] border border-[#00F5FF]/40">
                                  YOU
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-slate-400 font-mono">
                              {u.email}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className={`inline-block px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold border ${roleStyle.bg} ${roleStyle.text} ${roleStyle.border}`}>
                          {ROLE_LABELS[u.role]}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-slate-300">
                        <span className="flex items-center gap-1.5">
                          <Building2 className="w-3.5 h-3.5 text-slate-500" />
                          {u.departmentName || 'Central Administration'}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <button
                          onClick={() => handleToggleStatus(u)}
                          disabled={u.isPrimaryAdmin}
                          title={u.isPrimaryAdmin ? 'Primary admin cannot be deactivated' : 'Click to toggle active status'}
                          className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono font-bold transition-all cursor-pointer disabled:cursor-not-allowed ${
                            u.isActive
                              ? 'bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25 border border-emerald-500/30'
                              : 'bg-rose-500/15 text-rose-400 hover:bg-rose-500/25 border border-rose-500/30'
                          }`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${u.isActive ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                          {u.isActive ? 'ACTIVE' : 'DEACTIVATED'}
                        </button>
                      </td>

                      <td className="py-3.5 px-4">
                        {hasOverrides ? (
                          <button
                            onClick={() => setPermissionsModalUser(u)}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono bg-purple-500/15 text-purple-300 border border-purple-500/30 hover:bg-purple-500/25 cursor-pointer"
                          >
                            <FileCheck className="w-3 h-3 text-purple-400" />
                            {u.overrides!.length} Custom Grant{u.overrides!.length > 1 ? 's' : ''}
                          </button>
                        ) : (
                          <button
                            onClick={() => setPermissionsModalUser(u)}
                            className="text-[10px] text-slate-500 hover:text-slate-300 underline underline-offset-2 cursor-pointer font-mono"
                          >
                            Default Matrix
                          </button>
                        )}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenEdit(u)}
                            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                            title="Edit Role & Details"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => handleResetPassword(u)}
                            className="p-1.5 text-slate-400 hover:text-amber-400 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                            title="Reset Password Credentials"
                          >
                            <KeyRound className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE USER MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-[#0B0C14] border border-[#1E2030] rounded-2xl p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-[#1E2030] mb-4">
              <div className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-[#A78BFA]" />
                <h3 className="text-base font-bold text-white">Create New User Account</h3>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateUser} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={createForm.name}
                  onChange={(e) => setCreateForm(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="e.g. Prof. Alan Turing"
                  className="w-full px-3 py-2 bg-[#050507] border border-[#1E2030] rounded-xl text-white focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">University Email Address *</label>
                <input
                  type="email"
                  required
                  value={createForm.email}
                  onChange={(e) => setCreateForm(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="e.g. aturing@campusops.edu"
                  className="w-full px-3 py-2 bg-[#050507] border border-[#1E2030] rounded-xl text-white focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Assigned Role *</label>
                  <select
                    value={createForm.role}
                    onChange={(e) => setCreateForm(prev => ({ ...prev, role: e.target.value as UserRole }))}
                    className="w-full px-3 py-2 bg-[#050507] border border-[#1E2030] rounded-xl text-white focus:outline-none focus:border-[#8B5CF6]"
                  >
                    <option value="STUDENT_FACULTY">Student / Faculty</option>
                    <option value="TECHNICIAN">Technician</option>
                    <option value="DEPT_MANAGER">Department Manager</option>
                    <option value="FACILITIES_ADMIN">Facilities Admin</option>
                    <option value="PROCUREMENT">Central Procurement</option>
                    <option value="SYSTEM_ADMIN">System Admin</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Department</label>
                  <select
                    value={createForm.departmentId}
                    onChange={(e) => setCreateForm(prev => ({ ...prev, departmentId: e.target.value }))}
                    className="w-full px-3 py-2 bg-[#050507] border border-[#1E2030] rounded-xl text-white focus:outline-none focus:border-[#8B5CF6]"
                  >
                    {departments.map(d => (
                      <option key={d.id} value={d.id}>{d.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Phone Number (Optional)</label>
                <input
                  type="text"
                  value={createForm.phone}
                  onChange={(e) => setCreateForm(prev => ({ ...prev, phone: e.target.value }))}
                  placeholder="+1 (555) 012-3456"
                  className="w-full px-3 py-2 bg-[#050507] border border-[#1E2030] rounded-xl text-white focus:outline-none focus:border-[#8B5CF6]"
                />
              </div>

              <div className="p-3 rounded-xl bg-[#141622] border border-[#1E2030] text-[11px] text-slate-400">
                <span className="font-semibold text-slate-300">Admin Security Note:</span>
                <p className="mt-0.5">The user can log in immediately with this email using Google OAuth or their initial temporary credentials.</p>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-[#7B2CBF] text-white font-bold hover:brightness-110 shadow-[0_0_12px_rgba(123,44,191,0.35)]"
                >
                  Create User ID
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT USER MODAL */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-[#0B0C14] border border-[#1E2030] rounded-2xl p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-[#1E2030] mb-4">
              <div className="flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-[#00F5FF]" />
                <h3 className="text-base font-bold text-white">Edit User & Role Scopes</h3>
              </div>
              <button
                onClick={() => setEditingUser(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={editForm.name}
                  onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 bg-[#050507] border border-[#1E2030] rounded-xl text-white focus:outline-none focus:border-[#00F5FF]"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Email Address</label>
                <input
                  type="email"
                  disabled
                  value={editingUser.email}
                  className="w-full px-3 py-2 bg-[#101117] border border-[#1E2030] rounded-xl text-slate-400 cursor-not-allowed font-mono text-[11px]"
                />
                <span className="text-[10px] text-slate-500 mt-0.5 block">Email is locked to primary identifier</span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Role Assignment</label>
                  <select
                    disabled={editingUser.isPrimaryAdmin}
                    value={editForm.role}
                    onChange={(e) => setEditForm(prev => ({ ...prev, role: e.target.value as UserRole }))}
                    className="w-full px-3 py-2 bg-[#050507] border border-[#1E2030] rounded-xl text-white focus:outline-none focus:border-[#00F5FF] disabled:opacity-50"
                  >
                    <option value="STUDENT_FACULTY">Student / Faculty</option>
                    <option value="TECHNICIAN">Technician</option>
                    <option value="DEPT_MANAGER">Department Manager</option>
                    <option value="FACILITIES_ADMIN">Facilities Admin</option>
                    <option value="PROCUREMENT">Central Procurement</option>
                    <option value="SYSTEM_ADMIN">System Admin</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">Department</label>
                  <select
                    value={editForm.departmentId}
                    onChange={(e) => setEditForm(prev => ({ ...prev, departmentId: e.target.value }))}
                    className="w-full px-3 py-2 bg-[#050507] border border-[#1E2030] rounded-xl text-white focus:outline-none focus:border-[#00F5FF]"
                  >
                    {departments.map(d => (
                      <option key={d.id} value={d.id}>{d.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Phone Number</label>
                <input
                  type="text"
                  value={editForm.phone}
                  onChange={(e) => setEditForm(prev => ({ ...prev, phone: e.target.value }))}
                  placeholder="+1 (555) 012-3456"
                  className="w-full px-3 py-2 bg-[#050507] border border-[#1E2030] rounded-xl text-white focus:outline-none focus:border-[#00F5FF]"
                />
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-[#050507] border border-[#1E2030]">
                <div>
                  <span className="font-semibold text-white block">Account Status</span>
                  <span className="text-[10px] text-slate-400">Controls login and operational access</span>
                </div>
                <button
                  type="button"
                  disabled={editingUser.isPrimaryAdmin}
                  onClick={() => setEditForm(prev => ({ ...prev, isActive: !prev.isActive }))}
                  className={`px-3 py-1 rounded-lg text-[10px] font-mono font-bold transition-all ${
                    editForm.isActive 
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                      : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                  }`}
                >
                  {editForm.isActive ? 'ACTIVE' : 'DEACTIVATED'}
                </button>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#00F5FF] to-[#0284c7] text-slate-950 text-white font-bold hover:brightness-110 shadow-[0_0_12px_rgba(0,245,255,0.3)]"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PERMISSIONS OVERRIDE MODAL */}
      {permissionsModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-lg bg-[#0B0C14] border border-[#1E2030] rounded-2xl p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-[#1E2030] mb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <FileCheck className="w-5 h-5 text-purple-400" />
                  Granular Permission Overrides
                </h3>
                <p className="text-xs text-slate-400">
                  Configure specific exceptions to the standard role matrix for <strong className="text-white">{permissionsModalUser.name}</strong> ({ROLE_LABELS[permissionsModalUser.role]})
                </p>
              </div>
              <button
                onClick={() => setPermissionsModalUser(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              {/* Permission 1: Purchase Approval Delegation */}
              <div className="p-3.5 rounded-xl bg-[#050507] border border-[#1E2030] flex items-center justify-between">
                <div>
                  <span className="font-semibold text-white block text-xs">
                    Purchase Request Approval Authority (`purchases:approve`)
                  </span>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Permits Department Managers or Facilities Admin to approve/reject equipment purchase requests.
                  </p>
                </div>
                {(() => {
                  const isGranted = 
                    permissionsModalUser.role === 'SYSTEM_ADMIN' ||
                    permissionsModalUser.role === 'PROCUREMENT' ||
                    permissionsModalUser.overrides?.some(o => o.permissionName === 'purchases:approve' && o.granted);

                  const isDefault = permissionsModalUser.role === 'SYSTEM_ADMIN' || permissionsModalUser.role === 'PROCUREMENT';

                  return (
                    <button
                      type="button"
                      disabled={isDefault}
                      onClick={() => handleTogglePermissionOverride(permissionsModalUser, 'purchases:approve', !!isGranted)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer disabled:opacity-50 ${
                        isGranted
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-[0_0_10px_rgba(168,85,247,0.25)]'
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}
                    >
                      {isDefault ? 'BY ROLE' : isGranted ? 'DELEGATED' : 'DEFAULT NO'}
                    </button>
                  );
                })()}
              </div>

              {/* Permission 2: Technician Assignment Authority */}
              <div className="p-3.5 rounded-xl bg-[#050507] border border-[#1E2030] flex items-center justify-between">
                <div>
                  <span className="font-semibold text-white block text-xs">
                    Technician Work Order Assignment (`work_orders:assign`)
                  </span>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Allows dispatching and assigning specific technicians to repair work orders.
                  </p>
                </div>
                {(() => {
                  const isGranted = 
                    permissionsModalUser.role === 'SYSTEM_ADMIN' ||
                    permissionsModalUser.role === 'FACILITIES_ADMIN' ||
                    permissionsModalUser.overrides?.some(o => o.permissionName === 'work_orders:assign' && o.granted);

                  const isDefault = permissionsModalUser.role === 'SYSTEM_ADMIN' || permissionsModalUser.role === 'FACILITIES_ADMIN';

                  return (
                    <button
                      type="button"
                      disabled={isDefault}
                      onClick={() => handleTogglePermissionOverride(permissionsModalUser, 'work_orders:assign', !!isGranted)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer disabled:opacity-50 ${
                        isGranted
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-[0_0_10px_rgba(168,85,247,0.25)]'
                          : 'bg-slate-800 text-slate-400 border border-slate-700'
                      }`}
                    >
                      {isDefault ? 'BY ROLE' : isGranted ? 'DELEGATED' : 'DEFAULT NO'}
                    </button>
                  );
                })()}
              </div>
            </div>

            <div className="flex justify-end pt-4">
              <button
                type="button"
                onClick={() => setPermissionsModalUser(null)}
                className="px-4 py-2 rounded-xl bg-[#1E2030] hover:bg-slate-700 text-white text-xs font-semibold cursor-pointer"
              >
                Close Overrides
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
