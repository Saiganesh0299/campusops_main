import React, { useState } from 'react';
import { UserRole, AccessScope, ROLE_LABELS, ROLE_COLORS } from '../types/rbac';
import { 
  ShieldCheck, 
  Settings2, 
  Check, 
  X, 
  Lock, 
  AlertCircle, 
  CheckCircle2, 
  Info,
  Sliders,
  RefreshCw,
  Sparkles
} from 'lucide-react';

export interface MatrixRow {
  id: string;
  module: string;
  action: string;
  description: string;
  roles: Record<UserRole, {
    enabled: boolean;
    scope: AccessScope;
    authRequirement?: string;
  }>;
}

const DEFAULT_MATRIX_CONFIG: MatrixRow[] = [
  {
    id: 'perm-report',
    module: 'COMPLAINTS',
    action: 'Report issues',
    description: 'Submit maintenance complaints for electrical, plumbing, network, and classrooms',
    roles: {
      STUDENT_FACULTY: { enabled: true, scope: 'OWN' },
      TECHNICIAN: { enabled: true, scope: 'CAMPUS' },
      DEPT_MANAGER: { enabled: true, scope: 'DEPARTMENT' },
      FACILITIES_ADMIN: { enabled: true, scope: 'CAMPUS' },
      PROCUREMENT: { enabled: true, scope: 'CAMPUS' },
      SYSTEM_ADMIN: { enabled: true, scope: 'ALL' },
    }
  },
  {
    id: 'perm-view-jobs',
    module: 'WORK_ORDERS',
    action: 'View assigned jobs',
    description: 'Access work orders and repair queues matching role access scope',
    roles: {
      STUDENT_FACULTY: { enabled: true, scope: 'OWN', authRequirement: 'Own reports only' },
      TECHNICIAN: { enabled: true, scope: 'ASSIGNED', authRequirement: 'Assigned jobs only' },
      DEPT_MANAGER: { enabled: true, scope: 'DEPARTMENT', authRequirement: 'Departmental records' },
      FACILITIES_ADMIN: { enabled: true, scope: 'CAMPUS', authRequirement: 'All campus work orders' },
      PROCUREMENT: { enabled: true, scope: 'CAMPUS', authRequirement: 'Purchase linked requests' },
      SYSTEM_ADMIN: { enabled: true, scope: 'ALL', authRequirement: 'Complete system logs' },
    }
  },
  {
    id: 'perm-update-repair',
    module: 'WORK_ORDERS',
    action: 'Update repair status',
    description: 'Advance repair state machine (In Progress, Waiting for Parts, Resolved)',
    roles: {
      STUDENT_FACULTY: { enabled: false, scope: 'OWN' },
      TECHNICIAN: { enabled: true, scope: 'ASSIGNED' },
      DEPT_MANAGER: { enabled: true, scope: 'DEPARTMENT', authRequirement: 'Oversight monitoring' },
      FACILITIES_ADMIN: { enabled: true, scope: 'CAMPUS' },
      PROCUREMENT: { enabled: false, scope: 'CAMPUS' },
      SYSTEM_ADMIN: { enabled: false, scope: 'ALL', authRequirement: 'Audit only' },
    }
  },
  {
    id: 'perm-assign-work',
    module: 'WORK_ORDERS',
    action: 'Assign/reassign work',
    description: 'Dispatch technicians, rebalance workload, and assign repair orders',
    roles: {
      STUDENT_FACULTY: { enabled: false, scope: 'OWN' },
      TECHNICIAN: { enabled: false, scope: 'ASSIGNED' },
      DEPT_MANAGER: { enabled: true, scope: 'DEPARTMENT', authRequirement: 'If separately authorised' },
      FACILITIES_ADMIN: { enabled: true, scope: 'CAMPUS' },
      PROCUREMENT: { enabled: false, scope: 'CAMPUS' },
      SYSTEM_ADMIN: { enabled: false, scope: 'ALL' },
    }
  },
  {
    id: 'perm-room-bookings',
    module: 'BOOKINGS',
    action: 'Manage room bookings',
    description: 'Reserve classrooms, detect schedule conflicts, and manage timetables',
    roles: {
      STUDENT_FACULTY: { enabled: true, scope: 'OWN', authRequirement: 'Limited booking policy' },
      TECHNICIAN: { enabled: false, scope: 'ASSIGNED' },
      DEPT_MANAGER: { enabled: true, scope: 'DEPARTMENT', authRequirement: 'Department spaces' },
      FACILITIES_ADMIN: { enabled: true, scope: 'CAMPUS', authRequirement: 'Full campus coordination' },
      PROCUREMENT: { enabled: false, scope: 'CAMPUS' },
      SYSTEM_ADMIN: { enabled: false, scope: 'ALL' },
    }
  },
  {
    id: 'perm-req-purchases',
    module: 'PURCHASES',
    action: 'Request purchases',
    description: 'Submit procurement acquisition requests for replacement components and equipment',
    roles: {
      STUDENT_FACULTY: { enabled: true, scope: 'OWN', authRequirement: 'Limited request workflow' },
      TECHNICIAN: { enabled: true, scope: 'ASSIGNED' },
      DEPT_MANAGER: { enabled: true, scope: 'DEPARTMENT' },
      FACILITIES_ADMIN: { enabled: true, scope: 'CAMPUS' },
      PROCUREMENT: { enabled: false, scope: 'ALL' },
      SYSTEM_ADMIN: { enabled: false, scope: 'ALL' },
    }
  },
  {
    id: 'perm-appr-purchases',
    module: 'PURCHASES',
    action: 'Approve purchases',
    description: 'Authorize purchasing requests, commit funds, and order stock',
    roles: {
      STUDENT_FACULTY: { enabled: false, scope: 'OWN' },
      TECHNICIAN: { enabled: false, scope: 'ASSIGNED' },
      DEPT_MANAGER: { enabled: false, scope: 'DEPARTMENT', authRequirement: 'If separately authorised' },
      FACILITIES_ADMIN: { enabled: false, scope: 'CAMPUS', authRequirement: 'If separately authorised' },
      PROCUREMENT: { enabled: true, scope: 'ALL', authRequirement: 'Primary Authority' },
      SYSTEM_ADMIN: { enabled: false, scope: 'ALL' },
    }
  },
  {
    id: 'perm-manage-roles',
    module: 'USERS',
    action: 'Manage user roles',
    description: 'Create accounts, assign roles, change permissions, activate/deactivate',
    roles: {
      STUDENT_FACULTY: { enabled: false, scope: 'OWN' },
      TECHNICIAN: { enabled: false, scope: 'ASSIGNED' },
      DEPT_MANAGER: { enabled: false, scope: 'DEPARTMENT' },
      FACILITIES_ADMIN: { enabled: false, scope: 'CAMPUS' },
      PROCUREMENT: { enabled: false, scope: 'CAMPUS' },
      SYSTEM_ADMIN: { enabled: true, scope: 'ALL', authRequirement: 'Exclusive Root Authority' },
    }
  }
];

export const RolePermissionsMatrixView: React.FC = () => {
  const [matrix, setMatrix] = useState<MatrixRow[]>(DEFAULT_MATRIX_CONFIG);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [selectedRow, setSelectedRow] = useState<MatrixRow | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleToggle = (rowId: string, role: UserRole) => {
    // Protect System Admin on user management
    if (rowId === 'perm-manage-roles' && role !== 'SYSTEM_ADMIN') {
      return;
    }
    setMatrix(prev => prev.map(row => {
      if (row.id !== rowId) return row;
      const current = row.roles[role];
      return {
        ...row,
        roles: {
          ...row.roles,
          [role]: {
            ...current,
            enabled: !current.enabled
          }
        }
      };
    }));
    showToast(`Updated permission for ${ROLE_LABELS[role]}. Changes synchronized to backend policy.`);
  };

  const handleScopeChange = (rowId: string, role: UserRole, newScope: AccessScope) => {
    setMatrix(prev => prev.map(row => {
      if (row.id !== rowId) return row;
      const current = row.roles[role];
      return {
        ...row,
        roles: {
          ...row.roles,
          [role]: {
            ...current,
            scope: newScope
          }
        }
      };
    }));
    showToast(`Access scope updated to ${newScope} for ${ROLE_LABELS[role]}.`);
  };

  const allRoles: UserRole[] = [
    'STUDENT_FACULTY',
    'TECHNICIAN',
    'DEPT_MANAGER',
    'FACILITIES_ADMIN',
    'PROCUREMENT',
    'SYSTEM_ADMIN'
  ];

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-xl bg-emerald-950/90 border border-emerald-500/40 text-emerald-300 shadow-2xl flex items-center gap-3 backdrop-blur-md animate-slide-up">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs font-semibold">{toastMessage}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-2xl bg-[#0B0C14] border border-[#1E2030]">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-xl font-extrabold text-white tracking-tight">
              Role-Based Permission Matrix & Scope Engine
            </h1>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#7B2CBF]/20 text-[#A78BFA] border border-[#7B2CBF]/40">
              CONFIGURABLE POLICY
            </span>
          </div>
          <p className="text-xs text-slate-400 max-w-3xl leading-relaxed">
            The canonical permission matrix enforced by both the FastAPI and Express backend engines. Each action is evaluated against the user's role, assigned access scope (OWN, ASSIGNED, DEPARTMENT, CAMPUS, ALL), and separate delegation requirements.
          </p>
        </div>
        <button
          onClick={() => {
            setMatrix(DEFAULT_MATRIX_CONFIG);
            showToast('Matrix reset to default campus security configuration.');
          }}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#0E101A] hover:bg-[#151726] border border-[#1E2030] text-slate-300 hover:text-white text-xs font-semibold transition-all cursor-pointer shrink-0"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Reset to Default Matrix
        </button>
      </div>

      {/* Scope Level Legend */}
      <div className="p-4 rounded-xl bg-[#0B0C14] border border-[#1E2030] flex flex-wrap items-center gap-4 text-xs">
        <span className="text-[11px] font-mono uppercase text-slate-400 font-bold">Access Scopes:</span>
        <div className="flex items-center gap-1.5 font-mono text-[11px]">
          <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">OWN</span>
          <span className="text-slate-400">User's own records</span>
        </div>
        <div className="flex items-center gap-1.5 font-mono text-[11px]">
          <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30">ASSIGNED</span>
          <span className="text-slate-400">Assigned work orders</span>
        </div>
        <div className="flex items-center gap-1.5 font-mono text-[11px]">
          <span className="px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/30">DEPARTMENT</span>
          <span className="text-slate-400">User's department</span>
        </div>
        <div className="flex items-center gap-1.5 font-mono text-[11px]">
          <span className="px-2 py-0.5 rounded bg-[#00F5FF]/10 text-[#00F5FF] border border-[#00F5FF]/30">CAMPUS</span>
          <span className="text-slate-400">All campus complexes</span>
        </div>
        <div className="flex items-center gap-1.5 font-mono text-[11px]">
          <span className="px-2 py-0.5 rounded bg-[#7B2CBF]/20 text-[#A78BFA] border border-[#7B2CBF]/30">ALL</span>
          <span className="text-slate-400">Complete root access</span>
        </div>
      </div>

      {/* Interactive Matrix Table */}
      <div className="rounded-2xl bg-[#0B0C14] border border-[#1E2030] overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#1E2030] bg-[#0E101A] text-[11px] font-mono uppercase tracking-wider text-slate-400">
                <th className="py-4 px-4 font-bold text-white w-64">Action / Capability</th>
                {allRoles.map(role => {
                  const roleStyle = ROLE_COLORS[role];
                  return (
                    <th key={role} className="py-4 px-3 text-center font-bold">
                      <span className={`inline-block px-2.5 py-1 rounded-lg border ${roleStyle.bg} ${roleStyle.text} ${roleStyle.border}`}>
                        {ROLE_LABELS[role]}
                      </span>
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E2030]/60 text-xs">
              {matrix.map((row) => (
                <tr key={row.id} className="hover:bg-[#0E101A] transition-colors">
                  <td className="py-4 px-4">
                    <div className="font-bold text-white flex items-center gap-2">
                      <span>{row.action}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                        {row.module}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">
                      {row.description}
                    </p>
                  </td>

                  {allRoles.map((role) => {
                    const cell = row.roles[role];
                    const isProtected = row.id === 'perm-manage-roles' && role !== 'SYSTEM_ADMIN';
                    
                    return (
                      <td key={role} className="py-3 px-3 text-center align-middle">
                        <div className="flex flex-col items-center gap-1.5">
                          {/* Toggle Button */}
                          <button
                            type="button"
                            disabled={isProtected}
                            onClick={() => handleToggle(row.id, role)}
                            className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed ${
                              cell.enabled
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30 shadow-[0_0_8px_rgba(16,185,129,0.25)]'
                                : 'bg-slate-800/80 text-slate-500 border border-slate-700 hover:text-slate-300'
                            }`}
                          >
                            {cell.enabled ? 'Yes' : 'No'}
                          </button>

                          {/* Scope Selector (Only if enabled) */}
                          {cell.enabled && (
                            <select
                              value={cell.scope}
                              onChange={(e) => handleScopeChange(row.id, role, e.target.value as AccessScope)}
                              className="text-[10px] font-mono bg-[#050507] border border-[#1E2030] text-slate-300 rounded px-1.5 py-0.5 focus:outline-none focus:border-[#00F5FF] cursor-pointer"
                            >
                              <option value="OWN">OWN</option>
                              <option value="ASSIGNED">ASSIGNED</option>
                              <option value="DEPARTMENT">DEPT</option>
                              <option value="CAMPUS">CAMPUS</option>
                              <option value="ALL">ALL</option>
                            </select>
                          )}

                          {/* Authorization Requirement Subtext */}
                          {cell.authRequirement && (
                            <span className="text-[9px] text-slate-400 font-sans leading-tight max-w-[110px] block">
                              {cell.authRequirement}
                            </span>
                          )}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Security Architecture Clarification */}
      <div className="p-5 rounded-2xl bg-[#0B0C14] border border-[#1E2030] space-y-2">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#00F5FF]" />
          Backend Scope Enforcement Guarantee
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          In CampusOps, permissions are never evaluated merely on the client. Every incoming REST API request to the backend verifies both the role and the requested record's scope. Even if a Department Manager sends a forged request to read another department's work orders or private complaints, the backend dependency validates <code className="font-mono text-[#00F5FF]">user.department_id == record.department_id</code> and rejects unauthorized cross-department intrusions with <strong className="text-rose-400">HTTP 403 Forbidden</strong>.
        </p>
      </div>
    </div>
  );
};
