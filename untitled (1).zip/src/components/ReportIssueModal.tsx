import React, { useState, useEffect } from 'react';
import { Classroom, Building, TicketSeverity, MaintenanceTicket } from '../types/campus';
import { 
  Wrench, 
  AlertTriangle, 
  X, 
  Check, 
  ShieldAlert, 
  Sparkles, 
  Info, 
  Link2,
  CheckCircle2,
  Download,
  Clock,
  UserCheck
} from 'lucide-react';

interface ReportIssueModalProps {
  room?: Classroom;
  building: Building;
  onClose: () => void;
  onSuccess: (ticket: any) => void;
}

export const ReportIssueModal: React.FC<ReportIssueModalProps> = ({
  room,
  building,
  onClose,
  onSuccess
}) => {
  const [title, setTitle] = useState(room ? `Malfunction in ${room.roomNumber}` : 'Campus Facility Issue');
  const [category, setCategory] = useState<'Electrical' | 'HVAC' | 'Plumbing' | 'Audio/Visual' | 'Furniture' | 'Structural' | 'Network'>('Audio/Visual');
  const [severity, setSeverity] = useState<TicketSeverity>('high');
  const [description, setDescription] = useState('');
  const [reportedBy, setReportedBy] = useState('Campus Faculty');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Success view state
  const [submittedTicket, setSubmittedTicket] = useState<MaintenanceTicket | null>(null);
  const [downloadingReceipt, setDownloadingReceipt] = useState(false);

  // Duplicate candidate warning state
  const [duplicateWarning, setDuplicateWarning] = useState<any | null>(null);

  useEffect(() => {
    if (!title.trim() && !description.trim()) {
      setDuplicateWarning(null);
      return;
    }

    const timer = setTimeout(() => {
      fetch('/api/complaints/check-duplicate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          description,
          buildingId: building.id,
          roomId: room?.id,
          category
        })
      })
        .then(res => res.ok ? res.json() : null)
        .then(data => {
          if (data && data.hasPotentialDuplicates && data.topCandidate) {
            setDuplicateWarning(data.topCandidate);
          } else {
            setDuplicateWarning(null);
          }
        })
        .catch(() => {});
    }, 450);

    return () => clearTimeout(timer);
  }, [title, description, category, building.id, room?.id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Please provide a ticket title');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/maintenance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title,
          description,
          buildingId: building.id,
          roomId: room?.id,
          category,
          severity,
          reportedBy,
          duplicateOfId: duplicateWarning?.ticketId || undefined,
          isDuplicate: Boolean(duplicateWarning),
          duplicateConfidence: duplicateWarning?.similarityScore || undefined,
          duplicateReason: duplicateWarning?.reason || undefined
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to submit complaint');
      }

      setSubmittedTicket(data);
      onSuccess(data);
    } catch (err: any) {
      setError(err.message || 'Error filing maintenance ticket');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadReceipt = async () => {
    if (!submittedTicket) return;
    setDownloadingReceipt(true);
    try {
      const res = await fetch(`/api/complaints/${submittedTicket.id}/report?userId=usr-student-alex&userRole=STUDENT_FACULTY`);
      if (res.ok) {
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `CampusOps_Complaint_${submittedTicket.id}.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
    } catch {
      //
    } finally {
      setDownloadingReceipt(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in">
      <div className="bg-[#0B0C14] border border-[#1E2030] rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 bg-[#0E101A] border-b border-[#1E2030] flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono uppercase text-[#A78BFA] font-semibold flex items-center gap-1">
              <ShieldAlert className="w-3 h-3 text-[#00F5FF]" />
              <span>Log Maintenance Complaint</span>
            </span>
            <h3 className="text-base font-bold text-[#F5F7FA]">
              {room ? `Report Issue: ${room.roomNumber} (${room.name})` : `Report Issue: ${building.name}`}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-[#1E2030] text-zinc-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Confirmation Screen on Submission Success */}
        {submittedTicket ? (
          <div className="p-6 space-y-5 animate-in fade-in">
            <div className="text-center space-y-2">
              <div className="w-14 h-14 rounded-full bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-white">Complaint Logged & Dispatched</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Your maintenance complaint has been successfully recorded in the campus registry.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#0E101A] border border-[#1E2030] space-y-2.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Complaint Reference:</span>
                <span className="font-mono font-bold text-white bg-[#1A1C2A] px-2 py-0.5 rounded">{submittedTicket.id}</span>
              </div>
              {submittedTicket.workOrderId && (
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Assigned Work Order:</span>
                  <span className="font-mono font-bold text-[#00F5FF] bg-[#00F5FF]/10 px-2 py-0.5 rounded">{submittedTicket.workOrderId}</span>
                </div>
              )}
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Assigned Specialist:</span>
                <span className="font-semibold text-emerald-400 flex items-center gap-1">
                  <UserCheck className="w-3.5 h-3.5" />
                  {submittedTicket.assignedTechnicianName || 'Facilities Admin Queue'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Technician Notification:</span>
                <span className="text-emerald-400 text-[11px] font-mono">Dispatched via In-App & Email</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
              <button
                onClick={handleDownloadReceipt}
                disabled={downloadingReceipt}
                className="w-full sm:flex-1 py-2.5 rounded-xl bg-[#0E101A] hover:bg-[#151726] text-white text-xs font-semibold border border-[#1E2030] hover:border-[#00F5FF] flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
              >
                <Download className={`w-3.5 h-3.5 text-[#00F5FF] ${downloadingReceipt ? 'animate-bounce' : ''}`} />
                <span>{downloadingReceipt ? 'Generating PDF...' : 'Download PDF Report'}</span>
              </button>

              <button
                onClick={onClose}
                className="w-full sm:flex-1 py-2.5 rounded-xl bg-gradient-to-r from-[#7B2CBF] to-[#9D4EDD] text-white text-xs font-semibold hover:brightness-110 transition-all shadow-[0_0_15px_rgba(123,44,191,0.35)] cursor-pointer text-center"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          /* Form Body */
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {error && (
              <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/40 text-rose-400 text-xs">
                {error}
              </div>
            )}

            {/* Real-time AI Duplicate Detection Banner */}
            {duplicateWarning && (
              <div className="p-3.5 rounded-xl bg-[#00F5FF]/10 border border-[#00F5FF]/30 text-xs text-slate-300 space-y-1.5 animate-fade-in">
                <div className="flex items-center gap-2 text-[#00F5FF] font-bold">
                  <Sparkles className="w-4 h-4 text-[#A78BFA]" />
                  <span>Active Report Match Detected ({Math.round(duplicateWarning.similarityScore * 100)}% Similarity)</span>
                </div>
                <p className="text-[11px] text-slate-400">
                  A similar open ticket exists in this zone: <strong className="text-white">"{duplicateWarning.ticketTitle}"</strong> ({duplicateWarning.reason}).
                </p>
                <div className="flex items-center gap-1.5 text-[10px] text-emerald-400 pt-1">
                  <Check className="w-3.5 h-3.5" />
                  <span>Your complaint will be preserved independently with your own reporter record and correlated to the existing incident.</span>
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-mono text-zinc-300 uppercase mb-1.5">
                Issue Summary / Title *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Projector lamp flickering and overheating"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-[#050507] border border-[#1E2030] rounded-xl px-3.5 py-2 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-[#00F5FF]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-mono text-zinc-300 uppercase mb-1.5">
                  Category
                </label>
                <select
                  value={category}
                  onChange={(e: any) => setCategory(e.target.value)}
                  className="w-full bg-[#050507] border border-[#1E2030] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#00F5FF]"
                >
                  <option value="Audio/Visual">Audio / Visual</option>
                  <option value="Electrical">Electrical</option>
                  <option value="HVAC">HVAC / Climate</option>
                  <option value="Plumbing">Plumbing</option>
                  <option value="Network">Network / Wi-Fi</option>
                  <option value="Furniture">Furniture</option>
                  <option value="Structural">Structural</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono text-zinc-300 uppercase mb-1.5">
                  Urgency / Severity
                </label>
                <select
                  value={severity}
                  onChange={(e: any) => setSeverity(e.target.value)}
                  className="w-full bg-[#050507] border border-[#1E2030] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#00F5FF]"
                >
                  <option value="low">Low (Cosmetic / Routine)</option>
                  <option value="medium">Medium (Impaired Function)</option>
                  <option value="high">High (Classroom Blocked)</option>
                  <option value="critical">Critical (Immediate Danger / Safety)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono text-zinc-300 uppercase mb-1.5">
                Detailed Description
              </label>
              <textarea
                rows={3}
                placeholder="Provide symptoms, specific equipment, room location, or error codes..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full bg-[#050507] border border-[#1E2030] rounded-xl p-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#00F5FF]"
              />
            </div>

            <div>
              <label className="block text-xs font-mono text-zinc-300 uppercase mb-1.5">
                Reporter Identity
              </label>
              <input
                type="text"
                value={reportedBy}
                onChange={(e) => setReportedBy(e.target.value)}
                className="w-full bg-[#050507] border border-[#1E2030] rounded-xl px-3.5 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#00F5FF]"
              />
            </div>

            {/* Form Actions */}
            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-transparent hover:bg-[#1E2030] text-xs text-zinc-400 hover:text-white transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#7B2CBF] to-[#9D4EDD] text-white text-xs font-semibold hover:brightness-110 active:scale-95 transition-all shadow-[0_0_15px_rgba(123,44,191,0.35)] disabled:opacity-50 cursor-pointer flex items-center gap-1.5"
              >
                {loading ? (
                  <span>Submitting & Dispatching...</span>
                ) : (
                  <>
                    <Wrench className="w-3.5 h-3.5" />
                    <span>Submit Complaint Ticket</span>
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
