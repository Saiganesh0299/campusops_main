import { Building, Classroom, MaintenanceTicket, RoomBooking, InventoryItem, StaffTechnician, CampusIncident, DashboardMetrics } from '../types/campus';

export const initialBuildings: Building[] = [
  {
    id: 'bldg-civil',
    name: 'Civil Block',
    code: 'CVL',
    floorsCount: 7,
    classroomsCount: 18,
    equipmentCount: 96,
    openMaintenanceCount: 2,
    status: 'Operational',
    address: 'South-West Complex, EEC Campus',
    description: 'Premier infrastructure block housing Structural Engineering, Hydraulics, Soil Mechanics, Surveying, and CAD studios.',
    builtYear: 2018,
    totalAreaSqFt: 62000,
    currentEnergyKw: 118.5,
    campusPosition: {
      x: -6,
      z: 36,
      width: 34,
      depth: 16,
      heightPerFloor: 3.8,
      rotation: 0
    },
    floors: [
      { id: 'fl-cvl-0', buildingId: 'bldg-civil', floorNumber: 0, name: 'Ground Floor', levelLabel: 'Ground Floor', classroomCount: 3, activeIssuesCount: 1, occupancyRate: 80 },
      { id: 'fl-cvl-1', buildingId: 'bldg-civil', floorNumber: 1, name: 'First Floor', levelLabel: '1st Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 70 },
      { id: 'fl-cvl-2', buildingId: 'bldg-civil', floorNumber: 2, name: 'Second Floor', levelLabel: '2nd Floor', classroomCount: 3, activeIssuesCount: 1, occupancyRate: 65 },
      { id: 'fl-cvl-3', buildingId: 'bldg-civil', floorNumber: 3, name: 'Third Floor', levelLabel: '3rd Floor', classroomCount: 2, activeIssuesCount: 0, occupancyRate: 85 },
      { id: 'fl-cvl-4', buildingId: 'bldg-civil', floorNumber: 4, name: 'Fourth Floor', levelLabel: '4th Floor', classroomCount: 2, activeIssuesCount: 0, occupancyRate: 75 },
      { id: 'fl-cvl-5', buildingId: 'bldg-civil', floorNumber: 5, name: 'Fifth Floor', levelLabel: '5th Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 60 },
      { id: 'fl-cvl-6', buildingId: 'bldg-civil', floorNumber: 6, name: 'Sixth Floor', levelLabel: '6th Floor', classroomCount: 2, activeIssuesCount: 0, occupancyRate: 55 }
    ]
  },
  {
    id: 'bldg-main',
    name: 'Main Block',
    code: 'MAIN',
    floorsCount: 5,
    classroomsCount: 15,
    equipmentCount: 110,
    openMaintenanceCount: 3,
    status: 'Operational',
    address: 'North-West Quadrant, EEC Campus',
    description: 'Central administrative and academic nerve center containing Grand Auditorium, Digital Amphitheatres, and Council Chambers.',
    builtYear: 2014,
    totalAreaSqFt: 58000,
    currentEnergyKw: 154.2,
    campusPosition: {
      x: -36,
      z: -36,
      width: 28,
      depth: 24,
      heightPerFloor: 4.2,
      rotation: 0
    },
    floors: [
      { id: 'fl-main-0', buildingId: 'bldg-main', floorNumber: 0, name: 'Ground Floor', levelLabel: 'Ground Floor', classroomCount: 3, activeIssuesCount: 1, occupancyRate: 90 },
      { id: 'fl-main-1', buildingId: 'bldg-main', floorNumber: 1, name: 'First Floor', levelLabel: '1st Floor', classroomCount: 3, activeIssuesCount: 1, occupancyRate: 85 },
      { id: 'fl-main-2', buildingId: 'bldg-main', floorNumber: 2, name: 'Second Floor', levelLabel: '2nd Floor', classroomCount: 3, activeIssuesCount: 1, occupancyRate: 75 },
      { id: 'fl-main-3', buildingId: 'bldg-main', floorNumber: 3, name: 'Third Floor', levelLabel: '3rd Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 65 },
      { id: 'fl-main-4', buildingId: 'bldg-main', floorNumber: 4, name: 'Fourth Floor', levelLabel: '4th Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 70 }
    ]
  },
  {
    id: 'bldg-mech',
    name: 'Mechanical Block',
    code: 'MEC',
    floorsCount: 6,
    classroomsCount: 16,
    equipmentCount: 140,
    openMaintenanceCount: 2,
    status: 'Operational',
    address: 'South-East Zone (adjacent to EEC Main Gate), EEC Campus',
    description: 'Heavy engineering complex with CNC Machining Bays, Mechatronics Research, Heat Engines, and Fluid Mechanics.',
    builtYear: 2019,
    totalAreaSqFt: 54000,
    currentEnergyKw: 132.0,
    campusPosition: {
      x: 24,
      z: 36,
      width: 22,
      depth: 16,
      heightPerFloor: 3.9,
      rotation: 0
    },
    floors: [
      { id: 'fl-mech-0', buildingId: 'bldg-mech', floorNumber: 0, name: 'Ground Floor', levelLabel: 'Ground Floor', classroomCount: 3, activeIssuesCount: 1, occupancyRate: 85 },
      { id: 'fl-mech-1', buildingId: 'bldg-mech', floorNumber: 1, name: 'First Floor', levelLabel: '1st Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 75 },
      { id: 'fl-mech-2', buildingId: 'bldg-mech', floorNumber: 2, name: 'Second Floor', levelLabel: '2nd Floor', classroomCount: 3, activeIssuesCount: 1, occupancyRate: 65 },
      { id: 'fl-mech-3', buildingId: 'bldg-mech', floorNumber: 3, name: 'Third Floor', levelLabel: '3rd Floor', classroomCount: 2, activeIssuesCount: 0, occupancyRate: 80 },
      { id: 'fl-mech-4', buildingId: 'bldg-mech', floorNumber: 4, name: 'Fourth Floor', levelLabel: '4th Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 70 },
      { id: 'fl-mech-5', buildingId: 'bldg-mech', floorNumber: 5, name: 'Fifth Floor', levelLabel: '5th Floor', classroomCount: 2, activeIssuesCount: 0, occupancyRate: 60 }
    ]
  },
  {
    id: 'bldg-acad',
    name: 'Academic Block',
    code: 'ACAD',
    floorsCount: 7,
    classroomsCount: 22,
    equipmentCount: 165,
    openMaintenanceCount: 3,
    status: 'Operational',
    address: 'West Quad, EEC Campus',
    description: 'Advanced teaching block housing Computer Science, Artificial Intelligence, Smart Classrooms, and Sensor Network Labs.',
    builtYear: 2020,
    totalAreaSqFt: 65000,
    currentEnergyKw: 146.0,
    campusPosition: {
      x: -44,
      z: 8,
      width: 22,
      depth: 22,
      heightPerFloor: 3.8,
      rotation: 0
    },
    floors: [
      { id: 'fl-acad-0', buildingId: 'bldg-acad', floorNumber: 0, name: 'Ground Floor', levelLabel: 'Ground Floor', classroomCount: 4, activeIssuesCount: 1, occupancyRate: 88 },
      { id: 'fl-acad-1', buildingId: 'bldg-acad', floorNumber: 1, name: 'First Floor', levelLabel: '1st Floor', classroomCount: 3, activeIssuesCount: 1, occupancyRate: 82 },
      { id: 'fl-acad-2', buildingId: 'bldg-acad', floorNumber: 2, name: 'Second Floor', levelLabel: '2nd Floor', classroomCount: 3, activeIssuesCount: 1, occupancyRate: 78 },
      { id: 'fl-acad-3', buildingId: 'bldg-acad', floorNumber: 3, name: 'Third Floor', levelLabel: '3rd Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 85 },
      { id: 'fl-acad-4', buildingId: 'bldg-acad', floorNumber: 4, name: 'Fourth Floor', levelLabel: '4th Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 75 },
      { id: 'fl-acad-5', buildingId: 'bldg-acad', floorNumber: 5, name: 'Fifth Floor', levelLabel: '5th Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 65 },
      { id: 'fl-acad-6', buildingId: 'bldg-acad', floorNumber: 6, name: 'Sixth Floor', levelLabel: '6th Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 50 }
    ]
  },
  {
    id: 'bldg-admin',
    name: 'Admin Block',
    code: 'ADM',
    floorsCount: 5,
    classroomsCount: 12,
    equipmentCount: 78,
    openMaintenanceCount: 1,
    status: 'Operational',
    address: 'North Quad, EEC Campus',
    description: 'Executive complex housing the Registrar, Admissions Directorate, Examination Control, and University Governance.',
    builtYear: 2015,
    totalAreaSqFt: 42000,
    currentEnergyKw: 88.4,
    campusPosition: {
      x: 10,
      z: -36,
      width: 20,
      depth: 18,
      heightPerFloor: 4.0,
      rotation: 0
    },
    floors: [
      { id: 'fl-adm-0', buildingId: 'bldg-admin', floorNumber: 0, name: 'Ground Floor', levelLabel: 'Ground Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 92 },
      { id: 'fl-adm-1', buildingId: 'bldg-admin', floorNumber: 1, name: 'First Floor', levelLabel: '1st Floor', classroomCount: 2, activeIssuesCount: 1, occupancyRate: 85 },
      { id: 'fl-adm-2', buildingId: 'bldg-admin', floorNumber: 2, name: 'Second Floor', levelLabel: '2nd Floor', classroomCount: 2, activeIssuesCount: 0, occupancyRate: 80 },
      { id: 'fl-adm-3', buildingId: 'bldg-admin', floorNumber: 3, name: 'Third Floor', levelLabel: '3rd Floor', classroomCount: 2, activeIssuesCount: 0, occupancyRate: 70 },
      { id: 'fl-adm-4', buildingId: 'bldg-admin', floorNumber: 4, name: 'Fourth Floor', levelLabel: '4th Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 75 }
    ]
  },
  {
    id: 'bldg-block3',
    name: 'Block 3',
    code: 'BLK3',
    floorsCount: 9,
    classroomsCount: 26,
    equipmentCount: 185,
    openMaintenanceCount: 3,
    status: 'Operational',
    address: 'North-East Sector, EEC Campus',
    description: 'Flagship 9-story research high-rise for Advanced Computing, Cleanrooms, Nano-engineering, and Postgraduate Innovation.',
    builtYear: 2022,
    totalAreaSqFt: 82000,
    currentEnergyKw: 168.0,
    campusPosition: {
      x: 36,
      z: -36,
      width: 22,
      depth: 18,
      heightPerFloor: 3.7,
      rotation: 0
    },
    floors: [
      { id: 'fl-blk3-0', buildingId: 'bldg-block3', floorNumber: 0, name: 'Ground Floor', levelLabel: 'Ground Floor', classroomCount: 3, activeIssuesCount: 1, occupancyRate: 90 },
      { id: 'fl-blk3-1', buildingId: 'bldg-block3', floorNumber: 1, name: 'First Floor', levelLabel: '1st Floor', classroomCount: 3, activeIssuesCount: 1, occupancyRate: 85 },
      { id: 'fl-blk3-2', buildingId: 'bldg-block3', floorNumber: 2, name: 'Second Floor', levelLabel: '2nd Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 80 },
      { id: 'fl-blk3-3', buildingId: 'bldg-block3', floorNumber: 3, name: 'Third Floor', levelLabel: '3rd Floor', classroomCount: 3, activeIssuesCount: 1, occupancyRate: 75 },
      { id: 'fl-blk3-4', buildingId: 'bldg-block3', floorNumber: 4, name: 'Fourth Floor', levelLabel: '4th Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 70 },
      { id: 'fl-blk3-5', buildingId: 'bldg-block3', floorNumber: 5, name: 'Fifth Floor', levelLabel: '5th Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 65 },
      { id: 'fl-blk3-6', buildingId: 'bldg-block3', floorNumber: 6, name: 'Sixth Floor', levelLabel: '6th Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 60 },
      { id: 'fl-blk3-7', buildingId: 'bldg-block3', floorNumber: 7, name: 'Seventh Floor', levelLabel: '7th Floor', classroomCount: 2, activeIssuesCount: 0, occupancyRate: 55 },
      { id: 'fl-blk3-8', buildingId: 'bldg-block3', floorNumber: 8, name: 'Eighth Floor', levelLabel: '8th Floor', classroomCount: 3, activeIssuesCount: 0, occupancyRate: 50 }
    ]
  }
];

export const initialClassrooms: Classroom[] = [
  // Civil Block
  {
    id: 'room-cvl-001',
    buildingId: 'bldg-civil',
    floorId: 'fl-cvl-0',
    name: 'Hydraulics & Fluid Mechanics Lab',
    roomNumber: 'CVL-001',
    capacity: 45,
    type: 'Laboratory',
    status: 'maintenance',
    equipment: ['Hydraulic Flume Bench', 'Venturi Meter', 'Centrifugal Pump Test Rig', 'Digital Pressure Transducers'],
    equipmentCondition: 'Needs Attention',
    lastMaintenanceDate: '2026-10-18',
    gridPosition: { x: 40, y: 40, width: 260, height: 180 },
    features: ['High-flow drainage', '3-Phase 415V power', 'Safety eyewash station']
  },
  {
    id: 'room-cvl-002',
    buildingId: 'bldg-civil',
    floorId: 'fl-cvl-0',
    name: 'Heavy Structures Testing Bay',
    roomNumber: 'CVL-002',
    capacity: 35,
    type: 'Workshop',
    status: 'available',
    equipment: ['2000kN Compression Testing Machine', 'Universal Testing Machine', 'Extensometer'],
    equipmentCondition: 'Excellent',
    lastMaintenanceDate: '2026-10-24',
    gridPosition: { x: 330, y: 40, width: 260, height: 180 },
    features: ['Overhead 5-ton crane', 'Reinforced slab', 'Acoustic baffle damping']
  },
  {
    id: 'room-cvl-101',
    buildingId: 'bldg-civil',
    floorId: 'fl-cvl-1',
    name: 'Civil CAD & GIS Studio',
    roomNumber: 'CVL-101',
    capacity: 60,
    type: 'Computer Lab',
    status: 'available',
    equipment: ['60x HP Z-Workstations', 'Autodesk AEC Suite', 'ArcGIS Enterprise', 'Plotter HP DesignJet T830'],
    equipmentCondition: 'Good',
    lastMaintenanceDate: '2026-10-15',
    gridPosition: { x: 40, y: 40, width: 320, height: 200 },
    features: ['Gigabit LAN', 'Dual 4K ceiling projectors', 'Central UPS backup']
  },

  // Main Block
  {
    id: 'room-main-001',
    buildingId: 'bldg-main',
    floorId: 'fl-main-0',
    name: 'Grand Central Auditorium',
    roomNumber: 'MAIN-001',
    capacity: 450,
    type: 'Auditorium',
    status: 'booked',
    equipment: ['Christie 4K Laser Projection', 'Line Array Audio System', 'Dual Wireless Shure Mics', 'Broadcast DMX Lighting'],
    equipmentCondition: 'Excellent',
    lastMaintenanceDate: '2026-10-22',
    gridPosition: { x: 40, y: 40, width: 420, height: 280 },
    features: ['Motorized stage', 'Simultaneous interpretation booth', 'Live stream control room']
  },
  {
    id: 'room-main-101',
    buildingId: 'bldg-main',
    floorId: 'fl-main-1',
    name: 'Executive Council Chamber',
    roomNumber: 'MAIN-101',
    capacity: 40,
    type: 'Conference Room',
    status: 'available',
    equipment: ['85" Interactive Samsung Flip', 'Cisco Webex Room Kit Pro', 'Delegate Gooseneck Mics'],
    equipmentCondition: 'Good',
    lastMaintenanceDate: '2026-10-12',
    gridPosition: { x: 40, y: 40, width: 260, height: 180 },
    features: ['Soundproofed acoustic walls', 'Executive leather seating', 'Dedicated pantry link']
  },

  // Mechanical Block
  {
    id: 'room-mech-001',
    buildingId: 'bldg-mech',
    floorId: 'fl-mech-0',
    name: 'CNC Precision Machining Center',
    roomNumber: 'MEC-001',
    capacity: 30,
    type: 'Workshop',
    status: 'maintenance',
    equipment: ['Haas 3-Axis CNC Mill', 'Mazak CNC Lathe', 'Wire EDM Unit', 'Mitutoyo CMM'],
    equipmentCondition: 'Fair',
    lastMaintenanceDate: '2026-10-20',
    gridPosition: { x: 40, y: 40, width: 300, height: 200 },
    features: ['Mist extraction system', 'Compressed air 8-bar manifold', 'Industrial coolant filtration']
  },
  {
    id: 'room-mech-101',
    buildingId: 'bldg-mech',
    floorId: 'fl-mech-1',
    name: 'Automotive & IC Engines Lab',
    roomNumber: 'MEC-101',
    capacity: 40,
    type: 'Laboratory',
    status: 'available',
    equipment: ['Eddy Current Dynamometer', 'Multi-cylinder Petrol & Diesel Test Beds', 'Exhaust Gas Analyzer'],
    equipmentCondition: 'Good',
    lastMaintenanceDate: '2026-10-25',
    gridPosition: { x: 40, y: 40, width: 280, height: 180 },
    features: ['Exhaust extraction hood', 'Vibration isolated mounts', 'Fuel storage containment']
  },

  // Academic Block
  {
    id: 'room-acad-101',
    buildingId: 'bldg-acad',
    floorId: 'fl-acad-1',
    name: 'Smart Interactive Lecture Hall A',
    roomNumber: 'ACAD-101',
    capacity: 90,
    type: 'Smart Classroom',
    status: 'maintenance',
    equipment: ['Epson Laser Projector', 'Crestron Touch Controller', 'JBL Ceiling Speakers', 'Document Camera'],
    equipmentCondition: 'Needs Attention',
    lastMaintenanceDate: '2026-10-10',
    gridPosition: { x: 40, y: 40, width: 280, height: 190 },
    features: ['Tiered acoustic seating', 'Dual camera lecture capture', 'Podium HDMI/Type-C']
  },
  {
    id: 'room-acad-201',
    buildingId: 'bldg-acad',
    floorId: 'fl-acad-2',
    name: 'AI & Data Science Computing Center',
    roomNumber: 'ACAD-201',
    capacity: 65,
    type: 'Computer Lab',
    status: 'available',
    equipment: ['NVIDIA DGX Workstation A100', '60x Dell Precision i9 Workstations', 'Dual 10Gbps SFP+ uplinks'],
    equipmentCondition: 'Excellent',
    lastMaintenanceDate: '2026-10-26',
    gridPosition: { x: 40, y: 40, width: 340, height: 210 },
    features: ['Precision climate control 20°C', 'Clean power distribution', 'Biometric door lock']
  },

  // Admin Block
  {
    id: 'room-adm-101',
    buildingId: 'bldg-admin',
    floorId: 'fl-adm-1',
    name: 'Academic Affairs Boardroom',
    roomNumber: 'ADM-101',
    capacity: 25,
    type: 'Conference Room',
    status: 'available',
    equipment: ['Sony Bravia 75" Commercial Display', 'Poly Studio X50 Bar', 'Wireless Barco ClickShare'],
    equipmentCondition: 'Good',
    lastMaintenanceDate: '2026-10-19',
    gridPosition: { x: 40, y: 40, width: 240, height: 160 },
    features: ['Custom boardroom table', 'Conference telephone', 'Blackout motorized blinds']
  },

  // Block 3
  {
    id: 'room-blk3-101',
    buildingId: 'bldg-block3',
    floorId: 'fl-blk3-1',
    name: 'Nanotech Micro-Fabrication Lab',
    roomNumber: 'BLK3-101',
    capacity: 20,
    type: 'Research Core',
    status: 'maintenance',
    equipment: ['Class 1000 Cleanroom Flow Hood', 'Spin Coater', 'Scanning Electron Microscope (SEM)', 'Sputter Coater'],
    equipmentCondition: 'Needs Attention',
    lastMaintenanceDate: '2026-10-14',
    gridPosition: { x: 40, y: 40, width: 300, height: 210 },
    features: ['HEPA filtration ISO-6', 'Deionized water loop', 'Liquid nitrogen gas lines']
  },
  {
    id: 'room-blk3-201',
    buildingId: 'bldg-block3',
    floorId: 'fl-blk3-2',
    name: 'IoT & Embedded Systems Prototyping',
    roomNumber: 'BLK3-201',
    capacity: 40,
    type: 'Laboratory',
    status: 'available',
    equipment: ['Keysight Mixed Signal Oscilloscopes', 'Rohde & Schwarz Spectrum Analyzer', 'SMD Rework Station'],
    equipmentCondition: 'Excellent',
    lastMaintenanceDate: '2026-10-27',
    gridPosition: { x: 40, y: 40, width: 270, height: 180 },
    features: ['Anti-static ESD grounding benches', 'Fume extractors', 'Component dispensary']
  }
];

export const initialTickets: MaintenanceTicket[] = [
  {
    id: 'tic-261030-001',
    title: 'Hydraulic Test Bench Digital Manifold Calibration Fault',
    description: 'Pressure differential sensors on the primary flume bench fluctuate erratically by ±18 PSI. Requires multimeter diagnostics and sensor recalibration.',
    buildingId: 'bldg-civil',
    buildingName: 'Civil Block',
    floorId: 'fl-cvl-0',
    roomId: 'room-cvl-001',
    roomNumber: 'CVL-001',
    category: 'Electrical',
    severity: 'high',
    status: 'assigned',
    reportedBy: 'Alex Chen (Student)',
    reporterEmail: 'student.alex@campusops.edu',
    reportedAt: '2026-10-30T08:30:00Z',
    workOrderId: 'WO-261030-001',
    assetName: 'Armfield S6 Hydraulic Flume Test Bench',
    assetTag: 'AST-CVL-FLM-04',
    assignedTechnicianId: 'tech-1',
    assignedTechnicianName: 'Dennis Ritchie',
    assignedDepartment: 'Campus Facilities & Infrastructure',
    assignedTechnicianEmail: 'dennis.ritchie@campusops.edu',
    assignedTechnicianPhone: '+1 (555) 301-4421',
    estimatedResolution: '2026-10-30T17:00:00Z',
    history: [
      {
        id: 'hist-001-1',
        timestamp: '2026-10-30T08:30:00Z',
        action: 'REPORTED',
        actorName: 'Alex Chen',
        actorRole: 'Student',
        details: 'Initial complaint filed via Student Portal for CVL-001.'
      },
      {
        id: 'hist-001-2',
        timestamp: '2026-10-30T08:31:00Z',
        action: 'ASSIGNED',
        actorName: 'System Dispatch Engine',
        actorRole: 'System Admin',
        details: 'Auto-assigned to Dennis Ritchie based on Electrical skill match and Civil Block proximity.'
      }
    ]
  },
  {
    id: 'tic-261030-002',
    title: 'Digital Manifold Erratic Reading in Hydraulic Lab',
    description: 'Water pressure gauges in CVL-001 reading inconsistent numbers during morning lab session.',
    buildingId: 'bldg-civil',
    buildingName: 'Civil Block',
    floorId: 'fl-cvl-0',
    roomId: 'room-cvl-001',
    roomNumber: 'CVL-001',
    category: 'Electrical',
    severity: 'high',
    status: 'open',
    reportedBy: 'Kavita Rao (Lab Assistant)',
    reporterEmail: 'kavita.rao@campusops.edu',
    reportedAt: '2026-10-30T09:10:00Z',
    duplicateOfId: 'tic-261030-001',
    isDuplicate: true,
    duplicateConfidence: 0.94,
    duplicateReason: 'Same room (CVL-001), same equipment (Hydraulic Flume), reported within 45 minutes.',
    history: [
      {
        id: 'hist-002-1',
        timestamp: '2026-10-30T09:10:00Z',
        action: 'REPORTED',
        actorName: 'Kavita Rao',
        actorRole: 'Lab Assistant',
        details: 'Reported secondary observation of erratic water pressure reading.'
      }
    ]
  },
  {
    id: 'tic-261030-003',
    title: 'Ceiling Laser Projector Optical Unit Flicker & Color Shift',
    description: 'During CS301 morning lecture, the front laser projector flashed purple and shut down repeatedly under thermal cutoff warning.',
    buildingId: 'bldg-acad',
    buildingName: 'Academic Block',
    floorId: 'fl-acad-1',
    roomId: 'room-acad-101',
    roomNumber: 'ACAD-101',
    category: 'Audio/Visual',
    severity: 'medium',
    status: 'assigned',
    reportedBy: 'Prof. David Krum (Faculty)',
    reporterEmail: 'david.krum@campusops.edu',
    reportedAt: '2026-10-30T07:45:00Z',
    workOrderId: 'WO-261030-003',
    assetName: 'Optoma 4K UHD Solid-State Laser Projector',
    assetTag: 'AST-ACAD-PRJ-101',
    assignedTechnicianId: 'tech-2',
    assignedTechnicianName: 'Linus Torvalds',
    assignedDepartment: 'Campus Facilities & Infrastructure',
    assignedTechnicianEmail: 'linus.torvalds@campusops.edu',
    assignedTechnicianPhone: '+1 (555) 301-8842',
    // Deliberately undefined estimatedResolution to test authentic banner "Resolution time not yet estimated."
    history: [
      {
        id: 'hist-003-1',
        timestamp: '2026-10-30T07:45:00Z',
        action: 'REPORTED',
        actorName: 'Prof. David Krum',
        actorRole: 'Faculty',
        details: 'Reported projector thermal shutdown during lecture.'
      },
      {
        id: 'hist-003-2',
        timestamp: '2026-10-30T07:46:00Z',
        action: 'ASSIGNED',
        actorName: 'System Dispatch Engine',
        actorRole: 'System Admin',
        details: 'Auto-assigned to Linus Torvalds based on AV specialty match.'
      }
    ]
  },
  {
    id: 'tic-261030-004',
    title: 'Epson Projector Overheating in ACAD-101',
    description: 'Projector cuts off every 5 minutes in Smart Lecture Hall A with orange fan indicator light.',
    buildingId: 'bldg-acad',
    buildingName: 'Academic Block',
    floorId: 'fl-acad-1',
    roomId: 'room-acad-101',
    roomNumber: 'ACAD-101',
    category: 'Audio/Visual',
    severity: 'medium',
    status: 'open',
    reportedBy: 'Rohan Sharma (Student)',
    reporterEmail: 'rohan.sharma@campusops.edu',
    reportedAt: '2026-10-30T08:15:00Z',
    duplicateOfId: 'tic-261030-003',
    isDuplicate: true,
    duplicateConfidence: 0.89,
    duplicateReason: 'Same room (ACAD-101), same projector symptom, reported within 30 minutes.',
    history: [
      {
        id: 'hist-004-1',
        timestamp: '2026-10-30T08:15:00Z',
        action: 'REPORTED',
        actorName: 'Rohan Sharma',
        actorRole: 'Student',
        details: 'Reported fan error light on ACAD-101 projector.'
      }
    ]
  },
  {
    id: 'tic-261030-005',
    title: 'HVAC Air Handler B-4 Variable Frequency Drive Tripped',
    description: 'Roof chiller fan tripped on overcurrent in Block 3 Level 1-2 research cleanrooms. Ambient temperature rising above 24°C threshold.',
    buildingId: 'bldg-block3',
    buildingName: 'Block 3',
    floorId: 'fl-blk3-1',
    roomId: 'room-blk3-101',
    roomNumber: 'BLK3-101',
    category: 'HVAC',
    severity: 'critical',
    status: 'in_progress',
    reportedBy: 'Sarah Jenkins (Facilities Admin)',
    reporterEmail: 'facilities.admin@campusops.edu',
    reportedAt: '2026-10-30T06:15:00Z',
    workOrderId: 'WO-261030-005',
    assetName: 'Carrier Daikin Air Handler Unit AHU-B4',
    assetTag: 'AST-BLK3-HVAC-04',
    assignedTechnicianId: 'tech-3',
    assignedTechnicianName: 'Claude Shannon',
    assignedDepartment: 'Campus Facilities & Infrastructure',
    assignedTechnicianEmail: 'claude.shannon@campusops.edu',
    assignedTechnicianPhone: '+1 (555) 301-9913',
    estimatedResolution: '2026-10-30T16:00:00Z',
    incidentId: 'inc-261030-001',
    history: [
      {
        id: 'hist-005-1',
        timestamp: '2026-10-30T06:15:00Z',
        action: 'REPORTED',
        actorName: 'Sarah Jenkins',
        actorRole: 'Facilities Admin',
        details: 'Critical overcurrent alarm detected on Roof Chiller B-4.'
      },
      {
        id: 'hist-005-2',
        timestamp: '2026-10-30T06:16:00Z',
        action: 'ASSIGNED',
        actorName: 'System Dispatch Engine',
        actorRole: 'System Admin',
        details: 'Assigned to Claude Shannon (HVAC Specialist).'
      },
      {
        id: 'hist-005-3',
        timestamp: '2026-10-30T06:30:00Z',
        action: 'STATUS_CHANGED',
        actorName: 'Claude Shannon',
        actorRole: 'Technician',
        details: 'Technician arrived on site at Block 3 roof mechanical penthouse. Commenced VFD diagnostics.'
      }
    ]
  },
  {
    id: 'tic-261030-006',
    title: 'High Temperature Alarm in Nanotech Cleanroom',
    description: 'Cleanroom temperature elevated to 25.2°C. Sensitive photolithography processes halted.',
    buildingId: 'bldg-block3',
    buildingName: 'Block 3',
    floorId: 'fl-blk3-1',
    roomId: 'room-blk3-101',
    roomNumber: 'BLK3-101',
    category: 'HVAC',
    severity: 'high',
    status: 'in_progress',
    reportedBy: 'Dr. Aris Thorne (Researcher)',
    reporterEmail: 'aris.thorne@campusops.edu',
    reportedAt: '2026-10-30T06:40:00Z',
    incidentId: 'inc-261030-001',
    workOrderId: 'WO-261030-005',
    assignedTechnicianId: 'tech-3',
    assignedTechnicianName: 'Claude Shannon',
    assignedDepartment: 'Campus Facilities & Infrastructure',
    assignedTechnicianEmail: 'claude.shannon@campusops.edu',
    assignedTechnicianPhone: '+1 (555) 301-9913',
    duplicateConfidence: 0.92,
    duplicateReason: 'Correlated root failure: HVAC AHU-B4 trip in Block 3.',
    history: [
      {
        id: 'hist-006-1',
        timestamp: '2026-10-30T06:40:00Z',
        action: 'REPORTED',
        actorName: 'Dr. Aris Thorne',
        actorRole: 'Researcher',
        details: 'Reported ambient thermal violation in ISO-6 cleanroom.'
      },
      {
        id: 'hist-006-2',
        timestamp: '2026-10-30T06:42:00Z',
        action: 'ASSIGNED',
        actorName: 'System Dispatch Engine',
        actorRole: 'System Admin',
        details: 'Linked to active incident INC-261030-001; routed to Claude Shannon.'
      }
    ]
  },
  {
    id: 'tic-261029-007',
    title: 'Primary Chiller Water Circulator Pump Impeller Cavitation',
    description: 'Main circulating pump P-02 in Mechanical Block basement was vibrating loudly with excessive thermal buildup.',
    buildingId: 'bldg-mech',
    buildingName: 'Mechanical Block',
    floorId: 'fl-mech-0',
    roomId: 'room-mech-001',
    roomNumber: 'MECH-001',
    category: 'Plumbing',
    severity: 'high',
    status: 'resolved',
    reportedBy: 'Prof. Elena Rostova',
    reporterEmail: 'manager.ee@campusops.edu',
    reportedAt: '2026-10-29T10:15:00Z',
    workOrderId: 'WO-261029-007',
    assetName: 'Armstrong Dual-Suction Chilled Water Pump P-02',
    assetTag: 'AST-MECH-PUMP-02',
    assignedTechnicianId: 'tech-3',
    assignedTechnicianName: 'Claude Shannon',
    assignedDepartment: 'Campus Facilities & Infrastructure',
    assignedTechnicianEmail: 'claude.shannon@campusops.edu',
    assignedTechnicianPhone: '+1 (555) 301-9913',
    resolvedAt: '2026-10-29T16:45:00Z',
    estimatedResolution: '2026-10-29T17:00:00Z',
    repairActionTaken: 'Flushed air pockets from mechanical seal chamber, replaced sheared rubber vibration dampers, and re-aligned drive shaft within ±0.02mm tolerance.',
    partsUsed: ['Vibration Damper Kit (VD-400)', 'High-Pressure Mechanical Seal Ring (MSR-22)'],
    verifiedBy: 'Sarah Jenkins (Facilities Admin)',
    resolutionNotes: 'Pump cavitation completely mitigated. Flow rate returned to baseline 320 GPM. Verified operational by Facilities Admin.',
    history: [
      {
        id: 'hist-007-1',
        timestamp: '2026-10-29T10:15:00Z',
        action: 'REPORTED',
        actorName: 'Prof. Elena Rostova',
        actorRole: 'Department Manager',
        details: 'Logged abnormal vibration and acoustic spike on pump P-02.'
      },
      {
        id: 'hist-007-2',
        timestamp: '2026-10-29T10:20:00Z',
        action: 'ASSIGNED',
        actorName: 'System Dispatch Engine',
        actorRole: 'System Admin',
        details: 'Assigned to Claude Shannon.'
      },
      {
        id: 'hist-007-3',
        timestamp: '2026-10-29T11:00:00Z',
        action: 'STATUS_CHANGED',
        actorName: 'Claude Shannon',
        actorRole: 'Technician',
        details: 'Inspection started; cavitation root cause identified as mechanical seal air infiltration.'
      },
      {
        id: 'hist-007-4',
        timestamp: '2026-10-29T13:30:00Z',
        action: 'PARTS_RESERVED',
        actorName: 'Claude Shannon',
        actorRole: 'Technician',
        details: 'Dispatched parts requisition for seal ring and vibration damper kit.'
      },
      {
        id: 'hist-007-5',
        timestamp: '2026-10-29T16:45:00Z',
        action: 'RESOLVED',
        actorName: 'Claude Shannon',
        actorRole: 'Technician',
        details: 'Repairs completed and acoustic levels brought below 58dB. Sign-off recorded.'
      }
    ]
  }
];

export const initialBookings: RoomBooking[] = [
  {
    id: 'book-001',
    roomId: 'room-main-001',
    roomNumber: 'MAIN-001',
    roomName: 'Grand Central Auditorium',
    buildingName: 'Main Block',
    title: 'Annual EEC Engineering Symposia & Keynote',
    organizer: 'Dean Academic Council',
    department: 'Central Administration',
    date: '2026-10-30',
    startTime: '10:00',
    endTime: '13:00',
    attendeesCount: 380,
    purpose: 'University-wide technical presentation and guest lectures.',
    status: 'confirmed',
    requiresAV: true
  },
  {
    id: 'book-002',
    roomId: 'room-acad-201',
    roomNumber: 'ACAD-201',
    roomName: 'AI & Data Science Computing Center',
    buildingName: 'Academic Block',
    title: 'Hands-on Deep Learning Workshop with DGX',
    organizer: 'Prof. David Krum',
    department: 'Computer Science & Engineering',
    date: '2026-10-30',
    startTime: '14:00',
    endTime: '17:00',
    attendeesCount: 55,
    purpose: 'Student lab session training transformer architectures.',
    status: 'confirmed',
    requiresAV: true
  },
  {
    id: 'book-003',
    roomId: 'room-cvl-101',
    roomNumber: 'CVL-101',
    roomName: 'Civil CAD & GIS Studio',
    buildingName: 'Civil Block',
    title: 'Smart Cities BIM Modeling Practicum',
    organizer: 'Alex Chen',
    department: 'Civil Engineering',
    date: '2026-10-31',
    startTime: '11:00',
    endTime: '12:30',
    attendeesCount: 40,
    purpose: 'Revit 3D structural analysis for sophomore design cohort.',
    status: 'confirmed',
    requiresAV: false
  }
];

export const initialInventory: InventoryItem[] = [
  {
    id: 'inv-001',
    name: 'Epson 4K Laser Projector Optical Assembly',
    category: 'Projectors & Displays',
    quantityInStock: 4,
    minimumThreshold: 2,
    location: 'Central Stores - Rack A3',
    buildingId: 'bldg-admin',
    condition: 'New',
    unitCost: 1450.00,
    lastAudited: '2026-10-20'
  },
  {
    id: 'inv-002',
    name: 'Danfoss 15kW VFD Chiller Inverter Board',
    category: 'HVAC & Electrical',
    quantityInStock: 2,
    minimumThreshold: 1,
    location: 'Substation Stores - Shelf E2',
    buildingId: 'bldg-civil',
    condition: 'New',
    unitCost: 2890.00,
    lastAudited: '2026-10-15',
    reservedQuantity: 1
  },
  {
    id: 'inv-003',
    name: 'Cat6A Shielded RJ45 Patch Panels 24-Port',
    category: 'Computing & IT',
    quantityInStock: 18,
    minimumThreshold: 5,
    location: 'IT Storage - Bay 4',
    buildingId: 'bldg-acad',
    condition: 'New',
    unitCost: 145.00,
    lastAudited: '2026-10-24'
  },
  {
    id: 'inv-004',
    name: 'Fluorescent / LED Dual Electronic Ballasts',
    category: 'HVAC & Electrical',
    quantityInStock: 35,
    minimumThreshold: 10,
    location: 'Maintenance Depot - Bin 12',
    buildingId: 'bldg-mech',
    condition: 'New',
    unitCost: 48.50,
    lastAudited: '2026-10-28'
  }
];

export const initialStaff: StaffTechnician[] = [
  {
    id: 'tech-1',
    name: 'Dennis Ritchie',
    role: 'Lead Electrical & Calibration Specialist',
    specialties: ['Electrical', 'Audio/Visual'],
    phone: '+1 (555) 301-4421',
    email: 'dennis.ritchie@campusops.edu',
    shift: 'Morning (07:00 - 15:00)',
    status: 'on_task',
    activeTicketsCount: 2,
    rating: 4.95
  },
  {
    id: 'tech-2',
    name: 'Linus Torvalds',
    role: 'Senior AV & Systems Engineer',
    specialties: ['Audio/Visual', 'Network'],
    phone: '+1 (555) 301-8842',
    email: 'linus.torvalds@campusops.edu',
    shift: 'General (09:00 - 17:00)',
    status: 'on_task',
    activeTicketsCount: 1,
    rating: 4.92
  },
  {
    id: 'tech-3',
    name: 'Claude Shannon',
    role: 'HVAC & Critical Infrastructure Technician',
    specialties: ['HVAC', 'Plumbing'],
    phone: '+1 (555) 301-9913',
    email: 'claude.shannon@campusops.edu',
    shift: 'Morning (07:00 - 15:00)',
    status: 'on_task',
    activeTicketsCount: 2,
    rating: 4.88
  },
  {
    id: 'tech-4',
    name: 'Grace Hopper',
    role: 'Network Operations Specialist',
    specialties: ['Network', 'Electrical'],
    phone: '+1 (555) 301-7764',
    email: 'grace.hopper@campusops.edu',
    shift: 'Evening (14:00 - 22:00)',
    status: 'available',
    activeTicketsCount: 0,
    rating: 4.98
  }
];

export const initialIncidents: CampusIncident[] = [
  {
    id: 'inc-261030-001',
    incidentCode: 'INC-261030-001',
    title: 'Block 3 Chiller VFD Fault (AHU-B4)',
    description: 'Overcurrent trip on Variable Frequency Drive feeding Air Handler B4 in Block 3. Affected Level 1 & Level 2 Cleanrooms and Nanotech labs.',
    category: 'HVAC',
    severity: 'critical',
    status: 'investigating',
    affectedBuildings: ['Block 3'],
    affectedRooms: ['BLK3-101', 'BLK3-102', 'BLK3-201'],
    reportedAt: '2026-10-30T06:15:00Z',
    estimatedResolution: '2026-10-30T14:00:00Z',
    actionTaken: 'Technician Claude Shannon dispatched with replacement VFD controller from central inventory. System in bypass ventilation.',
    linkedComplaintIds: ['tic-261030-005', 'tic-261030-006'],
    workOrderId: 'WO-261030-009',
    assignedTechnicianId: 'tech-3',
    assignedTechnicianName: 'Claude Shannon'
  }
];

export const initialMetrics: DashboardMetrics = {
  totalBuildings: 6,
  totalClassrooms: 109,
  operationalRate: 97.4,
  openMaintenanceTickets: 6,
  activeBookingsToday: 14,
  averageUtilizationPercent: 78.5,
  activeIncidentsCount: 1,
  lowStockItemsCount: 2,
  availableStaffCount: 4,
  dailyEnergyKwh: 4850.4
};
