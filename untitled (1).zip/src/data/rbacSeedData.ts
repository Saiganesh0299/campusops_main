import { User, Department, PurchaseRequest } from '../types/rbac';

export const initialDepartments: Department[] = [
  {
    id: 'dept-admin',
    name: 'Central IT & University Administration',
    code: 'ADMIN',
    buildingId: 'bldg-admin',
    headName: 'Dr. Marcus Vance'
  },
  {
    id: 'dept-fac',
    name: 'Campus Facilities & Infrastructure',
    code: 'FAC',
    buildingId: 'bldg-civil',
    headName: 'Sarah Jenkins'
  },
  {
    id: 'dept-cs',
    name: 'Computer Science & Engineering',
    code: 'CS',
    buildingId: 'bldg-acad',
    headName: 'Prof. David Krum'
  },
  {
    id: 'dept-ee',
    name: 'Mechanical & Heavy Engineering',
    code: 'MECH',
    buildingId: 'bldg-mech',
    headName: 'Prof. Elena Rostova'
  },
  {
    id: 'dept-proc',
    name: 'Central Procurement & Supply Chain',
    code: 'PROC',
    buildingId: 'bldg-admin',
    headName: 'Arthur Pendelton'
  }
];

export const initialUsers: User[] = [
  {
    id: 'usr-admin',
    name: 'Dr. Marcus Vance',
    email: 'admin@campusops.edu',
    role: 'SYSTEM_ADMIN',
    departmentId: 'dept-admin',
    departmentName: 'Central IT & University Administration',
    isActive: true,
    isPrimaryAdmin: true,
    phone: '+1 (555) 019-2831',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    lastLoginAt: '2026-10-30T08:12:00Z',
    createdAt: '2025-01-10T00:00:00Z',
    permissions: ['*']
  },
  {
    id: 'usr-facilities-admin',
    name: 'Sarah Jenkins',
    email: 'facilities.admin@campusops.edu',
    role: 'FACILITIES_ADMIN',
    departmentId: 'dept-fac',
    departmentName: 'Campus Facilities & Infrastructure',
    isActive: true,
    phone: '+1 (555) 014-9923',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    lastLoginAt: '2026-10-30T07:45:00Z',
    createdAt: '2025-01-12T00:00:00Z',
    permissions: [
      'complaints:view_all',
      'complaints:create',
      'complaints:update_status',
      'work_orders:create',
      'work_orders:assign',
      'work_orders:update',
      'inventory:manage',
      'staff:manage',
      'incidents:manage',
      'rooms:manage',
      'purchases:create'
    ]
  },
  {
    id: 'usr-manager-cs',
    name: 'Prof. David Krum',
    email: 'manager.cs@campusops.edu',
    role: 'DEPT_MANAGER',
    departmentId: 'dept-cs',
    departmentName: 'Computer Science & Engineering',
    isActive: true,
    phone: '+1 (555) 018-7741',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    lastLoginAt: '2026-10-29T16:20:00Z',
    createdAt: '2025-01-15T00:00:00Z',
    permissions: [
      'complaints:view_department',
      'complaints:create',
      'rooms:book',
      'rooms:manage',
      'inventory:read',
      'analytics:view'
    ]
  },
  {
    id: 'usr-manager-ee',
    name: 'Prof. Elena Rostova',
    email: 'manager.ee@campusops.edu',
    role: 'DEPT_MANAGER',
    departmentId: 'dept-ee',
    departmentName: 'Electrical Engineering & IoT',
    isActive: true,
    phone: '+1 (555) 016-3392',
    avatarUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    lastLoginAt: '2026-10-30T09:05:00Z',
    createdAt: '2025-01-15T00:00:00Z',
    permissions: [
      'complaints:view_department',
      'complaints:create',
      'rooms:book',
      'rooms:manage',
      'inventory:read',
      'purchases:approve',
      'analytics:view'
    ],
    overrides: [
      {
        permissionName: 'purchases:approve',
        granted: true,
        notes: 'Delegated purchase approval authorization up to $5,000 for EE lab equipment'
      }
    ]
  },
  {
    id: 'usr-tech-dennis',
    name: 'Dennis Ritchie',
    email: 'tech.dennis@campusops.edu',
    role: 'TECHNICIAN',
    departmentId: 'dept-fac',
    departmentName: 'Campus Facilities & Infrastructure',
    isActive: true,
    phone: '+1 (555) 012-4411',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    lastLoginAt: '2026-10-30T08:50:00Z',
    createdAt: '2025-01-20T00:00:00Z',
    permissions: [
      'complaints:view_assigned',
      'complaints:create',
      'work_orders:update',
      'purchases:create',
      'inventory:read',
      'staff:read'
    ]
  },
  {
    id: 'usr-tech-grace',
    name: 'Grace Hopper',
    email: 'tech.grace@campusops.edu',
    role: 'TECHNICIAN',
    departmentId: 'dept-fac',
    departmentName: 'Campus Facilities & Infrastructure',
    isActive: true,
    phone: '+1 (555) 012-4412',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    lastLoginAt: '2026-10-29T14:15:00Z',
    createdAt: '2025-01-20T00:00:00Z',
    permissions: [
      'complaints:view_assigned',
      'complaints:create',
      'work_orders:update',
      'purchases:create',
      'inventory:read',
      'staff:read'
    ]
  },
  {
    id: 'usr-procurement',
    name: 'Arthur Pendelton',
    email: 'procurement.officer@campusops.edu',
    role: 'PROCUREMENT',
    departmentId: 'dept-proc',
    departmentName: 'Central Procurement & Supply Chain',
    isActive: true,
    phone: '+1 (555) 013-8821',
    avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    lastLoginAt: '2026-10-30T08:30:00Z',
    createdAt: '2025-02-01T00:00:00Z',
    permissions: [
      'purchases:read',
      'purchases:approve',
      'purchases:reject',
      'purchases:order',
      'purchases:receive',
      'inventory:manage',
      'complaints:create',
      'analytics:view'
    ]
  },
  {
    id: 'usr-student-alex',
    name: 'Alex Rivera',
    email: 'student.alex@campusops.edu',
    role: 'STUDENT_FACULTY',
    departmentId: 'dept-cs',
    departmentName: 'Computer Science & Engineering',
    isActive: true,
    phone: '+1 (555) 019-6612',
    avatarUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
    lastLoginAt: '2026-10-30T09:12:00Z',
    createdAt: '2025-08-25T00:00:00Z',
    permissions: [
      'complaints:create',
      'complaints:view_own',
      'rooms:book'
    ]
  },
  {
    id: 'usr-faculty-rachel',
    name: 'Dr. Rachel Green',
    email: 'faculty.rachel@campusops.edu',
    role: 'STUDENT_FACULTY',
    departmentId: 'dept-ee',
    departmentName: 'Electrical Engineering & IoT',
    isActive: true,
    phone: '+1 (555) 019-7744',
    avatarUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?w=150&auto=format&fit=crop&q=80',
    lastLoginAt: '2026-10-28T11:00:00Z',
    createdAt: '2025-08-20T00:00:00Z',
    permissions: [
      'complaints:create',
      'complaints:view_own',
      'rooms:book'
    ]
  }
];

export const initialPurchases: PurchaseRequest[] = [
  {
    id: 'pr-1001',
    requestNumber: 'PR-2026-0041',
    title: 'Replacement High-Lumen Laser Projector Bulbs (4K)',
    justification: 'Auditorium A and Smart Classroom OAB-201 lamps have surpassed 2,500 operation hours and suffer from 40% lumen degradation.',
    departmentId: 'dept-cs',
    departmentName: 'Computer Science & Engineering',
    requesterId: 'usr-tech-dennis',
    requesterName: 'Dennis Ritchie',
    requesterRole: 'TECHNICIAN',
    relatedTicketId: 'tic-1',
    items: [
      {
        name: 'Optoma 4K UHD Solid-State Laser Lamp Unit',
        quantity: 4,
        unitPrice: 285.00,
        totalPrice: 1140.00,
        partNumber: 'OPT-LMP-400X'
      },
      {
        name: 'Optical Heat Dispersion Filter Pack',
        quantity: 4,
        unitPrice: 42.50,
        totalPrice: 170.00,
        partNumber: 'FLT-HD-04'
      }
    ],
    totalAmount: 1310.00,
    status: 'PENDING_REVIEW',
    urgency: 'HIGH',
    createdAt: '2026-10-28T10:30:00Z',
    updatedAt: '2026-10-28T10:30:00Z',
    approvals: []
  },
  {
    id: 'pr-1002',
    requestNumber: 'PR-2026-0042',
    title: 'Precision Oscilloscope Probes & Logic Analyzers for IoT Lab',
    justification: 'Expanded intake of graduate embedded systems cohort requires 10 calibrated 200MHz differential probe pairs.',
    departmentId: 'dept-ee',
    departmentName: 'Electrical Engineering & IoT',
    requesterId: 'usr-manager-ee',
    requesterName: 'Prof. Elena Rostova',
    requesterRole: 'DEPT_MANAGER',
    items: [
      {
        name: 'Tektronix 200MHz Passive Voltage Probe Kit',
        quantity: 10,
        unitPrice: 165.00,
        totalPrice: 1650.00,
        partNumber: 'TEK-TPP0200'
      },
      {
        name: '16-Channel USB Logic Analyzer with Protocol Decoder',
        quantity: 5,
        unitPrice: 420.00,
        totalPrice: 2100.00,
        partNumber: 'LOG-USB-16P'
      }
    ],
    totalAmount: 3750.00,
    status: 'APPROVED',
    urgency: 'NORMAL',
    createdAt: '2026-10-25T14:15:00Z',
    updatedAt: '2026-10-26T09:20:00Z',
    approvals: [
      {
        id: 'appr-01',
        approverId: 'usr-procurement',
        approverName: 'Arthur Pendelton',
        approverRole: 'PROCUREMENT',
        action: 'APPROVED',
        comments: 'Verified budget line item under FY26 Academic Lab Equipment Grant. Forwarding to supplier.',
        timestamp: '2026-10-26T09:20:00Z'
      }
    ]
  },
  {
    id: 'pr-1003',
    requestNumber: 'PR-2026-0043',
    title: 'HVAC Chilled Water Glycol & Proportional Control Valves',
    justification: 'Lovelace Science Center Zone B chiller actuator failure causing erratic temperature fluctuation in cleanroom.',
    departmentId: 'dept-fac',
    departmentName: 'Campus Facilities & Infrastructure',
    requesterId: 'usr-tech-grace',
    requesterName: 'Grace Hopper',
    requesterRole: 'TECHNICIAN',
    relatedTicketId: 'tic-3',
    items: [
      {
        name: 'Belimo 2-Way Electronic Pressure-Independent Valve',
        quantity: 2,
        unitPrice: 590.00,
        totalPrice: 1180.00,
        partNumber: 'BEL-EPIV-50'
      },
      {
        name: 'Industrial HVAC Inhibited Propylene Glycol (55 Gal Drum)',
        quantity: 1,
        unitPrice: 850.00,
        totalPrice: 850.00,
        partNumber: 'GLY-IND-55'
      }
    ],
    totalAmount: 2030.00,
    status: 'PENDING_REVIEW',
    urgency: 'HIGH',
    createdAt: '2026-10-29T11:00:00Z',
    updatedAt: '2026-10-29T11:00:00Z',
    approvals: []
  },
  {
    id: 'pr-1004',
    requestNumber: 'PR-2026-0044',
    title: 'Cat6A Shielded Bulk Cable Spools & Keystone Jacks',
    justification: 'Network cabling upgrade for Turing 2nd floor robotics lab to support 10Gbps Ethernet telemetry.',
    departmentId: 'dept-fac',
    departmentName: 'Campus Facilities & Infrastructure',
    requesterId: 'usr-facilities-admin',
    requesterName: 'Sarah Jenkins',
    requesterRole: 'FACILITIES_ADMIN',
    items: [
      {
        name: 'Cat6A 1000ft CMR Shielded Solid Copper Cable',
        quantity: 3,
        unitPrice: 240.00,
        totalPrice: 720.00,
        partNumber: 'CAB-C6A-SH'
      },
      {
        name: 'Toolless Shielded RJ45 Keystone Jacks (Pack of 24)',
        quantity: 2,
        unitPrice: 65.00,
        totalPrice: 130.00,
        partNumber: 'KEY-RJ45-24'
      }
    ],
    totalAmount: 850.00,
    status: 'ORDERED',
    urgency: 'NORMAL',
    createdAt: '2026-10-20T16:00:00Z',
    updatedAt: '2026-10-22T11:45:00Z',
    approvals: [
      {
        id: 'appr-02',
        approverId: 'usr-procurement',
        approverName: 'Arthur Pendelton',
        approverRole: 'PROCUREMENT',
        action: 'APPROVED',
        comments: 'Approved against Facilities standard network maintenance budget.',
        timestamp: '2026-10-22T11:45:00Z'
      }
    ]
  }
];
