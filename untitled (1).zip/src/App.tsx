import React, { useState, useEffect } from 'react';
import { 
  Building, 
  Classroom, 
  Floor, 
  MaintenanceTicket, 
  RoomBooking, 
  InventoryItem, 
  StaffTechnician, 
  CampusIncident, 
  DashboardMetrics 
} from './types/campus';
import { 
  initialBuildings, 
  initialClassrooms, 
  initialTickets, 
  initialBookings, 
  initialInventory, 
  initialStaff, 
  initialIncidents, 
  initialMetrics 
} from './data/seedData';
import { createNewFloor, createDefaultRoomsForFloor } from './utils/campusUtils';

// Component Views
import { ThreeCampusViewer } from './components/ThreeCampusViewer';
import { FloorPlanView } from './components/FloorPlanView';
import { DashboardView } from './components/DashboardView';
import { MaintenanceView } from './components/MaintenanceView';
import { BookingsView } from './components/BookingsView';
import { InventoryView } from './components/InventoryView';
import { StaffView } from './components/StaffView';
import { IncidentsView } from './components/IncidentsView';
import { AnalyticsView } from './components/AnalyticsView';
import { AiChatView } from './components/AiChatView';
import { AiSettingsView } from './components/AiSettingsView';
import { AiCopilotWidget } from './components/AiCopilotWidget';
import { BookRoomModal } from './components/BookRoomModal';
import { ReportIssueModal } from './components/ReportIssueModal';

// RBAC Components, Data & Policy
import { User, UserRole, ROLE_LABELS, ROLE_COLORS } from './types/rbac';
import { initialUsers } from './data/rbacSeedData';
import { canAccessTab, getRequiredRoleForTab, filterScopedTickets } from './utils/rbacPolicy';
import { AuthModal } from './components/AuthModal';
import { UserManagementView } from './components/UserManagementView';
import { ProcurementView } from './components/ProcurementView';
import { AccessDeniedView } from './components/AccessDeniedView';
import { NavbarUserBadge } from './components/NavbarUserBadge';
import { NotificationsView } from './components/NotificationsView';

// Icons
import { 
  Compass, 
  LayoutDashboard, 
  Layers, 
  Wrench, 
  Calendar, 
  Boxes, 
  Users, 
  AlertTriangle, 
  BarChart3, 
  Sparkles, 
  Settings, 
  Menu, 
  X, 
  Building2, 
  ShieldCheck, 
  Bell,
  ShoppingBag,
  UserCheck,
  UserCog
} from 'lucide-react';

export default function App() {
  // Navigation & View state
  const [activeTab, setActiveTab] = useState<string>('3d-campus');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Campus Data State
  const [buildings, setBuildings] = useState<Building[]>(initialBuildings);
  const [classrooms, setClassrooms] = useState<Classroom[]>(initialClassrooms);
  const [tickets, setTickets] = useState<MaintenanceTicket[]>(initialTickets);
  const [bookings, setBookings] = useState<RoomBooking[]>(initialBookings);
  const [inventory, setInventory] = useState<InventoryItem[]>(initialInventory);
  const [staff, setStaff] = useState<StaffTechnician[]>(initialStaff);
  const [incidents, setIncidents] = useState<CampusIncident[]>(initialIncidents);
  const [metrics, setMetrics] = useState<DashboardMetrics>(initialMetrics);

  // Unread notifications count
  const [unreadNotifCount, setUnreadNotifCount] = useState<number>(3);

  // Selected State
  const [selectedBuilding, setSelectedBuilding] = useState<Building | null>(null);
  const [selectedFloor, setSelectedFloor] = useState<Floor | null>(null);

  // Modal State
  const [roomToBook, setRoomToBook] = useState<Classroom | null>(null);
  const [showReportModal, setShowReportModal] = useState<boolean>(false);
  const [reportPrefill, setReportPrefill] = useState<{ buildingId?: string; roomId?: string; roomNumber?: string }>({});

  // RBAC User & Auth State (Defaults to Primary System Admin)
  const [currentUser, setCurrentUser] = useState<User>(initialUsers[0]);
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);

  // Centralized Scope-Aware Maintenance Complaints Filtering
  const scopedTickets = React.useMemo(() => {
    return filterScopedTickets(tickets, currentUser);
  }, [tickets, currentUser]);

  // Robust Account & Persona Switcher with Route Access Guard
  const handleSwitchUser = (user: User) => {
    setCurrentUser(user);
    if (!canAccessTab(user.role, activeTab)) {
      setActiveTab('3d-campus');
    }
  };

  // Sync from backend REST API if available (re-fetch maintenance with role context)
  useEffect(() => {
    fetch('/api/buildings')
      .then(res => res.ok ? res.json() : null)
      .then(data => { if (data && data.length) setBuildings(data); })
      .catch(() => {});

    fetch('/api/classrooms')
      .then(res => res.ok ? res.json() : null)
      .then(data => { if (data && data.length) setClassrooms(data); })
      .catch(() => {});

    fetch('/api/bookings')
      .then(res => res.ok ? res.json() : null)
      .then(data => { if (data && data.length) setBookings(data); })
      .catch(() => {});

    fetch('/api/inventory', {
      headers: { 'x-user-id': currentUser.id, 'x-user-role': currentUser.role }
    })
      .then(res => res.ok ? res.json() : null)
      .then(data => { if (data && data.length) setInventory(data); })
      .catch(() => {});

    fetch('/api/staff', {
      headers: { 'x-user-id': currentUser.id, 'x-user-role': currentUser.role }
    })
      .then(res => res.ok ? res.json() : null)
      .then(data => { if (data && data.length) setStaff(data); })
      .catch(() => {});

    fetch('/api/incidents', {
      headers: { 'x-user-id': currentUser.id, 'x-user-role': currentUser.role }
    })
      .then(res => res.ok ? res.json() : null)
      .then(data => { if (data && data.length) setIncidents(data); })
      .catch(() => {});
  }, [currentUser]);

  // Re-fetch maintenance tickets whenever currentUser changes
  useEffect(() => {
    fetch(`/api/maintenance?userId=${currentUser.id}&userRole=${currentUser.role}`, {
      headers: { 'x-user-id': currentUser.id, 'x-user-role': currentUser.role }
    })
      .then(res => res.ok ? res.json() : null)
      .then(data => { if (data && data.length) setTickets(data); })
      .catch(() => {});
  }, [currentUser]);

  // Sync Unread Notification Count
  useEffect(() => {
    fetch(`/api/notifications?userId=${currentUser.id}&role=${currentUser.role}&unreadOnly=true`)
      .then(res => res.ok ? res.json() : [])
      .then(data => {
        if (Array.isArray(data)) setUnreadNotifCount(data.length);
      })
      .catch(() => {});

    // Live SSE listener for badge updates
    const sse = new EventSource(`/api/notifications/stream?userId=${currentUser.id}`);
    sse.onmessage = (evt) => {
      try {
        const d = JSON.parse(evt.data);
        if (d && d.id) {
          setUnreadNotifCount(prev => prev + 1);
        }
      } catch {}
    };
    return () => {
      sse.close();
    };
  }, [currentUser]);

  // Handlers
  const handleSelectBuilding = (b: Building) => {
    setSelectedBuilding(b);
    if (b.floors && b.floors.length > 0) {
      setSelectedFloor(b.floors[0]);
    }
  };

  const handleDeselectBuilding = () => {
    setSelectedBuilding(null);
    setSelectedFloor(null);
  };

  const handleOpenFloorPlan = (b: Building, floor?: Floor) => {
    setSelectedBuilding(b);
    setSelectedFloor(floor || b.floors[0]);
    setActiveTab('floor-plan');
  };

  const handleNavigateTo3D = (b?: Building) => {
    if (b) {
      setSelectedBuilding(b);
      if (!selectedFloor && b.floors && b.floors.length > 0) setSelectedFloor(b.floors[0]);
    } else {
      setSelectedBuilding(null);
      setSelectedFloor(null);
    }
    setActiveTab('3d-campus');
  };

  // Dynamic Floor Configuration Handlers
  const handleAddFloor = (buildingId: string) => {
    const bldg = buildings.find(b => b.id === buildingId);
    if (!bldg) return;

    const newFloorNum = bldg.floors.length;
    const newFloor = createNewFloor(bldg.id, newFloorNum);
    const newRooms = createDefaultRoomsForFloor(bldg, newFloor);

    // Update classrooms
    setClassrooms(prev => [...prev, ...newRooms]);

    // Update buildings
    const updatedBuilding: Building = {
      ...bldg,
      floors: [...bldg.floors, newFloor],
      floorsCount: bldg.floors.length + 1,
      classroomsCount: bldg.classroomsCount + newRooms.length
    };

    setBuildings(prev => prev.map(b => b.id === buildingId ? updatedBuilding : b));

    if (selectedBuilding?.id === buildingId) {
      setSelectedBuilding(updatedBuilding);
      setSelectedFloor(newFloor);
    }
  };

  const handleRemoveFloor = (buildingId: string) => {
    const bldg = buildings.find(b => b.id === buildingId);
    if (!bldg || bldg.floors.length <= 1) return;

    const topFloor = bldg.floors[bldg.floors.length - 1];
    const newFloors = bldg.floors.slice(0, -1);
    const removedRooms = classrooms.filter(r => r.floorId === topFloor.id);

    // Remove classrooms and associated bookings for removed floor
    setClassrooms(prev => prev.filter(r => r.floorId !== topFloor.id));
    setBookings(prev => prev.filter(bk => !removedRooms.some(r => r.id === bk.roomId)));

    const updatedBuilding: Building = {
      ...bldg,
      floors: newFloors,
      floorsCount: newFloors.length,
      classroomsCount: Math.max(1, bldg.classroomsCount - removedRooms.length)
    };

    setBuildings(prev => prev.map(b => b.id === buildingId ? updatedBuilding : b));

    if (selectedBuilding?.id === buildingId) {
      setSelectedBuilding(updatedBuilding);
      if (selectedFloor?.id === topFloor.id) {
        setSelectedFloor(newFloors[newFloors.length - 1]);
      }
    }
  };

  // Ticket actions
  const handleUpdateTicketStatus = async (ticketId: string, newStatus: any, notes?: string) => {
    setTickets(prev => prev.map(t => t.id === ticketId ? { ...t, status: newStatus, resolutionNotes: notes || t.resolutionNotes } : t));
    try {
      await fetch(`/api/maintenance/${ticketId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus, resolutionNotes: notes })
      });
    } catch (err) {}
  };

  const handleCreateTicketSuccess = (newTicket: MaintenanceTicket) => {
    setTickets(prev => [newTicket, ...prev]);
    setShowReportModal(false);
  };

  // Booking actions
  const handleCreateBookingSuccess = (newBooking: RoomBooking) => {
    setBookings(prev => [newBooking, ...prev]);
    setClassrooms(prev => prev.map(r => r.id === newBooking.roomId ? { ...r, status: 'booked' } : r));
    setRoomToBook(null);
  };

  const handleCancelBooking = async (bookingId: string) => {
    const booking = bookings.find(b => b.id === bookingId);
    setBookings(prev => prev.filter(b => b.id !== bookingId));
    if (booking) {
      setClassrooms(prev => prev.map(r => r.id === booking.roomId ? { ...r, status: 'available' } : r));
    }
    try {
      await fetch(`/api/bookings/${bookingId}`, { method: 'DELETE' });
    } catch (err) {}
  };

  // Inventory actions
  const handleRestock = async (itemId: string, addQuantity: number) => {
    setInventory(prev => prev.map(item => item.id === itemId ? { ...item, quantityInStock: item.quantityInStock + addQuantity } : item));
    try {
      await fetch(`/api/inventory/${itemId}/restock`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ quantity: addQuantity })
      });
    } catch (err) {}
  };

  // Incident actions
  const handleAddIncident = async (incidentData: any) => {
    const newInc: CampusIncident = {
      id: `inc-${Date.now()}`,
      ...incidentData,
      status: 'investigating',
      reportedAt: new Date().toISOString()
    };
    setIncidents(prev => [newInc, ...prev]);
    try {
      await fetch('/api/incidents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newInc)
      });
    } catch (err) {}
  };

  const handleUpdateIncidentStatus = async (id: string, status: any) => {
    setIncidents(prev => prev.map(i => i.id === id ? { ...i, status } : i));
  };

  const allNavItems = [
    { id: '3d-campus', label: '3D Unified Campus', icon: Compass, badge: 'Unified', section: 'spatial' },
    { id: 'dashboard', label: 'Command Center', icon: LayoutDashboard, section: 'spatial' },
    { id: 'floor-plan', label: 'Floor Plan Explorer', icon: Layers, section: 'spatial' },
    { id: 'maintenance', label: 'Maintenance & Complaints', icon: Wrench, count: scopedTickets.filter(t => t.status !== 'resolved').length, section: 'operations' },
    { id: 'notifications', label: 'Operations & Alerts', icon: Bell, count: unreadNotifCount, section: 'operations' },
    { id: 'bookings', label: 'Room Bookings', icon: Calendar, count: bookings.length, section: 'operations' },
    { id: 'inventory', label: 'Inventory & Assets', icon: Boxes, section: 'operations' },
    { id: 'staff', label: 'Staff & Technicians', icon: Users, section: 'operations' },
    { id: 'incidents', label: 'Campus Incidents', icon: AlertTriangle, count: incidents.filter(i => i.status !== 'resolved').length, section: 'operations' },
    { id: 'procurement', label: 'Central Procurement', icon: ShoppingBag, section: 'governance' },
    { id: 'user-management', label: 'User Directory & RBAC', icon: UserCog, badge: 'Admin', section: 'governance' },
    { id: 'analytics', label: 'Operations Analytics', icon: BarChart3, section: 'governance' },
    { id: 'ai-chat', label: 'AI Operations Copilot', icon: Sparkles, glow: true, section: 'governance' },
    { id: 'settings', label: 'System & AI Policies', icon: Settings, section: 'governance' }
  ];

  // Strictly filter navigation tabs based on user role authorization
  const navItems = allNavItems.filter(item => canAccessTab(currentUser.role, item.id));

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#050507] text-[#F8FAFC]">
      {/* Desktop / Tablet Sidebar Navigation */}
      <aside
        className={`hidden md:flex flex-col bg-[#07080D]/95 backdrop-blur-xl border-r border-[#1E2030] transition-all duration-300 ${
          sidebarCollapsed ? 'w-20' : 'w-64'
        }`}
      >
        {/* Brand Header with New CampusOps Logo */}
        <div className="flex items-center justify-between h-16 px-4 border-b border-[#1E2030]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#0B0C14] border border-[#222436] flex items-center justify-center p-1 shadow-lg shadow-[#8B5CF6]/15 shrink-0">
              <img
                src="/campusops-logo.png"
                alt="CampusOps Logo"
                className="w-full h-full object-contain drop-shadow-[0_0_8px_rgba(0,245,255,0.4)]"
              />
            </div>
            {!sidebarCollapsed && (
              <div>
                <span className="text-base font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                  CampusOps
                </span>
                <span className="text-[10px] block font-mono text-[#00F5FF] font-semibold -mt-0.5 tracking-wider">
                  INTELLIGENT COMMAND
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Navigation Items List */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1.5 no-scrollbar">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer group ${
                  isActive
                    ? 'bg-gradient-to-r from-[#8B5CF6]/25 to-[#00F5FF]/10 text-white border border-[#8B5CF6]/50 shadow-[0_0_18px_rgba(139,92,246,0.3)]'
                    : 'text-slate-400 hover:text-white hover:bg-[#121320]'
                }`}
                title={sidebarCollapsed ? item.label : undefined}
              >
                <Icon className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                  isActive ? 'text-[#00F5FF]' : item.glow ? 'text-[#8B5CF6]' : 'text-slate-400'
                }`} />

                {!sidebarCollapsed && (
                  <span className="flex-1 text-left truncate">{item.label}</span>
                )}

                {!sidebarCollapsed && item.badge && (
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-[#00F5FF]/15 text-[#00F5FF] border border-[#00F5FF]/30">
                    {item.badge}
                  </span>
                )}

                {!sidebarCollapsed && item.count !== undefined && item.count > 0 && (
                  <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                    item.id === 'incidents' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                    item.id === 'maintenance' ? 'bg-[#8B5CF6]/20 text-[#C084FC] border border-[#8B5CF6]/30' :
                    'bg-[#1E2030] text-slate-300'
                  }`}>
                    {item.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Sidebar Footer info */}
        <div className="p-3 border-t border-[#1E2030] text-xs">
          {!sidebarCollapsed ? (
            <div className="p-3 rounded-xl bg-[#0B0C14] border border-[#1E2030]/80 space-y-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-400">Campus Status</span>
                <span className="text-emerald-400 font-semibold flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Nominal
                </span>
              </div>
              <div className="text-[10px] text-slate-500 font-mono flex items-center justify-between">
                <span>Active Complexes:</span>
                <span className="text-[#00F5FF] font-semibold">6 Nodes</span>
              </div>
            </div>
          ) : (
            <div className="flex justify-center">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            </div>
          )}
        </div>
      </aside>

      {/* Accessible Mobile Slide-Over Navigation Sheet / Drawer */}
      {mobileMenuOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Navigation Menu"
          className="fixed inset-0 z-50 md:hidden flex flex-col justify-end bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
        >
          {/* Backdrop Tap Area */}
          <div
            className="flex-1 w-full"
            onClick={() => setMobileMenuOpen(false)}
            aria-hidden="true"
          />

          {/* Drawer Body Container */}
          <div className="relative w-full max-h-[85vh] bg-[#080910] border-t border-[#222436] rounded-t-3xl shadow-[0_-15px_50px_rgba(0,0,0,0.9)] flex flex-col overflow-hidden animate-in slide-in-from-bottom duration-300">
            {/* Accessible Grab Handle */}
            <div className="w-12 h-1.5 bg-[#25283D] rounded-full mx-auto my-3" />

            {/* Header */}
            <div className="flex items-center justify-between px-5 pb-3 border-b border-[#1E2030]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#0B0C14] border border-[#222436] flex items-center justify-center p-1 shadow-md shadow-[#00F5FF]/10 shrink-0">
                  <img
                    src="/campusops-logo.png"
                    alt="CampusOps Logo"
                    className="w-full h-full object-contain"
                  />
                </div>
                <div>
                  <h2 className="text-base font-extrabold text-white tracking-tight">CampusOps</h2>
                  <span className="text-[10px] font-mono font-semibold text-[#00F5FF] uppercase tracking-wider block -mt-0.5">
                    Unified Campus Hub
                  </span>
                </div>
              </div>

              <button
                onClick={() => setMobileMenuOpen(false)}
                className="w-11 h-11 rounded-xl bg-[#131422] hover:bg-[#1E2032] border border-[#25283D] text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                aria-label="Close navigation menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Action Shortcuts inside Mobile Menu */}
            <div className="grid grid-cols-2 gap-2.5 p-4 bg-[#0B0C14] border-b border-[#1E2030]">
              <button
                onClick={() => {
                  setReportPrefill({ buildingId: selectedBuilding?.id });
                  setShowReportModal(true);
                  setMobileMenuOpen(false);
                }}
                className="min-h-[44px] flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-[#131422] hover:bg-[#1A1C30] border border-[#00F5FF]/40 text-[#00F5FF] text-xs font-bold transition-all active:scale-[0.98] cursor-pointer"
              >
                <Wrench className="w-4 h-4" />
                <span>Report Issue</span>
              </button>
              <button
                onClick={() => {
                  setRoomToBook(classrooms[0] || null);
                  setMobileMenuOpen(false);
                }}
                className="min-h-[44px] flex items-center justify-center gap-2 px-3 py-2.5 rounded-xl bg-gradient-to-r from-[#7B2CBF] to-[#8B5CF6] text-white text-xs font-bold transition-all shadow-md shadow-[#8B5CF6]/25 active:scale-[0.98] cursor-pointer"
              >
                <Calendar className="w-4 h-4" />
                <span>Book Space</span>
              </button>
            </div>

            {/* Scrollable Navigation Sections */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
              {/* Category 1: Spatial & 3D */}
              <div>
                <span className="text-[10px] font-mono uppercase font-bold text-slate-400 tracking-wider px-2 block mb-1.5">
                  Spatial & Digital Twin
                </span>
                <div className="space-y-1">
                  {navItems.filter(i => i.section === 'spatial').map(item => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setActiveTab(item.id);
                          setMobileMenuOpen(false);
                        }}
                        className={`w-full min-h-[48px] flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                          isActive
                            ? 'bg-gradient-to-r from-[#8B5CF6]/25 to-[#00F5FF]/15 text-white border border-[#8B5CF6]/50 shadow-[0_0_12px_rgba(139,92,246,0.3)]'
                            : 'text-slate-300 hover:text-white hover:bg-[#121320]'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#00F5FF]' : 'text-slate-400'}`} />
                          <span className="text-left">{item.label}</span>
                        </div>
                        {item.badge && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#00F5FF]/15 text-[#00F5FF] border border-[#00F5FF]/30">
                            {item.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Category 2: Facilities Operations */}
              <div>
                <span className="text-[10px] font-mono uppercase font-bold text-slate-400 tracking-wider px-2 block mb-1.5">
                  Facilities Operations
                </span>
                <div className="space-y-1">
                  {navItems.filter(i => i.section === 'operations').map(item => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setActiveTab(item.id);
                          setMobileMenuOpen(false);
                        }}
                        className={`w-full min-h-[48px] flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                          isActive
                            ? 'bg-gradient-to-r from-[#8B5CF6]/25 to-[#00F5FF]/15 text-white border border-[#8B5CF6]/50 shadow-[0_0_12px_rgba(139,92,246,0.3)]'
                            : 'text-slate-300 hover:text-white hover:bg-[#121320]'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#00F5FF]' : 'text-slate-400'}`} />
                          <span className="text-left">{item.label}</span>
                        </div>
                        {item.count !== undefined && item.count > 0 && (
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                            item.id === 'incidents' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                            item.id === 'maintenance' ? 'bg-[#8B5CF6]/20 text-[#C084FC] border border-[#8B5CF6]/30' :
                            'bg-[#1E2030] text-slate-300'
                          }`}>
                            {item.count}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Category 3: Governance & Intelligence */}
              <div>
                <span className="text-[10px] font-mono uppercase font-bold text-slate-400 tracking-wider px-2 block mb-1.5">
                  Governance & Intelligence
                </span>
                <div className="space-y-1">
                  {navItems.filter(i => i.section === 'governance').map(item => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setActiveTab(item.id);
                          setMobileMenuOpen(false);
                        }}
                        className={`w-full min-h-[48px] flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                          isActive
                            ? 'bg-gradient-to-r from-[#8B5CF6]/25 to-[#00F5FF]/15 text-white border border-[#8B5CF6]/50 shadow-[0_0_12px_rgba(139,92,246,0.3)]'
                            : 'text-slate-300 hover:text-white hover:bg-[#121320]'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#00F5FF]' : item.glow ? 'text-[#8B5CF6]' : 'text-slate-400'}`} />
                          <span className="text-left">{item.label}</span>
                        </div>
                        {item.badge && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#8B5CF6]/20 text-[#A78BFA] border border-[#8B5CF6]/30">
                            {item.badge}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Mobile Footer User Role Profile & Auth Trigger */}
            <div className="p-4 bg-[#06070B] border-t border-[#1E2030] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={currentUser.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
                  alt={currentUser.name}
                  className="w-9 h-9 rounded-full object-cover border border-[#222436]"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">{currentUser.name}</span>
                    <span className="text-[9px] font-mono px-1.5 py-0.2 rounded font-bold bg-[#8B5CF6]/20 text-[#A78BFA] border border-[#8B5CF6]/40">
                      {ROLE_LABELS[currentUser.role]}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono block">
                    {currentUser.email}
                  </span>
                </div>
              </div>

              <button
                onClick={() => {
                  setShowAuthModal(true);
                  setMobileMenuOpen(false);
                }}
                className="min-h-[44px] px-3 py-2 rounded-xl bg-[#131422] hover:bg-[#1E2032] border border-[#25283D] text-xs font-semibold text-slate-200 hover:text-white flex items-center gap-1.5 cursor-pointer"
              >
                <UserCheck className="w-3.5 h-3.5 text-[#00F5FF]" />
                <span>Switch</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Navbar */}
        <header className="h-16 px-4 sm:px-6 bg-[#07080E]/90 backdrop-blur-md border-b border-[#1E2030] flex items-center justify-between shrink-0 z-20">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="md:hidden w-11 h-11 flex items-center justify-center text-slate-300 hover:text-white rounded-xl bg-[#121320] border border-[#1E2030] active:scale-95 transition-all"
              aria-label="Open full menu"
            >
              <Menu className="w-5 h-5" />
            </button>

            <button
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="hidden md:flex p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800/50 cursor-pointer"
              title="Toggle Sidebar"
            >
              <Menu className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2.5">
              <img
                src="/campusops-logo.png"
                alt="CampusOps"
                className="w-8 h-8 object-contain rounded-xl border border-[#222436] bg-[#0A0B12] p-1 shrink-0 shadow-sm shadow-[#00F5FF]/10"
              />
              <span className="hidden sm:inline text-xs font-semibold text-slate-400">View:</span>
              <span className="text-xs font-bold text-white bg-[#121320] px-2.5 py-1 rounded-lg border border-[#1E2030]">
                {navItems.find(i => i.id === activeTab)?.label}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => {
                setReportPrefill({ buildingId: selectedBuilding?.id });
                setShowReportModal(true);
              }}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#121320] hover:bg-[#1A1B2C] text-white text-xs font-medium border border-[#25283D] hover:border-[#00F5FF]/40 transition-colors cursor-pointer"
            >
              <Wrench className="w-3.5 h-3.5 text-[#00F5FF]" />
              <span>Report Complaint</span>
            </button>

            <button
              onClick={() => setRoomToBook(classrooms[0] || null)}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#7B2CBF] to-[#8B5CF6] text-white text-xs font-semibold hover:brightness-110 transition-all shadow-[0_0_15px_rgba(139,92,246,0.3)] cursor-pointer"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Book Space</span>
            </button>

            {/* Notification Bell with Real-Time Badge */}
            <button
              onClick={() => setActiveTab('notifications')}
              className={`relative min-w-[44px] min-h-[44px] flex items-center justify-center rounded-xl transition-all cursor-pointer ${
                activeTab === 'notifications'
                  ? 'bg-[#8B5CF6]/20 text-[#00F5FF] border border-[#8B5CF6]/50 shadow-[0_0_15px_rgba(139,92,246,0.25)]'
                  : 'bg-[#121320] hover:bg-[#191A2B] text-slate-300 border border-[#1E2030]'
              }`}
              title="Real-Time Technician & Operational Notifications"
              aria-label="View notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifCount > 0 && (
                <span className="absolute 1 -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-[#8B5CF6] text-white text-[10px] font-bold flex items-center justify-center font-mono shadow-[0_0_8px_rgba(139,92,246,0.6)]">
                  {unreadNotifCount > 9 ? '9+' : unreadNotifCount}
                </span>
              )}
            </button>

            <div className="h-6 w-[1px] bg-slate-800 hidden sm:block" />

            {/* User Badge with Role indicator & Account Switcher Dropdown */}
            <NavbarUserBadge
              currentUser={currentUser}
              onOpenAuthModal={() => setShowAuthModal(true)}
              onSwitchUser={handleSwitchUser}
            />
          </div>
        </header>

        {/* Viewport Content (with bottom padding on mobile for thumb dock) */}
        <main className="flex-1 relative overflow-y-auto pb-20 md:pb-0">
          {!canAccessTab(currentUser.role, activeTab) ? (
            <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
              <AccessDeniedView
                currentUser={currentUser}
                moduleName={allNavItems.find(i => i.id === activeTab)?.label || activeTab}
                requiredRole={getRequiredRoleForTab(activeTab)}
                onNavigateHome={() => setActiveTab('3d-campus')}
                onOpenAuth={() => setShowAuthModal(true)}
              />
            </div>
          ) : (
            <>
              {activeTab === '3d-campus' && (
            <div className="w-full h-full">
              <ThreeCampusViewer
                buildings={buildings}
                selectedBuilding={selectedBuilding}
                selectedFloor={selectedFloor}
                onSelectBuilding={handleSelectBuilding}
                onDeselectBuilding={handleDeselectBuilding}
                onSelectFloor={(fl) => {
                  setSelectedFloor(fl);
                  setActiveTab('floor-plan');
                }}
                onOpenFloorPlan={(b, fl) => handleOpenFloorPlan(b, fl)}
                onAddFloor={handleAddFloor}
                onRemoveFloor={handleRemoveFloor}
              />
            </div>
          )}

          {activeTab === 'dashboard' && (
            <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
              <DashboardView
                buildings={buildings}
                classrooms={classrooms}
                tickets={tickets}
                bookings={bookings}
                incidents={incidents}
                metrics={metrics}
                onNavigateTo3D={handleNavigateTo3D}
                onNavigateToFloorPlan={handleOpenFloorPlan}
                onOpenReportModal={() => setShowReportModal(true)}
                onOpenBookingModal={(room) => setRoomToBook(room || classrooms[0])}
                onNavigateTab={(tab) => setActiveTab(tab)}
              />
            </div>
          )}

          {activeTab === 'floor-plan' && (
            <div className="w-full h-full p-2 sm:p-4">
              <FloorPlanView
                building={selectedBuilding || buildings[0]}
                floor={selectedFloor || selectedBuilding?.floors[0] || buildings[0].floors[0]}
                classrooms={classrooms}
                onBackTo3D={() => handleNavigateTo3D(selectedBuilding || undefined)}
                onSelectRoom={() => {}}
                onSelectFloor={(fl) => setSelectedFloor(fl)}
                onBookRoom={(room: Classroom) => setRoomToBook(room)}
                onReportIssue={(room: Classroom) => {
                  setReportPrefill({
                    buildingId: room.buildingId,
                    roomId: room.id,
                    roomNumber: room.roomNumber
                  });
                  setShowReportModal(true);
                }}
                onAddFloor={handleAddFloor}
                onRemoveFloor={handleRemoveFloor}
              />
            </div>
          )}

          {activeTab === 'maintenance' && (
            <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
              <MaintenanceView
                tickets={scopedTickets}
                technicians={staff}
                currentUser={currentUser}
                onOpenReportModal={() => setShowReportModal(true)}
                onUpdateTicketStatus={handleUpdateTicketStatus}
              />
            </div>
          )}

          {activeTab === 'notifications' && (
            <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
              <NotificationsView
                currentUser={currentUser}
                onNavigateToComplaint={() => setActiveTab('maintenance')}
              />
            </div>
          )}

          {activeTab === 'procurement' && (
            <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
              <ProcurementView currentUser={currentUser} />
            </div>
          )}

          {activeTab === 'user-management' && (
            <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
              {currentUser.role === 'SYSTEM_ADMIN' ? (
                <UserManagementView currentUser={currentUser} />
              ) : (
                <AccessDeniedView 
                  currentUser={currentUser}
                  moduleName="User Directory & Administration"
                  requiredRole="SYSTEM_ADMIN"
                  onNavigateHome={() => setActiveTab('3d-campus')}
                  onOpenAuth={() => setShowAuthModal(true)}
                />
              )}
            </div>
          )}

          {activeTab === 'bookings' && (
            <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
              <BookingsView
                bookings={bookings}
                classrooms={classrooms}
                buildings={buildings}
                onOpenBookingModal={(room) => setRoomToBook(room || classrooms[0])}
                onCancelBooking={handleCancelBooking}
              />
            </div>
          )}

          {activeTab === 'inventory' && (
            <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
              <InventoryView
                inventory={inventory}
                onRestockItem={handleRestock}
                currentUser={currentUser}
              />
            </div>
          )}

          {activeTab === 'staff' && (
            <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
              <StaffView technicians={staff} />
            </div>
          )}

          {activeTab === 'incidents' && (
            <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
              <IncidentsView
                incidents={incidents}
                buildings={buildings}
                onAddIncident={handleAddIncident}
                onUpdateStatus={handleUpdateIncidentStatus}
              />
            </div>
          )}

          {activeTab === 'analytics' && (
            <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
              <AnalyticsView
                buildings={buildings}
                classrooms={classrooms}
                tickets={tickets}
                bookings={bookings}
              />
            </div>
          )}

          {activeTab === 'ai-chat' && (
            <div className="p-4 sm:p-6 max-w-5xl mx-auto h-full">
              <AiChatView
                onOpenBookingModal={(room) => setRoomToBook(room)}
                onOpenReportModal={(prefill) => {
                  setReportPrefill(prefill || {});
                  setShowReportModal(true);
                }}
              />
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto">
              <AiSettingsView />
            </div>
          )}
            </>
          )}
        </main>
      </div>

      {/* Accessible Mobile Bottom Navigation Dock (Natural Thumb Zone) */}
      <nav
        aria-label="Mobile Bottom Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#06070B]/95 backdrop-blur-2xl border-t border-[#1E2030] pb-[env(safe-area-inset-bottom)] px-2 shadow-[0_-10px_25px_rgba(0,0,0,0.8)]"
      >
        <div className="grid grid-cols-5 items-center h-16">
          {/* Tab 1: 3D Campus */}
          <button
            onClick={() => {
              setActiveTab('3d-campus');
              setMobileMenuOpen(false);
            }}
            className={`min-h-[48px] flex flex-col items-center justify-center py-1 transition-all active:scale-95 cursor-pointer ${
              activeTab === '3d-campus' ? 'text-[#00F5FF]' : 'text-slate-400 hover:text-slate-200'
            }`}
            aria-label="3D Campus View"
            aria-current={activeTab === '3d-campus' ? 'page' : undefined}
          >
            <Compass className={`w-5 h-5 transition-transform ${activeTab === '3d-campus' ? 'scale-110 drop-shadow-[0_0_8px_rgba(0,245,255,0.7)]' : ''}`} />
            <span className="text-[10px] font-bold tracking-tight mt-1">3D Campus</span>
            {activeTab === '3d-campus' && (
              <span className="w-1 h-1 rounded-full bg-[#8B5CF6] shadow-[0_0_4px_#8B5CF6] mt-0.5" />
            )}
          </button>

          {/* Tab 2: Floor Plans */}
          <button
            onClick={() => {
              setActiveTab('floor-plan');
              setMobileMenuOpen(false);
            }}
            className={`min-h-[48px] flex flex-col items-center justify-center py-1 transition-all active:scale-95 cursor-pointer ${
              activeTab === 'floor-plan' ? 'text-[#00F5FF]' : 'text-slate-400 hover:text-slate-200'
            }`}
            aria-label="Floor Plans Explorer"
            aria-current={activeTab === 'floor-plan' ? 'page' : undefined}
          >
            <Layers className={`w-5 h-5 transition-transform ${activeTab === 'floor-plan' ? 'scale-110 drop-shadow-[0_0_8px_rgba(0,245,255,0.7)]' : ''}`} />
            <span className="text-[10px] font-bold tracking-tight mt-1">Floor Plan</span>
            {activeTab === 'floor-plan' && (
              <span className="w-1 h-1 rounded-full bg-[#8B5CF6] shadow-[0_0_4px_#8B5CF6] mt-0.5" />
            )}
          </button>

          {/* Tab 3: Maintenance & Complaints */}
          <button
            onClick={() => {
              setActiveTab('maintenance');
              setMobileMenuOpen(false);
            }}
            className={`relative min-h-[48px] flex flex-col items-center justify-center py-1 transition-all active:scale-95 cursor-pointer ${
              activeTab === 'maintenance' ? 'text-[#00F5FF]' : 'text-slate-400 hover:text-slate-200'
            }`}
            aria-label="Maintenance & Complaints"
            aria-current={activeTab === 'maintenance' ? 'page' : undefined}
          >
            <div className="relative">
              <Wrench className={`w-5 h-5 transition-transform ${activeTab === 'maintenance' ? 'scale-110 drop-shadow-[0_0_8px_rgba(0,245,255,0.7)]' : ''}`} />
              {scopedTickets.filter(t => t.status !== 'resolved').length > 0 && (
                <span className="absolute -top-1.5 -right-2.5 px-1 min-w-[15px] h-[15px] rounded-full bg-[#8B5CF6] text-white text-[9px] font-mono font-bold flex items-center justify-center shadow-md">
                  {scopedTickets.filter(t => t.status !== 'resolved').length}
                </span>
              )}
            </div>
            <span className="text-[10px] font-bold tracking-tight mt-1">Issues</span>
            {activeTab === 'maintenance' && (
              <span className="w-1 h-1 rounded-full bg-[#8B5CF6] shadow-[0_0_4px_#8B5CF6] mt-0.5" />
            )}
          </button>

          {/* Tab 4: Room Bookings */}
          <button
            onClick={() => {
              setActiveTab('bookings');
              setMobileMenuOpen(false);
            }}
            className={`min-h-[48px] flex flex-col items-center justify-center py-1 transition-all active:scale-95 cursor-pointer ${
              activeTab === 'bookings' ? 'text-[#00F5FF]' : 'text-slate-400 hover:text-slate-200'
            }`}
            aria-label="Room Bookings"
            aria-current={activeTab === 'bookings' ? 'page' : undefined}
          >
            <Calendar className={`w-5 h-5 transition-transform ${activeTab === 'bookings' ? 'scale-110 drop-shadow-[0_0_8px_rgba(0,245,255,0.7)]' : ''}`} />
            <span className="text-[10px] font-bold tracking-tight mt-1">Book Space</span>
            {activeTab === 'bookings' && (
              <span className="w-1 h-1 rounded-full bg-[#8B5CF6] shadow-[0_0_4px_#8B5CF6] mt-0.5" />
            )}
          </button>

          {/* Tab 5: More Hub / Menu Drawer */}
          <button
            onClick={() => setMobileMenuOpen(prev => !prev)}
            className={`relative min-h-[48px] flex flex-col items-center justify-center py-1 transition-all active:scale-95 cursor-pointer ${
              mobileMenuOpen || !['3d-campus', 'floor-plan', 'maintenance', 'bookings'].includes(activeTab)
                ? 'text-[#8B5CF6]'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            aria-label="Open Full Campus Menu"
          >
            <div className="relative">
              <Menu className={`w-5 h-5 transition-transform ${mobileMenuOpen ? 'scale-110 text-[#00F5FF]' : ''}`} />
              {unreadNotifCount > 0 && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-[#00F5FF] shadow-[0_0_6px_#00F5FF] animate-pulse" />
              )}
            </div>
            <span className="text-[10px] font-bold tracking-tight mt-1">
              {mobileMenuOpen ? 'Close' : 'More'}
            </span>
            {(mobileMenuOpen || !['3d-campus', 'floor-plan', 'maintenance', 'bookings'].includes(activeTab)) && (
              <span className="w-1 h-1 rounded-full bg-[#00F5FF] shadow-[0_0_4px_#00F5FF] mt-0.5" />
            )}
          </button>
        </div>
      </nav>

      {/* Floating AI Copilot Widget (Present across all views including 3D) */}
      {activeTab !== 'ai-chat' && (
        <AiCopilotWidget
          onOpenBookingModal={(room) => setRoomToBook(room)}
          onOpenReportModal={() => setShowReportModal(true)}
        />
      )}

      {/* Modals */}
      {roomToBook && (
        <BookRoomModal
          room={roomToBook}
          onClose={() => setRoomToBook(null)}
          onSuccess={handleCreateBookingSuccess}
        />
      )}

      {showReportModal && (
        <ReportIssueModal
          building={selectedBuilding || buildings.find(b => b.id === reportPrefill.buildingId) || buildings[0]}
          room={reportPrefill.roomId ? classrooms.find(r => r.id === reportPrefill.roomId) : undefined}
          onClose={() => setShowReportModal(false)}
          onSuccess={handleCreateTicketSuccess}
        />
      )}
    </div>
  );
}
