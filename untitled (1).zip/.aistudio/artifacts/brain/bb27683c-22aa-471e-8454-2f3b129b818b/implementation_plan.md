# CampusOps – Advanced Role-Based Access Control (RBAC) & Admin User Management

This implementation plan outlines the architecture, database schema, backend endpoints, and frontend user experience for upgrading CampusOps with enterprise-grade Role-Based Access Control (RBAC) across six distinct roles, complete with admin-only user provisioning, scope-aware data filtering, multi-tier purchase approvals, and Google Authentication with a CAPTCHA gate.

***

### User Review & Critical Decisions

> [!IMPORTANT]
> **Key Architecture Decisions Confirmed:**
> - **Admin-Only Account Creation**: Public self-registration is disabled. Only the System Admin can create new user accounts, assign roles, assign departments, and configure custom permissions.
> - **Google Authentication & "I'm Not a Robot" CAPTCHA**: The login interface will support Google OAuth authentication and credentials login, preceded by an interactive, accessible "I am not a robot" CAPTCHA challenge. If an unprovisioned Google email attempts login, it is cleanly rejected with guidance to contact the System Admin.
> - **Purchase Approval Governance**: All purchase requests flow to Procurement by default. Department Managers or Facilities Admin can only approve requests if the System Admin has explicitly granted them a granular `purchase:approve` permission.
> - **Protected Primary Admin**: The primary System Admin account (`admin@campusops.edu`) is permanently protected against deletion, deactivation, or role demotion.

***

## 1. Overview & Core Concept

CampusOps will transform from a single-view operations console into a secure multi-persona campus management ecosystem. Every user belongs to one of six hierarchical roles:

1. **Student / Faculty**: Reports maintenance issues, tracks own complaints, responds to clarifications, books permitted spaces, and requests limited purchases.
2. **Technician**: Views strictly assigned work orders, updates repair statuses, inputs resolution notes, and requests spare parts.
3. **Department Manager**: Exercises oversight over departmental complaints, work orders, room bookings, and submits departmental purchase requests.
4. **Facilities Admin**: Manages campus-wide maintenance tickets, work orders, room scheduling conflicts, technician assignments, and inventory.
5. **Procurement**: Manages purchasing requests, reviews vendor requirements, approves or rejects acquisitions, and tracks stock replenishment.
6. **System Admin**: Omnipotent administrator managing user accounts, role assignments, department scopes, custom permission overrides, security settings, and global audit logs.

***

## 2. User Experience & Visual Design

### Design System & Theme Alignment
- **Aesthetic**: Futuristic Command Center retaining Jet Black (`#0A0A0C`), Neon Rose (`#FF2E88`), and Cerulean Blue (`#007BA7`).
- **Typography**: Plus Jakarta Sans for UI display hierarchy and JetBrains Mono (`tabular-nums`) for codes, metrics, timestamps, and audit identifiers.
- **Surface Elevation**: 1px subtle borders (`border-[#252630]`), clean unboxed metadata with dot separators (`·`), and zero mechanical pseudo-code comment headers.

### Navigation Architecture by Role
The sidebar navigation dynamically filters modules according to the authenticated user's permissions:

```
┌─────────────────────────┬────────────────────────────────────────────────────────┐
│ Role                    │ Visible Navigation Items                               │
├─────────────────────────┼────────────────────────────────────────────────────────┤
│ Student / Faculty       │ 3D Campus, My Complaints, Report Issue, Bookings,      │
│                         │ Notifications, AI Copilot                              │
├─────────────────────────┼────────────────────────────────────────────────────────┤
│ Technician              │ 3D Campus, Assigned Work Orders, Repair Status,        │
│                         │ Parts Requests, My Schedule, Notifications             │
├─────────────────────────┼────────────────────────────────────────────────────────┤
│ Department Manager      │ Department Dashboard, Dept Complaints, Dept Work       │
│                         │ Orders, Dept Bookings, Purchase Requests, Reports      │
├─────────────────────────┼────────────────────────────────────────────────────────┤
│ Facilities Admin        │ Command Center, 3D Campus, Floor Plans, All Complaints,│
│                         │ Incidents, Work Orders, Room Bookings, Inventory,      │
│                         │ Purchase Requests, Facilities Analytics                │
├─────────────────────────┼────────────────────────────────────────────────────────┤
│ Procurement             │ Procurement Dashboard, Purchase Requests, Pending      │
│                         │ Approvals, Inventory Shortages, Purchase History       │
├─────────────────────────┼────────────────────────────────────────────────────────┤
│ System Admin            │ Complete Command Center, User Management, Role &       │
│                         │ Permissions, 3D Campus, Complaints, Incidents, Work    │
│                         │ Orders, Bookings, Inventory, Procurement, Analytics,   │
│                         │ Security Audit Logs, System Settings                   │
└─────────────────────────┴────────────────────────────────────────────────────────┘
```

### Key User Flows
1. **Login & CAPTCHA Verification**:
   - The user opens the login portal or modal.
   - Solves the interactive "I am not a robot" security check.
   - Authenticates via Google Sign-In or enters email and password.
   - Backend validates that the account is active and pre-provisioned by System Admin.
   - The interface instantly loads the role-specific dashboard and scopes.

2. **System Admin User Management**:
   - Live KPI bar: Total Users, Active Users, Inactive Accounts, Distribution by Role, and Department counts.
   - Interactive user data table with search, role filter, department filter, and status badges.
   - Action controls: "Create User", "Edit User", "Change Role", "Assign Department", "Toggle Active/Inactive", "Reset Password", "Configure Permissions".
   - Create User Modal: Enforces full name, email format, role selection, department assignment, and auto-generated secure initial password.

3. **Purchase Approval Flow**:
   - Requester (Technician, Student/Faculty, Manager, Facilities Admin) creates a purchase request with item name, quantity, estimated cost, related work order, and justification.
   - Status defaults to `PENDING_REVIEW`.
   - Procurement users (and specifically authorized Managers/Facilities Admins) review requests with one-click "Approve" or "Reject" dialog with mandatory comments.
   - Approvals record timestamp, approver ID, and update inventory stock upon delivery.

4. **Access Denied Fallback**:
   - If a user attempts to navigate to a module outside their role scope, a styled `AccessDeniedView` displays a helpful explanation and a button to return to their permitted dashboard.

***

## 3. Key Product Decisions & Trade-Offs

- **Configurable Scope Engine vs Hardcoded Roles**:
  - *Chosen Approach*: Permissions are stored in database records associating `role`, `module`, `action`, and `scope` (`OWN`, `ASSIGNED`, `DEPARTMENT`, `CAMPUS`, `ALL`).
  - *Why*: Allows the System Admin to toggle permissions or delegate purchase approval without needing code redeployments.
- **Strict Backend Scope Filtering**:
  - *Chosen Approach*: Backend queries inject user ID, assigned technician ID, or department ID directly into SQLAlchemy query filters.
  - *Why*: Eliminates security vulnerabilities where malicious frontend requests attempt to read foreign department data.
- **Google OAuth Integration with Pre-Provisioned Validation**:
  - *Chosen Approach*: Google OAuth credential token is verified by the backend; user email must match an existing record created by the System Admin.
  - *Why*: Adheres to strict administrative compliance while providing modern single sign-on.

***

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        CampusOps Client (React SPA)                     │
│  ┌──────────────┐  ┌──────────────────┐  ┌───────────────────────────┐ │
│  │ Google Auth  │  │ CAPTCHA Gate     │  │ Role-Aware Navigation     │ │
│  └──────┬───────┘  └────────┬─────────┘  └─────────────┬─────────────┘ │
└─────────┼───────────────────┼──────────────────────────┼───────────────┘
          │                   │                          │
          ▼                   ▼                          ▼
┌────────────────────────────────────────────────────────────────────────┐
│                   FastAPI Backend (/api) & Security Layer               │
│  ┌───────────────────────┐  ┌────────────────────────────────────────┐ │
│  │ JWT / OAuth Validator │  │ Role & Permission Scope Dependency     │ │
│  └──────────┬────────────┘  └──────────────────┬─────────────────────┘ │
└─────────────┼──────────────────────────────────┼───────────────────────┘
              │                                  │
              ▼                                  ▼
┌────────────────────────────────────────────────────────────────────────┐
│                          Database (MySQL 8.x)                          │
│  ┌──────────────┐   ┌──────────────┐   ┌─────────────────────────────┐ │
│  │ users        │   │ departments  │   │ permissions                 │ │
│  ├──────────────┤   ├──────────────┤   ├─────────────────────────────┤ │
│  │ id (PK)      │   │ id (PK)      │   │ id (PK)                     │ │
│  │ email (UQ)   │◄──┤ name         │   │ module, action, default_scope│ │
│  │ role (ENUM)  │   │ code         │   └──────────────┬──────────────┘ │
│  │ department_id│   └──────────────┘                  │                │
│  └──────┬───────┘                                     ▼                │
│         │           ┌────────────────────────────────────────┐         │
│         │           │ role_permissions / user_permissions    │         │
│         ▼           └────────────────────────────────────────┘         │
│  ┌───────────────────────────────────────────────────────────────────┐ │
│  │ purchase_requests & purchase_approvals (M2M Traceability)         │ │
│  └───────────────────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────────────┘
```

### Database Schema Updates
1. **`users` Table**:
   - `role` Enum extended to: `STUDENT_FACULTY`, `TECHNICIAN`, `DEPT_MANAGER`, `FACILITIES_ADMIN`, `PROCUREMENT`, `SYSTEM_ADMIN`.
   - `department_id`: Integer, ForeignKey to `departments.id`, nullable.
   - `is_primary_admin`: Boolean, default False (protects root admin from deletion).
2. **`departments` Table**:
   - `id`, `name`, `code`, `description`, `created_at`.
3. **`permissions` & `role_permissions` Table**:
   - `module`: e.g., `COMPLAINTS`, `WORK_ORDERS`, `BOOKINGS`, `PURCHASES`, `USERS`, `INVENTORY`.
   - `action`: e.g., `READ`, `CREATE`, `UPDATE`, `DELETE`, `APPROVE`, `ASSIGN`.
   - `scope`: `OWN`, `ASSIGNED`, `DEPARTMENT`, `CAMPUS`, `ALL`.
4. **`user_permission_overrides` Table**:
   - Allows System Admin to grant special permissions (like `purchase:approve`) to specific users.
5. **`purchase_requests` & `purchase_approvals` Table**:
   - Stores item details, requester, department, related work order, estimated cost, status (`PENDING_REVIEW`, `APPROVED`, `REJECTED`, `ORDERED`, `RECEIVED`), and full approval history audit trails.

### API Endpoint Enhancements
- `POST /api/auth/google-login` — Validates Google ID token against pre-provisioned user database.
- `POST /api/auth/verify-captcha` — Verifies CAPTCHA token prior to authentication.
- `GET /api/users` & `POST /api/users` — Admin-only user management with department assignment.
- `PATCH /api/users/{id}/role` & `PATCH /api/users/{id}/status` — Admin role changes and activation toggling.
- `GET /api/users/me/permissions` — Returns resolved permissions and scopes for the frontend.
- `GET /api/purchases` & `POST /api/purchases` — Purchase request creation and role-scoped retrieval.
- `PATCH /api/purchases/{id}/approve` & `PATCH /api/purchases/{id}/reject` — Procurement and authorized approver actions.
- Scoped filtering applied to `GET /api/complaints`, `GET /api/work-orders`, and `GET /api/bookings`.

***

## 5. Verification & Test Plan

1. **Automated Backend Tests (`pytest`)**:
   - 18 dedicated tests verifying all 6 roles against permissions, scope barriers, admin-only user creation, protected primary admin, and purchase approval workflows.
2. **Frontend UI Verification**:
   - Verify dynamic navigation hides unauthorized tabs for each role.
   - Verify direct navigation to unauthorized URLs redirects to Access Denied.
   - Verify CAPTCHA challenge functions correctly on login.
   - Verify System Admin User Management dashboard can create, edit, activate/deactivate, and reassign roles.
3. **Compilation & Health**:
   - Verify `compile_applet` and `lint_applet` pass with zero errors.
