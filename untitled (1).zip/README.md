# CampusOps — Intelligent 3D Campus Operations Platform

CampusOps is a full-stack, futuristic 3D digital-twin campus operations platform featuring an interactive Three.js 3D campus model, architectural floor-plan navigation, work orders, room scheduling, inventory, incident tracking, telemetry, and an integrated AI operations copilot.

---

## 🚀 Quick Start Guide (Localhost)

### 1. Prerequisites
Ensure you have the following installed on your machine:
- **Node.js**: `v18.x`, `v20.x`, or higher ([Download Node.js](https://nodejs.org/))
- **npm** (comes bundled with Node.js) or **pnpm** / **yarn**

Verify your versions:
```bash
node -v   # Should output v18.0.0 or higher
npm -v
```

---

### 2. Extract & Navigate to the Project Folder
If you downloaded a `.zip` archive:
```bash
# Unzip the downloaded file
unzip CampusOps.zip -d CampusOps

# Move into the project directory
cd CampusOps
```

---

### 3. Install Dependencies
Install all required Node.js packages (including React 19, Three.js, Express, Tailwind CSS v4, Lucide icons, and Motion):
```bash
npm install
```

---

### 4. Configure Environment Variables (Optional)
Copy the example environment configuration:
```bash
# On macOS / Linux:
cp .env.example .env

# On Windows (Command Prompt):
copy .env.example .env

# On Windows (PowerShell):
cp .env.example .env
```

The file `.env` contains:
```env
# Optional: Set custom port (default is 3000)
PORT=3000

# Optional: Add your Gemini API key to enable live AI generative responses.
# If omitted or left empty, CampusOps automatically uses built-in smart heuristics fallback.
GEMINI_API_KEY=""
```
> **Note:** The Gemini API Key is completely **optional**. If you do not provide one, the CampusOps AI Copilot operates normally using smart built-in campus heuristics!

---

### 5. Run the Application in Development Mode
Start the full-stack server (runs Express backend + Vite dev server middleware on port 3000):
```bash
npm run dev
```

Open your browser and navigate to:
👉 **[http://localhost:3000](http://localhost:3000)**

---

### 6. Production Build & Run (Alternative)
To test the optimized production build:
```bash
# 1. Compile the frontend bundles
npm run build

# 2. Start the production server
NODE_ENV=production npm start
```
On Windows PowerShell:
```powershell
$env:NODE_ENV="production"; npm start
```

---

## 🛠️ Project Structure
- `server.ts` — Express REST API (buildings, classrooms, bookings, maintenance, copilot) & Vite dev middleware.
- `src/components/ThreeCampusViewer.tsx` — Full 3D Campus digital twin built with Three.js (isometric camera, custom shaders, road network, glowing plazas, raycasting, and smooth camera transitions).
- `src/components/FloorPlanView.tsx` — 2D vector architectural blueprint explorer with live room status and quick bookings.
- `src/components/DashboardView.tsx` — Real-time command center KPI overview and live activity feeds.
- `src/components/MaintenanceView.tsx` — Work orders & ticket management system.
- `src/components/BookingsView.tsx` — Classroom reservation & timetable system.
- `src/components/InventoryView.tsx` — Campus equipment & asset inventory.
- `src/components/StaffView.tsx` — Field technician roster & dispatch.
- `src/components/IncidentsView.tsx` — Critical incident management & dispatch.
- `src/components/AiChatView.tsx` & `src/components/AiCopilotWidget.tsx` — CampusOps AI Copilot.
- `src/data/seedData.ts` — Seed database for the campus buildings, rooms, tickets, and assets.

---

## ❓ Troubleshooting
- **Port 3000 is already in use?**
  Set a different port in your `.env` file (e.g. `PORT=3001`) or run:
  ```bash
  PORT=3001 npm run dev
  ```
- **Module errors or missing packages?**
  Delete `node_modules` and re-run `npm install`:
  ```bash
  rm -rf node_modules package-lock.json
  npm install
  ```
