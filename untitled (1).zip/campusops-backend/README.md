# CampusOps – Intelligent Campus Operations Platform
## Python FastAPI & MySQL Server 8.x Backend

A production-grade, modular, high-concurrency backend built with **FastAPI**, **MySQL 8.x**, **SQLAlchemy 2.0 ORM**, **Alembic migrations**, **JWT authentication**, and **Google Gemini AI**.

---

## 1. System Architecture

```text
campusops-backend/
│
├── app/
│   ├── main.py                     # FastAPI application entry point, CORS, and exception handlers
│   ├── core/
│   │   ├── config.py               # Pydantic BaseSettings environment configuration
│   │   ├── security.py             # Bcrypt password hashing and JWT encoding/decoding
│   │   ├── dependencies.py         # DB session & role-based access control dependencies
│   │   └── exceptions.py           # Standard HTTP & business logic exceptions
│   │
│   ├── database/
│   │   ├── connection.py           # SQLAlchemy 2.0 engine with connection pooling
│   │   ├── base.py                 # DeclarativeBase and TimestampMixin
│   │   └── session.py              # SessionLocal factory and get_db generator
│   │
│   ├── models/                     # SQLAlchemy 2.0 database entities
│   │   ├── user.py                 # User accounts with roles (ADMIN, FACILITY_MANAGER, STAFF, STUDENT)
│   │   ├── building.py             # Campus buildings
│   │   ├── room.py                 # Rooms, capacities, and availability statuses
│   │   ├── staff.py                # Staff technicians, skills, shifts, and workloads
│   │   ├── asset.py                # Equipment & infrastructure assets
│   │   ├── complaint.py            # Maintenance complaints with AI classifications
│   │   ├── incident.py             # Correlated campus incidents (M2M with complaints)
│   │   ├── work_order.py           # Work order state machine
│   │   ├── booking.py              # Concurrency-safe room reservations
│   │   ├── inventory.py            # Spare parts with non-negative check constraints
│   │   ├── reservation.py          # Part reservations linked to work orders
│   │   ├── notification.py         # In-app alerts
│   │   └── activity_log.py         # Audit logging
│   │
│   ├── schemas/                    # Pydantic v2 validation models
│   │   ├── common.py               # Standardized JSON response envelope
│   │   ├── auth.py, building.py, room.py, staff.py, complaint.py...
│   │   └── dashboard.py            # Aggregated analytics schemas
│   │
│   ├── routers/                    # REST API endpoints under /api
│   │   ├── auth.py, buildings.py, rooms.py, staff.py, complaints.py,
│   │   ├── incidents.py, work_orders.py, bookings.py, inventory.py,
│   │   ├── notifications.py, dashboard.py, ai.py
│   │
│   ├── services/                   # Business logic and external service integrations
│   │   ├── ai_service.py           # Gemini AI extraction + local heuristic reasoning
│   │   ├── complaint_service.py    # Intake pipeline, AI classification, duplicate detection
│   │   ├── duplicate_service.py    # Similarity scoring against unresolved complaints
│   │   ├── incident_service.py     # Outage clustering and correlation
│   │   ├── assignment_service.py   # Multi-factor technician ranking
│   │   ├── booking_service.py      # Concurrency-safe booking & alternative finder
│   │   ├── inventory_service.py    # Transactional stock reservations & restocking
│   │   └── notification_service.py # Alerts and activity logging
│   │
│   └── utils/
│       ├── enums.py, validators.py, helpers.py
│
├── migrations/                     # Alembic database migrations
├── tests/                          # Pytest test suite (16 comprehensive tests)
├── scripts/
│   └── seed_database.py            # Comprehensive mock database seeder
├── .env.example
├── requirements.txt
├── alembic.ini
└── README.md
```

---

## 2. Windows PowerShell Setup & Execution Guide

Follow these exact steps in **PowerShell (Run as Administrator or standard user)**.

### Step 1: Clone / Navigate to Backend Directory
```powershell
cd campusops-backend
```

### Step 2: Create and Activate Python Virtual Environment (Python 3.11+)
```powershell
# Create virtual environment
python -m venv venv

# If PowerShell script execution policy restricts scripts, allow local scripts:
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

# Activate virtual environment
.\venv\Scripts\Activate.ps1
```

### Step 3: Install Required Dependencies
```powershell
pip install --upgrade pip
pip install -r requirements.txt
```

### Step 4: Configure MySQL Database
Make sure **MySQL Server 8.x** is running on your system (e.g., via MySQL Workbench, Windows Services, or XAMPP).

In PowerShell or MySQL CLI:
```sql
CREATE DATABASE IF NOT EXISTS campusops_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### Step 5: Configure Environment Variables
Copy `.env.example` to `.env`:
```powershell
Copy-Item .env.example .env
```
Open `.env` in Notepad or VS Code and set your MySQL credentials:
```ini
DB_HOST=127.0.0.1
DB_PORT=3306
DB_USER=root
DB_PASSWORD=YourActualMySQLPasswordHere
DB_NAME=campusops_db
DATABASE_URL=mysql+pymysql://root:YourActualMySQLPasswordHere@127.0.0.1:3306/campusops_db
GEMINI_API_KEY=YourGoogleGeminiApiKeyHere
```

### Step 6: Run Database Migrations
Apply the initial schema to MySQL:
```powershell
alembic upgrade head
```

### Step 7: Seed the Database with Realistic Campus Data
Run the seeding script to populate buildings, rooms, 10 technicians, assets, 20+ complaints, bookings, and inventory:
```powershell
python scripts/seed_database.py
```

### Step 8: Start the FastAPI Backend Server
```powershell
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
- **Base API URL:** `http://127.0.0.1:8000/api`
- **Interactive Swagger Documentation:** `http://127.0.0.1:8000/docs`
- **ReDoc Documentation:** `http://127.0.0.1:8000/redoc`

### Step 9: Running Automated Tests
Run pytest in an isolated in-memory test database:
```powershell
pytest -v
```

---

## 3. Seeded Demo Accounts & Credentials

All test accounts share the default seed password: `CampusOps@2026`

| Role | Email | Password | Access Capabilities |
| :--- | :--- | :--- | :--- |
| **ADMIN** | `admin@campusops.edu` | `CampusOps@2026` | Full system control, user roles, buildings, correlation |
| **FACILITY_MANAGER** | `manager@campusops.edu` | `CampusOps@2026` | Dispatching, inventory restocking, work order overrides |
| **STAFF (Electrical)** | `staff.dennis@campusops.edu` | `CampusOps@2026` | Work orders, parts reservation, status updates |
| **STAFF (IT & Network)** | `staff.grace@campusops.edu` | `CampusOps@2026` | Work orders, parts reservation, status updates |
| **STUDENT** | `student@campusops.edu` | `CampusOps@2026` | Room booking, complaint submission, notifications |

---

## 4. REST API Endpoint Reference

All endpoints return a uniform JSON envelope:
```json
{
  "success": true,
  "message": "Operation completed successfully",
  "data": { ... }
}
```

### Authentication (`/api/auth`)
- `POST /api/auth/register` — Register a new student/faculty user account.
- `POST /api/auth/login` — Login with email and password; returns JWT access & refresh tokens.
- `POST /api/auth/refresh` — Refresh expired access token with valid refresh token.
- `GET /api/auth/me` — Retrieve current authenticated user profile.

### Campus Buildings & Classrooms (`/api/buildings`, `/api/rooms`)
- `GET /api/buildings` — List all campus complexes with floor counts and room counts.
- `GET /api/buildings/{id}` — Get single building details.
- `GET /api/buildings/{id}/rooms` — List all rooms within a specific building.
- `POST /api/buildings` — [ADMIN, FACILITY_MANAGER] Register a new campus building.
- `GET /api/rooms` — List classrooms with query filters (`building_id`, `floor`, `room_type`, `status`).
- `GET /api/rooms/{id}/availability` — Check room availability for a given date.

### Complaints & AI Intake (`/api/complaints`)
- `POST /api/complaints` — Submit an issue report. Triggers AI categorization, priority calculation, and duplicate check. If location is incomplete, marks as `AWAITING_CLARIFICATION`.
- `GET /api/complaints` — List complaints with filters (`building_id`, `category`, `priority`, `status`).
- `GET /api/complaints/{id}` — Retrieve detailed complaint record with candidate duplicates.
- `PUT /api/complaints/{id}` — Update complaint details or clarify missing information.
- `DELETE /api/complaints/{id}` — [ADMIN, FACILITY_MANAGER] Delete complaint.
- `POST /api/complaints/ingest-email` — Simulated email intake webhook (`sender_email`, `subject`, `body`).

### Incident Correlation (`/api/incidents`)
- `POST /api/incidents/correlate` — Analyzes unresolved complaints within a timeframe (e.g. 48 hours) to detect building-wide or campus outages.
- `POST /api/incidents/correlate/confirm-group` — Instantiates a correlated incident from recommended complaint cluster.
- `GET /api/incidents` — List campus incidents.
- `GET /api/incidents/{id}/complaints` — Retrieve all complaints linked to an incident.

### Intelligent Staff & Work Orders (`/api/work-orders`, `/api/staff`)
- `GET /api/staff` — List all technicians with departments, skill matrices, shifts, and workloads.
- `GET /api/staff/available` — List currently available technicians on duty.
- `POST /api/work-orders/{id}/recommend-staff` — Multi-factor ranking of technicians based on required skills, active workload, and shift schedule.
- `POST /api/work-orders/{id}/assign` — Assign work order to technician and increment workload.
- `POST /api/work-orders/{id}/reassign` — Reassign with reason tracking and workload re-balancing.
- `PATCH /api/work-orders/{id}/status` — Status transition (`NEW` → `ASSIGNED` → `IN_PROGRESS` → `RESOLVED` → `CLOSED`). Auto-consumes reserved inventory on resolution.
- `GET /api/work-orders/{id}/history` — Full chronological audit history.

### Concurrency-Safe Room Bookings (`/api/bookings`)
- `POST /api/bookings` — Creates room reservation with database row-level locking (`with_for_update()`) to prevent race conditions.
- `GET /api/bookings` — Filter bookings by room, date, and status.
- `GET /api/bookings/alternatives` — When a conflict or full room is detected, computes alternative available time slots and nearby rooms with suitable capacity.
- `DELETE /api/bookings/{id}` — Cancel a booking.

### Inventory & Spare Parts (`/api/inventory`)
- `GET /api/inventory` — List parts with stock levels and low-stock alerts.
- `POST /api/inventory/{id}/restock` — Add stock with quantity and notes.
- `POST /api/work-orders/{id}/reserve-parts` — Atomically reserves parts for a work order. If stock is insufficient, marks work order as `WAITING_FOR_PARTS`.
- `POST /api/reservations/{id}/release` — Releases reserved parts back to available inventory.

### Analytics Dashboard (`/api/dashboard`)
- `GET /api/dashboard/summary` — Aggregated real-time metrics (open tickets, critical incidents, workload, efficiency rate).
- `GET /api/dashboard/complaints` — Breakdown by category, priority, status, and building.
- `GET /api/dashboard/work-orders` — Status distribution and overdue tracking.
- `GET /api/dashboard/staff-workload` — Per-staff workload metrics.
- `GET /api/dashboard/inventory` — Low stock inventory alerts.

### Grounded AI Campus Copilot (`/api/ai`)
- `POST /api/ai/chat` — Campus operational assistant grounded strictly in live database records.

---

## 5. React + TypeScript Frontend Integration Examples

### Example 1: Axios Client Configuration
```typescript
// src/api/client.ts
import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Attach JWT access token automatically
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token');
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;
```

### Example 2: Submitting a Maintenance Complaint
```typescript
import api from './client';

export async function submitCampusComplaint(data: {
  description: string;
  buildingId: number;
  roomId?: number;
}) {
  const response = await api.post('/complaints', {
    description: data.description,
    building_id: data.buildingId,
    room_id: data.roomId,
    source: 'FORM'
  });
  return response.data; // { success: true, message: "...", data: { ... } }
}
```

### Example 3: Concurrency-Safe Room Booking with Fallback
```typescript
import api from './client';

export async function bookRoom(params: {
  roomId: number;
  purpose: string;
  bookingDate: string; // 'YYYY-MM-DD'
  startTime: string;   // 'HH:MM'
  endTime: string;     // 'HH:MM'
}) {
  try {
    const res = await api.post('/bookings', {
      room_id: params.roomId,
      purpose: params.purpose,
      booking_date: params.bookingDate,
      start_time: params.startTime,
      end_time: params.endTime
    });
    return { success: true, booking: res.data.data };
  } catch (err: any) {
    if (err.response?.status === 409) {
      // Fetch intelligent alternatives
      const altRes = await api.get('/bookings/alternatives', {
        params: {
          room_id: params.roomId,
          booking_date: params.bookingDate,
          start_time: params.startTime,
          end_time: params.endTime
        }
      });
      return { success: false, conflict: true, alternatives: altRes.data.data };
    }
    throw err;
  }
}
```

### Example 4: Interacting with AI Campus Copilot
```typescript
import api from './client';

export async function askCampusCopilot(question: string) {
  const res = await api.post('/ai/chat', { message: question });
  return res.data.data.reply;
}
```
