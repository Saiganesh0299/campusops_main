import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database.base import Base
from app.database.session import get_db
from app.main import app
from app.core.security import get_password_hash, create_access_token
from app.models.department import Department
from app.models.permission import Permission, RolePermission, UserPermissionOverride
from app.models.user import User
from app.models.building import Building
from app.models.room import Room
from app.models.staff import Staff
from app.models.inventory import Inventory
from app.models.complaint import Complaint
from app.models.work_order import WorkOrder
from app.models.purchase import PurchaseRequest, PurchaseApproval
from app.services.permission_service import permission_service
from app.utils.enums import (
    UserRole,
    AccessScope,
    ComplaintCategory,
    PriorityLevel,
    ComplaintStatus,
    WorkOrderStatus,
    PurchaseStatus
)

SQLALCHEMY_DATABASE_URL = "sqlite:///:memory:"

engine_test = create_engine(
    SQLALCHEMY_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine_test)

@pytest.fixture(scope="function")
def db_session():
    Base.metadata.create_all(bind=engine_test)
    session = TestingSessionLocal()
    try:
        # Initialize default permissions
        permission_service.ensure_default_permissions(session)

        # 1. Departments
        dept_cs = Department(code="CS", name="Computer Science")
        dept_ee = Department(code="EE", name="Electrical Engineering")
        dept_fac = Department(code="FAC", name="Facilities")
        dept_proc = Department(code="PROC", name="Procurement")
        session.add_all([dept_cs, dept_ee, dept_fac, dept_proc])
        session.flush()

        # 2. Seed Users for all 6 roles
        pw = get_password_hash("CampusOps@2026")

        admin = User(
            full_name="System Admin",
            email="admin@campusops.edu",
            password_hash=pw,
            role=UserRole.SYSTEM_ADMIN,
            is_active=True,
            is_primary_admin=True
        )
        fac_admin = User(
            full_name="Facilities Admin",
            email="facilities.admin@campusops.edu",
            password_hash=pw,
            role=UserRole.FACILITIES_ADMIN,
            department_id=dept_fac.id,
            is_active=True
        )
        mgr_cs = User(
            full_name="CS Manager",
            email="manager.cs@campusops.edu",
            password_hash=pw,
            role=UserRole.DEPT_MANAGER,
            department_id=dept_cs.id,
            is_active=True
        )
        mgr_ee = User(
            full_name="EE Manager",
            email="manager.ee@campusops.edu",
            password_hash=pw,
            role=UserRole.DEPT_MANAGER,
            department_id=dept_ee.id,
            is_active=True
        )
        tech = User(
            full_name="Dennis Tech",
            email="tech.dennis@campusops.edu",
            password_hash=pw,
            role=UserRole.TECHNICIAN,
            department_id=dept_ee.id,
            is_active=True
        )
        proc = User(
            full_name="Procurement Officer",
            email="procurement.officer@campusops.edu",
            password_hash=pw,
            role=UserRole.PROCUREMENT,
            department_id=dept_proc.id,
            is_active=True
        )
        student1 = User(
            full_name="Alex Student",
            email="student.alex@campusops.edu",
            password_hash=pw,
            role=UserRole.STUDENT_FACULTY,
            department_id=dept_cs.id,
            is_active=True
        )
        student2 = User(
            full_name="Bob Student",
            email="student.bob@campusops.edu",
            password_hash=pw,
            role=UserRole.STUDENT_FACULTY,
            department_id=dept_ee.id,
            is_active=True
        )

        session.add_all([admin, fac_admin, mgr_cs, mgr_ee, tech, proc, student1, student2])
        session.flush()

        # Explicit purchase approval delegation for mgr_ee
        p_appr = session.query(Permission).filter(Permission.module == "PURCHASES", Permission.action == "APPROVE").first()
        if p_appr:
            ov = UserPermissionOverride(user_id=mgr_ee.id, permission_id=p_appr.id, scope=AccessScope.DEPARTMENT, is_granted=True)
            session.add(ov)

        # Technician Staff Profile
        staff_rec = Staff(
            user_id=tech.id,
            employee_code="TECH-001",
            department="Electrical",
            skills=["electrical", "lighting"],
            shift_start="08:00",
            shift_end="17:00",
            is_available=True,
            current_workload=0
        )
        session.add(staff_rec)

        # Buildings & Rooms
        bldg = Building(building_code="TEST-B1", building_name="Test Complex", total_floors=2)
        session.add(bldg)
        session.flush()

        room1 = Room(building_id=bldg.id, room_number="101", room_name="Lab 101", capacity=30, availability_status="available")
        room2 = Room(building_id=bldg.id, room_number="102", room_name="Lab 102", capacity=30, availability_status="available")
        session.add_all([room1, room2])
        session.flush()

        # Inventory
        inv = Inventory(
            item_code="PART-01",
            item_name="LED Bulb",
            category="Electrical",
            total_quantity=20,
            available_quantity=20,
            reserved_quantity=0,
            minimum_stock_level=5,
            storage_location="Shelf 1"
        )
        session.add(inv)
        session.commit()

        yield session
    finally:
        session.close()
        Base.metadata.drop_all(bind=engine_test)

@pytest.fixture(scope="function")
def client(db_session):
    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as test_client:
        yield test_client
    app.dependency_overrides.clear()

def make_header(db_session, email):
    u = db_session.query(User).filter(User.email == email).first()
    token = create_access_token({"sub": str(u.id), "email": u.email, "role": u.role.value})
    return {"Authorization": f"Bearer {token}"}

@pytest.fixture
def admin_headers(db_session):
    return make_header(db_session, "admin@campusops.edu")

@pytest.fixture
def fac_admin_headers(db_session):
    return make_header(db_session, "facilities.admin@campusops.edu")

@pytest.fixture
def mgr_cs_headers(db_session):
    return make_header(db_session, "manager.cs@campusops.edu")

@pytest.fixture
def mgr_ee_headers(db_session):
    return make_header(db_session, "manager.ee@campusops.edu")

@pytest.fixture
def tech_headers(db_session):
    return make_header(db_session, "tech.dennis@campusops.edu")

@pytest.fixture
def proc_headers(db_session):
    return make_header(db_session, "procurement.officer@campusops.edu")

@pytest.fixture
def student_headers(db_session):
    return make_header(db_session, "student.alex@campusops.edu")

@pytest.fixture
def student2_headers(db_session):
    return make_header(db_session, "student.bob@campusops.edu")
