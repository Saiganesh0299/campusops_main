import pytest
from datetime import date, timedelta
from app.models.building import Building
from app.models.room import Room
from app.models.inventory import Inventory
from app.models.complaint import Complaint
from app.models.work_order import WorkOrder
from app.models.purchase import PurchaseRequest
from app.models.user import User
from app.models.activity_log import ActivityLog
from app.utils.enums import UserRole, PurchaseStatus, WorkOrderStatus, ComplaintStatus

# 1. System Admin can access every module
def test_system_admin_access_all_modules(client, admin_headers):
    for endpoint in ["/api/users", "/api/dashboard/summary", "/api/work-orders", "/api/purchases", "/api/complaints"]:
        res = client.get(endpoint, headers=admin_headers)
        assert res.status_code == 200, f"Admin failed to access {endpoint}"
        assert res.json()["success"] is True

# 2. Only System Admin can create users (public registration is disabled)
def test_only_system_admin_can_create_users(client, admin_headers, student_headers, tech_headers):
    # Public registration disabled
    pub_res = client.post("/api/auth/register", json={
        "full_name": "Intruder",
        "email": "intruder@test.edu",
        "password": "Password123!"
    })
    assert pub_res.status_code == 403

    # Student cannot create user
    student_res = client.post("/api/users", headers=student_headers, json={
        "full_name": "New User",
        "email": "student_created@test.edu",
        "password": "Password123!",
        "role": "STUDENT_FACULTY"
    })
    assert student_res.status_code == 403

    # Admin CAN create user
    admin_res = client.post("/api/users", headers=admin_headers, json={
        "full_name": "Authorized User",
        "email": "auth_user@test.edu",
        "password": "Password123!",
        "role": "STUDENT_FACULTY"
    })
    assert admin_res.status_code == 201
    assert admin_res.json()["data"]["email"] == "auth_user@test.edu"

# 3. Only System Admin can change roles
def test_only_system_admin_can_change_roles(client, admin_headers, student_headers, db_session):
    student = db_session.query(User).filter(User.email == "student.alex@campusops.edu").first()

    # Student cannot change role
    fail_res = client.patch(f"/api/users/{student.id}/role", headers=student_headers, json={"role": "SYSTEM_ADMIN"})
    assert fail_res.status_code == 403

    # Admin can change role
    ok_res = client.patch(f"/api/users/{student.id}/role", headers=admin_headers, json={"role": "TECHNICIAN"})
    assert ok_res.status_code == 200
    assert ok_res.json()["data"]["role"] == "TECHNICIAN"

# 4. Students can submit and view their own complaints
def test_students_submit_and_view_own_complaints(client, student_headers, db_session):
    bldg = db_session.query(Building).first()
    room = db_session.query(Room).first()

    # Submit complaint
    create_res = client.post("/api/complaints", headers=student_headers, json={
        "description": "Lab air conditioning is not turning on",
        "building_id": bldg.id,
        "room_id": room.id
    })
    assert create_res.status_code == 201
    c_id = create_res.json()["data"]["id"]

    # View list (should contain this complaint)
    list_res = client.get("/api/complaints", headers=student_headers)
    assert list_res.status_code == 200
    ids = [c["id"] for c in list_res.json()["data"]]
    assert c_id in ids

# 5. Students cannot access unrestricted room booking management or cancel others' bookings
def test_student_booking_restrictions(client, student_headers, admin_headers, db_session):
    room = db_session.query(Room).first()
    today_str = str(date.today() + timedelta(days=3))

    # Admin creates booking
    admin_bk = client.post("/api/bookings", headers=admin_headers, json={
        "room_id": room.id,
        "purpose": "Executive Board Meeting",
        "booking_date": today_str,
        "start_time": "14:00",
        "end_time": "16:00"
    })
    bk_id = admin_bk.json()["data"]["id"]

    # Student cannot cancel admin's booking
    del_res = client.post(f"/api/bookings/{bk_id}", headers=student_headers)  # delete via post or delete
    del_res2 = client.delete(f"/api/bookings/{bk_id}", headers=student_headers)
    assert del_res2.status_code == 403

# 6. Technicians can view only their assigned work orders
def test_technician_assigned_work_orders_only(client, tech_headers, admin_headers, db_session):
    bldg = db_session.query(Building).first()
    room = db_session.query(Room).first()

    # Create complaint and work order
    c = Complaint(
        complaint_code="CMP-T1",
        building_id=bldg.id,
        room_id=room.id,
        description="Transformer issue",
        status=ComplaintStatus.SUBMITTED
    )
    db_session.add(c)
    db_session.flush()

    wo_unassigned = WorkOrder(
        work_order_code="WO-UNASSIGNED",
        complaint_id=c.id,
        assigned_staff_id=None,
        description="Unassigned electrical work",
        status=WorkOrderStatus.NEW
    )
    db_session.add(wo_unassigned)
    db_session.commit()

    # Tech views work orders
    tech_orders = client.get("/api/work-orders", headers=tech_headers)
    assert tech_orders.status_code == 200
    tech_wo_codes = [w["work_order_code"] for w in tech_orders.json()["data"]]
    assert "WO-UNASSIGNED" not in tech_wo_codes

# 7. Technicians can update repair status but cannot assign jobs
def test_technician_cannot_assign_jobs(client, tech_headers, db_session):
    wo = db_session.query(WorkOrder).first()
    staff = db_session.query(User).filter(User.role == UserRole.TECHNICIAN).first()

    res = client.post(f"/api/work-orders/{wo.id}/assign", headers=tech_headers, json={
        "staff_id": staff.id
    })
    assert res.status_code == 403
    assert "access denied" in res.json()["message"].lower() or "forbidden" in res.json()["message"].lower()

# 8. Department Managers can access only their department's records
def test_department_manager_access_department_only(client, mgr_cs_headers, student_headers, student2_headers, db_session):
    bldg = db_session.query(Building).first()
    room = db_session.query(Room).first()

    # Student 1 in CS submits complaint
    c_cs = client.post("/api/complaints", headers=student_headers, json={
        "description": "CS Department server room thermostat failure",
        "building_id": bldg.id,
        "room_id": room.id
    }).json()["data"]["id"]

    # Student 2 in EE submits complaint
    c_ee = client.post("/api/complaints", headers=student2_headers, json={
        "description": "EE Department high voltage generator grounding fault",
        "building_id": bldg.id,
        "room_id": room.id
    }).json()["data"]["id"]

    # CS Manager list complaints -> Should include c_cs but NOT c_ee
    cs_list = client.get("/api/complaints", headers=mgr_cs_headers)
    assert cs_list.status_code == 200
    visible_ids = [c["id"] for c in cs_list.json()["data"]]
    assert c_cs in visible_ids
    assert c_ee not in visible_ids

# 9. Department Managers cannot manage other departments
def test_department_manager_cannot_manage_other_departments(client, mgr_cs_headers, db_session):
    ee_dept = db_session.query(User).filter(User.email == "manager.ee@campusops.edu").first().department_id

    # CS Manager trying to fetch EE department-specific complaints
    res = client.get(f"/api/departments/{ee_dept}/complaints", headers=mgr_cs_headers)
    assert res.status_code == 403

# 10. Facilities Admin can assign and reassign campus-wide work orders
def test_facilities_admin_can_assign_work_orders(client, fac_admin_headers, db_session):
    wo = db_session.query(WorkOrder).first()
    staff_u = db_session.query(User).filter(User.email == "tech.dennis@campusops.edu").first()

    res = client.post(f"/api/work-orders/{wo.id}/assign", headers=fac_admin_headers, json={
        "staff_id": staff_u.staff_profile.id
    })
    assert res.status_code == 200
    assert res.json()["data"]["status"] == "ASSIGNED"

# 11. Procurement can approve purchase requests
def test_procurement_can_approve_purchase_requests(client, proc_headers, tech_headers, db_session):
    # Tech submits purchase request
    req_res = client.post("/api/purchases", headers=tech_headers, json={
        "item_name": "Schneider Electric Inverter Board",
        "category": "Electrical",
        "quantity": 1,
        "estimated_unit_cost": 450.0,
        "justification": "Burnt power module replacement"
    })
    assert req_res.status_code == 201
    pr_id = req_res.json()["data"]["id"]

    # Procurement approves request
    appr_res = client.patch(f"/api/purchases/{pr_id}/approve", headers=proc_headers, json={
        "comments": "Approved against Q4 maintenance inventory budget"
    })
    assert appr_res.status_code == 200
    assert appr_res.json()["data"]["status"] == "APPROVED"

# 12. Department Managers and Facilities Admin can approve purchases only when separately authorised
def test_purchase_approval_separate_authorization(client, mgr_cs_headers, mgr_ee_headers, tech_headers, db_session):
    # Tech in EE submits purchase request in EE
    ee_dept = db_session.query(User).filter(User.email == "manager.ee@campusops.edu").first().department_id
    pr_res = client.post("/api/purchases", headers=tech_headers, json={
        "item_name": "EE Lab High Voltage Probe",
        "category": "Tools",
        "quantity": 2,
        "estimated_unit_cost": 210.0,
        "department_id": ee_dept,
        "justification": "Precision testing for EE lab"
    })
    pr_id = pr_res.json()["data"]["id"]

    # CS Manager (NO explicit approval authorization) -> 403 Forbidden
    res_cs = client.patch(f"/api/purchases/{pr_id}/approve", headers=mgr_cs_headers, json={"comments": "Denied"})
    assert res_cs.status_code == 403

    # EE Manager (HAS explicit approval delegation for EE department) -> 200 OK
    res_ee = client.patch(f"/api/purchases/{pr_id}/approve", headers=mgr_ee_headers, json={"comments": "Approved by EE Chair"})
    assert res_ee.status_code == 200
    assert res_ee.json()["data"]["status"] == "APPROVED"

# 13. Unauthorised users cannot access restricted pages/endpoints (403)
def test_unauthorized_endpoints_rejected(client, student_headers):
    for ep in ["/api/users", "/api/users/summary", "/api/dashboard/work-orders"]:
        res = client.get(ep, headers=student_headers)
        assert res.status_code == 403

# 14. Unauthorised API requests without token are rejected (401)
def test_unauthenticated_requests_rejected(client):
    res = client.get("/api/users")
    assert res.status_code == 401

# 15. Users cannot change their own roles or permissions
def test_users_cannot_change_own_roles(client, tech_headers, db_session):
    tech = db_session.query(User).filter(User.email == "tech.dennis@campusops.edu").first()
    res = client.patch(f"/api/users/{tech.id}/role", headers=tech_headers, json={"role": "SYSTEM_ADMIN"})
    assert res.status_code == 403

# 16. Deactivated users cannot log in
def test_deactivated_users_cannot_login(client, admin_headers, db_session):
    student = db_session.query(User).filter(User.email == "student.alex@campusops.edu").first()

    # Deactivate account
    client.patch(f"/api/users/{student.id}/status?is_active=false", headers=admin_headers)

    # Attempt login
    login_res = client.post("/api/auth/login", json={
        "email": "student.alex@campusops.edu",
        "password": "CampusOps@2026"
    })
    assert login_res.status_code == 401
    assert "deactivated" in login_res.json()["message"].lower()

# 17. Purchase approvals are recorded in audit logs
def test_purchase_approval_audit_logging(client, proc_headers, tech_headers, db_session):
    pr_res = client.post("/api/purchases", headers=tech_headers, json={
        "item_name": "Audit Test Part",
        "category": "Electrical",
        "quantity": 1,
        "estimated_unit_cost": 50.0,
        "justification": "Testing audit log recording"
    })
    pr_id = pr_res.json()["data"]["id"]

    client.patch(f"/api/purchases/{pr_id}/approve", headers=proc_headers, json={
        "comments": "Audited approval"
    })

    # Check ActivityLog
    log = db_session.query(ActivityLog).filter(
        ActivityLog.action == "APPROVE_PURCHASE",
        ActivityLog.entity_id == str(pr_id)
    ).first()
    assert log is not None
    assert "Audited" in log.description or "Approved" in log.description

# 18. Users cannot access another user's private complaint records
def test_cannot_access_other_user_complaint_directly(client, student_headers, student2_headers, db_session):
    bldg = db_session.query(Building).first()
    room = db_session.query(Room).first()

    # Student 2 creates complaint
    c_res = client.post("/api/complaints", headers=student2_headers, json={
        "description": "Student 2 confidential private complaint",
        "building_id": bldg.id,
        "room_id": room.id
    })
    c2_id = c_res.json()["data"]["id"]

    # Student 1 attempts to access student 2's complaint
    view_res = client.get(f"/api/complaints/{c2_id}", headers=student_headers)
    assert view_res.status_code == 403
    assert "access denied" in view_res.json()["message"].lower() or "own" in view_res.json()["message"].lower()
