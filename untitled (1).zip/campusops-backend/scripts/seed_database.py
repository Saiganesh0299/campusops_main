import sys
import os
from datetime import datetime, date, time, timedelta, timezone

# Add parent directory to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.core.security import get_password_hash
from app.database.connection import engine
from app.database.session import SessionLocal
from app.database.base import Base
from app.models.department import Department
from app.models.permission import Permission, RolePermission, UserPermissionOverride
from app.models.user import User
from app.models.building import Building
from app.models.room import Room
from app.models.staff import Staff
from app.models.asset import Asset
from app.models.complaint import Complaint
from app.models.incident import Incident
from app.models.work_order import WorkOrder
from app.models.booking import Booking
from app.models.inventory import Inventory
from app.models.reservation import InventoryReservation
from app.models.purchase import PurchaseRequest, PurchaseApproval
from app.models.notification import Notification
from app.models.activity_log import ActivityLog
from app.services.permission_service import permission_service
from app.utils.enums import (
    UserRole,
    AccessScope,
    ComplaintCategory,
    PriorityLevel,
    ComplaintStatus,
    ComplaintSource,
    WorkOrderStatus,
    BookingStatus,
    IncidentStatus,
    InventoryReservationStatus,
    PurchaseStatus,
    NotificationType
)

def seed_database():
    print("Initializing CampusOps database schema...")
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    try:
        # Check if already seeded
        if db.query(User).filter(User.is_primary_admin == True).first():
            print("Database already contains primary administrator. Refreshing permissions and ensuring core roles...")
            permission_service.ensure_default_permissions(db)
            return

        print("1. Initializing RBAC Permission Matrix...")
        permission_service.ensure_default_permissions(db)

        print("2. Seeding Academic and Operations Departments...")
        dept_cs = Department(code="CS", name="Computer Science & Engineering", description="School of Computing and Information Systems")
        dept_ee = Department(code="EE", name="Electrical & Power Systems", description="Department of Electrical and Energy Technologies")
        dept_me = Department(code="ME", name="Mechanical & Robotics", description="Department of Mechanical Engineering and Mechatronics")
        dept_fac = Department(code="FAC", name="Facilities & Infrastructure", description="Campus Physical Plant and Building Operations")
        dept_proc = Department(code="PROC", name="Procurement & Supply Chain", description="University Sourcing, Vendors, and Inventory Acquisition")
        dept_admin = Department(code="ADMIN", name="Campus Executive Administration", description="Central Operations Leadership")

        db.add_all([dept_cs, dept_ee, dept_me, dept_fac, dept_proc, dept_admin])
        db.flush()

        print("3. Seeding The 6 Key Personas with Documented Roles...")
        default_pw = get_password_hash("CampusOps@2026")

        # 1. System Admin (Primary protected root admin)
        admin_user = User(
            full_name="Dr. Arthur Vance (System Admin)",
            email="admin@campusops.edu",
            password_hash=default_pw,
            role=UserRole.SYSTEM_ADMIN,
            department_id=dept_admin.id,
            is_active=True,
            is_primary_admin=True
        )

        # 2. Facilities Admin
        facilities_admin = User(
            full_name="Marcus Sterling (Facilities Admin)",
            email="facilities.admin@campusops.edu",
            password_hash=default_pw,
            role=UserRole.FACILITIES_ADMIN,
            department_id=dept_fac.id,
            is_active=True
        )

        # 3. Department Manager (Computer Science)
        manager_cs = User(
            full_name="Prof. Sarah Lin (CS Dept Manager)",
            email="manager.cs@campusops.edu",
            password_hash=default_pw,
            role=UserRole.DEPT_MANAGER,
            department_id=dept_cs.id,
            is_active=True
        )

        # 3b. Department Manager (Electrical Engineering - with explicit purchase approval delegation)
        manager_ee = User(
            full_name="Prof. David Kumar (EE Dept Manager)",
            email="manager.ee@campusops.edu",
            password_hash=default_pw,
            role=UserRole.DEPT_MANAGER,
            department_id=dept_ee.id,
            is_active=True
        )

        # 4. Technician (Lead Electrical Tech)
        tech_dennis = User(
            full_name="Dennis Ritchie (Senior Electrician)",
            email="tech.dennis@campusops.edu",
            password_hash=default_pw,
            role=UserRole.TECHNICIAN,
            department_id=dept_ee.id,
            is_active=True
        )

        # 4b. Technician (IT & Network Tech)
        tech_grace = User(
            full_name="Grace Hopper (Lead Network Tech)",
            email="tech.grace@campusops.edu",
            password_hash=default_pw,
            role=UserRole.TECHNICIAN,
            department_id=dept_cs.id,
            is_active=True
        )

        # 5. Procurement Officer
        procurement_officer = User(
            full_name="Helena Croft (Procurement Officer)",
            email="procurement.officer@campusops.edu",
            password_hash=default_pw,
            role=UserRole.PROCUREMENT,
            department_id=dept_proc.id,
            is_active=True
        )

        # 6. Student / Faculty
        student_alex = User(
            full_name="Alex Mercer (Graduate Student)",
            email="student.alex@campusops.edu",
            password_hash=default_pw,
            role=UserRole.STUDENT_FACULTY,
            department_id=dept_cs.id,
            is_active=True
        )

        faculty_rachel = User(
            full_name="Dr. Rachel Chen (Faculty Researcher)",
            email="faculty.rachel@campusops.edu",
            password_hash=default_pw,
            role=UserRole.STUDENT_FACULTY,
            department_id=dept_cs.id,
            is_active=True
        )

        db.add_all([
            admin_user,
            facilities_admin,
            manager_cs,
            manager_ee,
            tech_dennis,
            tech_grace,
            procurement_officer,
            student_alex,
            faculty_rachel
        ])
        db.flush()

        print("4. Delegating Explicit Purchase Approval Override to Prof. David Kumar...")
        purchase_approve_perm = db.query(Permission).filter(
            Permission.module == "PURCHASES",
            Permission.action == "APPROVE"
        ).first()

        if purchase_approve_perm:
            override = UserPermissionOverride(
                user_id=manager_ee.id,
                permission_id=purchase_approve_perm.id,
                scope=AccessScope.DEPARTMENT,
                is_granted=True
            )
            db.add(override)
            db.flush()

        print("5. Seeding Buildings & Classrooms...")
        bldg_orion = Building(
            building_code="OAB",
            building_name="Orion Academic Block",
            description="Central campus academic complex with 3 floors of lecture halls, seminar rooms, and faculty suites.",
            total_floors=3
        )
        bldg_turing = Building(
            building_code="TEH",
            building_name="Turing Engineering Hub",
            description="Advanced technology center featuring 4 floors of robotics, hardware labs, and cybersecurity centers.",
            total_floors=4
        )
        bldg_lovelace = Building(
            building_code="ALSC",
            building_name="Ada Lovelace Science Center",
            description="Computational mathematics and biotechnology wing with 3 floors of wet labs and cleanrooms.",
            total_floors=3
        )
        db.add_all([bldg_orion, bldg_turing, bldg_lovelace])
        db.flush()

        rooms = [
            Room(building_id=bldg_orion.id, floor_number=0, room_number="OAB-001", room_name="Newton Auditorium", room_type="Auditorium", capacity=180),
            Room(building_id=bldg_orion.id, floor_number=0, room_number="OAB-002", room_name="General Lecture Hall A", room_type="Lecture Hall", capacity=75),
            Room(building_id=bldg_orion.id, floor_number=1, room_number="OAB-101", room_name="Calculus Studio", room_type="Classroom", capacity=45),
            Room(building_id=bldg_orion.id, floor_number=1, room_number="OAB-102", room_name="Faculty Meeting Suite", room_type="Conference Room", capacity=25),
            Room(building_id=bldg_turing.id, floor_number=0, room_number="TEH-001", room_name="Robotics Arena", room_type="Laboratory", capacity=60),
            Room(building_id=bldg_turing.id, floor_number=1, room_number="TEH-101", room_name="Embedded Systems Lab", room_type="Laboratory", capacity=40),
            Room(building_id=bldg_lovelace.id, floor_number=0, room_number="ALSC-001", room_name="Bio-Computation Lab", room_type="Laboratory", capacity=35)
        ]
        db.add_all(rooms)
        db.flush()

        print("6. Linking Technicians Staff Profiles...")
        staff_d = Staff(
            user_id=tech_dennis.id,
            employee_code="TECH-001",
            department="Electrical",
            skills=["electrical", "power", "hvac", "lighting"],
            shift_start="08:00",
            shift_end="17:00",
            is_available=True,
            current_workload=1
        )
        staff_g = Staff(
            user_id=tech_grace.id,
            employee_code="TECH-002",
            department="IT & Network",
            skills=["it_network", "wifi", "ethernet", "routers"],
            shift_start="08:00",
            shift_end="17:00",
            is_available=True,
            current_workload=1
        )
        db.add_all([staff_d, staff_g])
        db.flush()

        print("7. Seeding Inventory Spare Parts...")
        inv_items = [
            Inventory(item_code="PART-LED-18W", item_name="18W Modular LED Ceiling Panel", category="Electrical", description="Standard 600x600 ceiling panel", total_quantity=45, available_quantity=42, reserved_quantity=3, minimum_stock_level=10, storage_location="Warehouse A, Rack 2"),
            Inventory(item_code="PART-HDMI-10M", item_name="10-Meter High-Speed 4K HDMI Cable", category="Classroom Equipment", description="Heavy duty shielded HDMI cable", total_quantity=25, available_quantity=22, reserved_quantity=3, minimum_stock_level=5, storage_location="AV Depot, Shelf 1"),
            Inventory(item_code="PART-CAT6A-305M", item_name="Cat6A Shielded Bulk Cable Box", category="IT Network", description="305-meter plenum box", total_quantity=8, available_quantity=3, reserved_quantity=5, minimum_stock_level=4, storage_location="Network Server Room 101"),
            Inventory(item_code="PART-VALVE-BALL", item_name="1-Inch Brass Ball Valve", category="Plumbing", description="Heavy duty plumbing valve", total_quantity=18, available_quantity=18, reserved_quantity=0, minimum_stock_level=6, storage_location="Plumbing Workshop Bin 4")
        ]
        db.add_all(inv_items)
        db.flush()

        print("8. Seeding Complaints & Work Orders...")
        c1 = Complaint(
            complaint_code="CMP-261030-0001",
            submitted_by=student_alex.id,
            building_id=bldg_orion.id,
            room_id=rooms[2].id,
            description="Ceiling lighting panel flickering rapidly in Calculus Studio",
            category=ComplaintCategory.ELECTRICAL,
            priority=PriorityLevel.MEDIUM,
            status=ComplaintStatus.WORK_ORDER_CREATED,
            source=ComplaintSource.FORM,
            ai_summary="Flickering ceiling light fixture",
            ai_confidence=0.94
        )
        c2 = Complaint(
            complaint_code="CMP-261030-0002",
            submitted_by=faculty_rachel.id,
            building_id=bldg_turing.id,
            room_id=rooms[5].id,
            description="High latency and packet drops on primary Ethernet switches in Embedded Lab",
            category=ComplaintCategory.IT_NETWORK,
            priority=PriorityLevel.HIGH,
            status=ComplaintStatus.WORK_ORDER_CREATED,
            source=ComplaintSource.CHATBOT,
            ai_summary="Ethernet network packet loss",
            ai_confidence=0.91
        )
        db.add_all([c1, c2])
        db.flush()

        wo1 = WorkOrder(
            work_order_code="WO-261030-0001",
            complaint_id=c1.id,
            assigned_staff_id=staff_d.id,
            description="Replace ballast and LED panel in OAB-101",
            priority=PriorityLevel.MEDIUM,
            status=WorkOrderStatus.IN_PROGRESS
        )
        wo2 = WorkOrder(
            work_order_code="WO-261030-0002",
            complaint_id=c2.id,
            assigned_staff_id=staff_g.id,
            description="Inspect patch panels and replace Cat6A uplink in TEH-101",
            priority=PriorityLevel.HIGH,
            status=WorkOrderStatus.ASSIGNED
        )
        db.add_all([wo1, wo2])
        db.flush()

        print("9. Seeding Purchase Requests & Approval Workflows...")
        # Request 1: Submitted by Dennis (Technician) for wo1 -> Approved by Procurement
        pr1 = PurchaseRequest(
            request_code="PR-261030-0001",
            requester_id=tech_dennis.id,
            department_id=dept_ee.id,
            work_order_id=wo1.id,
            item_name="Schneider Electric Smart Circuit Breaker 32A",
            category="Electrical",
            quantity=2,
            estimated_unit_cost=145.0,
            total_estimated_cost=290.0,
            justification="Required to replace burnt breaker in OAB-101 electrical panel",
            status=PurchaseStatus.APPROVED
        )
        # Request 2: Submitted by Dennis -> Pending review
        pr2 = PurchaseRequest(
            request_code="PR-261030-0002",
            requester_id=tech_dennis.id,
            department_id=dept_ee.id,
            work_order_id=wo1.id,
            item_name="Industrial Digital Multimeter Clamp Kit",
            category="Tools",
            quantity=1,
            estimated_unit_cost=320.0,
            total_estimated_cost=320.0,
            justification="Precision load diagnostics for substation feeder inspection",
            status=PurchaseStatus.PENDING_REVIEW
        )
        # Request 3: Submitted by Prof Sarah Lin (CS Manager) -> Pending procurement review
        pr3 = PurchaseRequest(
            request_code="PR-261030-0003",
            requester_id=manager_cs.id,
            department_id=dept_cs.id,
            work_order_id=None,
            item_name="Cisco 24-Port Gigabit Managed POE Switch",
            category="Networking",
            quantity=3,
            estimated_unit_cost=850.0,
            total_estimated_cost=2550.0,
            justification="Departmental lab infrastructure upgrade for CS capstone project clusters",
            status=PurchaseStatus.PENDING_REVIEW
        )

        db.add_all([pr1, pr2, pr3])
        db.flush()

        # Record approval for pr1 by Helena Croft (Procurement)
        app1 = PurchaseApproval(
            purchase_request_id=pr1.id,
            approver_id=procurement_officer.id,
            action="APPROVED",
            comments="Verified against electrical maintenance budget allocation. PO dispatched."
        )
        db.add(app1)

        print("10. Seeding Room Bookings...")
        today = date.today()
        b1 = Booking(
            booking_code="BK-261030-0001",
            room_id=rooms[0].id,
            requested_by=manager_cs.id,
            purpose="Computer Science Colloquium",
            booking_date=today + timedelta(days=2),
            start_time=time(10, 0),
            end_time=time(12, 0),
            status=BookingStatus.CONFIRMED
        )
        b2 = Booking(
            booking_code="BK-261030-0002",
            room_id=rooms[2].id,
            requested_by=student_alex.id,
            purpose="Peer Study Circle",
            booking_date=today + timedelta(days=1),
            start_time=time(14, 0),
            end_time=time(16, 0),
            status=BookingStatus.CONFIRMED
        )
        db.add_all([b1, b2])

        print("11. Seeding Audit Logs...")
        log_init = ActivityLog(
            user_id=admin_user.id,
            action="INITIALIZE_RBAC",
            entity_type="Security",
            entity_id="GLOBAL",
            description="CampusOps 6-Role Hierarchical RBAC and Department Scopes initialized."
        )
        db.add(log_init)

        db.commit()
        print("CampusOps database seeding completed successfully!")

    except Exception as e:
        db.rollback()
        print(f"Error seeding database: {e}")
        raise
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()
