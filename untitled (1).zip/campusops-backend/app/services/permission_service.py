from typing import Dict, List, Optional, Tuple
from sqlalchemy.orm import Session
from app.models.permission import Permission, RolePermission, UserPermissionOverride
from app.models.user import User
from app.utils.enums import UserRole, AccessScope

# Default permission matrix definitions: (module, action, description, role_scopes)
DEFAULT_PERMISSION_MATRIX = [
    # COMPLAINTS
    ("COMPLAINTS", "REPORT", "Submit a maintenance complaint", {
        UserRole.STUDENT_FACULTY: AccessScope.OWN,
        UserRole.TECHNICIAN: AccessScope.CAMPUS,
        UserRole.DEPT_MANAGER: AccessScope.DEPARTMENT,
        UserRole.FACILITIES_ADMIN: AccessScope.CAMPUS,
        UserRole.PROCUREMENT: AccessScope.CAMPUS,
        UserRole.SYSTEM_ADMIN: AccessScope.ALL,
    }),
    ("COMPLAINTS", "READ", "View complaints", {
        UserRole.STUDENT_FACULTY: AccessScope.OWN,
        UserRole.TECHNICIAN: AccessScope.ASSIGNED,
        UserRole.DEPT_MANAGER: AccessScope.DEPARTMENT,
        UserRole.FACILITIES_ADMIN: AccessScope.CAMPUS,
        UserRole.PROCUREMENT: AccessScope.CAMPUS,
        UserRole.SYSTEM_ADMIN: AccessScope.ALL,
    }),
    ("COMPLAINTS", "UPDATE", "Update complaint details or status", {
        UserRole.STUDENT_FACULTY: AccessScope.OWN,
        UserRole.TECHNICIAN: AccessScope.ASSIGNED,
        UserRole.DEPT_MANAGER: AccessScope.DEPARTMENT,
        UserRole.FACILITIES_ADMIN: AccessScope.CAMPUS,
        UserRole.SYSTEM_ADMIN: AccessScope.ALL,
    }),

    # WORK_ORDERS
    ("WORK_ORDERS", "READ", "View work orders", {
        UserRole.STUDENT_FACULTY: AccessScope.OWN,
        UserRole.TECHNICIAN: AccessScope.ASSIGNED,
        UserRole.DEPT_MANAGER: AccessScope.DEPARTMENT,
        UserRole.FACILITIES_ADMIN: AccessScope.CAMPUS,
        UserRole.SYSTEM_ADMIN: AccessScope.ALL,
    }),
    ("WORK_ORDERS", "UPDATE_STATUS", "Update repair status on work order", {
        UserRole.TECHNICIAN: AccessScope.ASSIGNED,
        UserRole.DEPT_MANAGER: AccessScope.DEPARTMENT,
        UserRole.FACILITIES_ADMIN: AccessScope.CAMPUS,
        UserRole.SYSTEM_ADMIN: AccessScope.ALL,
    }),
    ("WORK_ORDERS", "ASSIGN", "Assign or reassign work orders to staff", {
        UserRole.DEPT_MANAGER: AccessScope.DEPARTMENT,
        UserRole.FACILITIES_ADMIN: AccessScope.CAMPUS,
        UserRole.SYSTEM_ADMIN: AccessScope.ALL,
    }),
    ("WORK_ORDERS", "CREATE", "Create work orders directly", {
        UserRole.FACILITIES_ADMIN: AccessScope.CAMPUS,
        UserRole.SYSTEM_ADMIN: AccessScope.ALL,
    }),

    # ROOM_BOOKINGS
    ("BOOKINGS", "CREATE", "Request room bookings", {
        UserRole.STUDENT_FACULTY: AccessScope.OWN,
        UserRole.DEPT_MANAGER: AccessScope.DEPARTMENT,
        UserRole.FACILITIES_ADMIN: AccessScope.CAMPUS,
        UserRole.SYSTEM_ADMIN: AccessScope.ALL,
    }),
    ("BOOKINGS", "READ", "View room bookings", {
        UserRole.STUDENT_FACULTY: AccessScope.OWN,
        UserRole.DEPT_MANAGER: AccessScope.DEPARTMENT,
        UserRole.FACILITIES_ADMIN: AccessScope.CAMPUS,
        UserRole.SYSTEM_ADMIN: AccessScope.ALL,
    }),
    ("BOOKINGS", "MANAGE", "Cancel or approve room bookings campus-wide", {
        UserRole.DEPT_MANAGER: AccessScope.DEPARTMENT,
        UserRole.FACILITIES_ADMIN: AccessScope.CAMPUS,
        UserRole.SYSTEM_ADMIN: AccessScope.ALL,
    }),

    # PURCHASES
    ("PURCHASES", "REQUEST", "Request purchases for spare parts/equipment", {
        UserRole.STUDENT_FACULTY: AccessScope.OWN,
        UserRole.TECHNICIAN: AccessScope.ASSIGNED,
        UserRole.DEPT_MANAGER: AccessScope.DEPARTMENT,
        UserRole.FACILITIES_ADMIN: AccessScope.CAMPUS,
        UserRole.SYSTEM_ADMIN: AccessScope.ALL,
    }),
    ("PURCHASES", "READ", "View purchase requests", {
        UserRole.STUDENT_FACULTY: AccessScope.OWN,
        UserRole.TECHNICIAN: AccessScope.ASSIGNED,
        UserRole.DEPT_MANAGER: AccessScope.DEPARTMENT,
        UserRole.FACILITIES_ADMIN: AccessScope.CAMPUS,
        UserRole.PROCUREMENT: AccessScope.ALL,
        UserRole.SYSTEM_ADMIN: AccessScope.ALL,
    }),
    ("PURCHASES", "APPROVE", "Approve or reject purchase requests", {
        UserRole.PROCUREMENT: AccessScope.ALL,
        UserRole.SYSTEM_ADMIN: AccessScope.ALL,
        # Note: DEPT_MANAGER and FACILITIES_ADMIN can only approve when separately authorized via UserPermissionOverride
    }),

    # USER MANAGEMENT
    ("USERS", "MANAGE", "Create users, assign roles, change permissions", {
        UserRole.SYSTEM_ADMIN: AccessScope.ALL,
    }),
    ("USERS", "READ", "View user accounts and profiles", {
        UserRole.SYSTEM_ADMIN: AccessScope.ALL,
    })
]

class PermissionService:
    @staticmethod
    def ensure_default_permissions(db: Session):
        """
        Seeds all system permissions and maps the default role permission matrix.
        """
        for module, action, desc, role_map in DEFAULT_PERMISSION_MATRIX:
            perm = db.query(Permission).filter(
                Permission.module == module,
                Permission.action == action
            ).first()

            if not perm:
                perm = Permission(
                    module=module,
                    action=action,
                    default_scope=AccessScope.OWN,
                    description=desc
                )
                db.add(perm)
                db.flush()

            # Map default role permissions
            for role, scope in role_map.items():
                rp = db.query(RolePermission).filter(
                    RolePermission.role == role,
                    RolePermission.permission_id == perm.id
                ).first()
                if not rp:
                    rp = RolePermission(
                        role=role,
                        permission_id=perm.id,
                        scope=scope,
                        is_enabled=True
                    )
                    db.add(rp)

        db.commit()

    @staticmethod
    def get_user_effective_permissions(db: Session, user: User) -> List[Dict[str, any]]:
        """
        Calculates user's resolved permissions taking into account their role and any user overrides.
        """
        # 1. Fetch role-based permissions
        role_perms = db.query(RolePermission).join(Permission).filter(
            RolePermission.role == user.role,
            RolePermission.is_enabled == True
        ).all()

        perms_map: Dict[Tuple[str, str], AccessScope] = {}
        for rp in role_perms:
            perms_map[(rp.permission.module, rp.permission.action)] = rp.scope

        # 2. Apply user-specific overrides (e.g. explicitly granted purchase:approve to a manager)
        overrides = db.query(UserPermissionOverride).join(Permission).filter(
            UserPermissionOverride.user_id == user.id
        ).all()

        for ov in overrides:
            if ov.is_granted:
                perms_map[(ov.permission.module, ov.permission.action)] = ov.scope
            else:
                perms_map.pop((ov.permission.module, ov.permission.action), None)

        # 3. System Admin always has ALL access to everything
        if user.role == UserRole.SYSTEM_ADMIN:
            for module, action, _, _ in DEFAULT_PERMISSION_MATRIX:
                perms_map[(module, action)] = AccessScope.ALL

        return [
            {
                "module": mod,
                "action": act,
                "scope": sc.value,
                "is_granted": True
            }
            for (mod, act), sc in perms_map.items()
        ]

    @staticmethod
    def user_has_permission(
        db: Session,
        user: User,
        module: str,
        action: str,
        minimum_scope: Optional[AccessScope] = None
    ) -> Tuple[bool, Optional[AccessScope]]:
        """
        Determines whether user has authorization for (module, action), returning (authorized, granted_scope).
        """
        if user.role == UserRole.SYSTEM_ADMIN:
            return True, AccessScope.ALL

        # Check user-specific override first
        perm = db.query(Permission).filter(
            Permission.module == module,
            Permission.action == action
        ).first()

        if perm:
            user_ov = db.query(UserPermissionOverride).filter(
                UserPermissionOverride.user_id == user.id,
                UserPermissionOverride.permission_id == perm.id
            ).first()

            if user_ov:
                if not user_ov.is_granted:
                    return False, None
                return True, user_ov.scope

        # Check role permission
        if perm:
            rp = db.query(RolePermission).filter(
                RolePermission.role == user.role,
                RolePermission.permission_id == perm.id,
                RolePermission.is_enabled == True
            ).first()
            if rp:
                return True, rp.scope

        return False, None

permission_service = PermissionService()
