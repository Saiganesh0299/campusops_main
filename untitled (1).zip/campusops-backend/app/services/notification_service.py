from typing import Optional
from sqlalchemy.orm import Session
from app.models.notification import Notification
from app.models.activity_log import ActivityLog
from app.utils.enums import NotificationType

class NotificationService:
    @staticmethod
    def notify_user(
        db: Session,
        user_id: int,
        title: str,
        message: str,
        notification_type: NotificationType = NotificationType.SYSTEM
    ) -> Notification:
        notif = Notification(
            user_id=user_id,
            title=title,
            message=message,
            notification_type=notification_type
        )
        db.add(notif)
        db.commit()
        db.refresh(notif)
        return notif

    @staticmethod
    def log_activity(
        db: Session,
        action: str,
        entity_type: str,
        entity_id: str,
        description: str,
        user_id: Optional[int] = None
    ) -> ActivityLog:
        log = ActivityLog(
            user_id=user_id,
            action=action,
            entity_type=entity_type,
            entity_id=str(entity_id),
            description=description
        )
        db.add(log)
        db.commit()
        db.refresh(log)
        return log

notification_service = NotificationService()
