from datetime import datetime
from typing import List, Optional
from sqlalchemy.orm import Session
from app.models.staff import Staff
from app.models.work_order import WorkOrder
from app.schemas.staff import StaffRecommendationResponse
from app.utils.enums import PriorityLevel

class AssignmentService:
    @staticmethod
    def is_within_shift(shift_start: str, shift_end: str, current_time_str: Optional[str] = None) -> bool:
        """
        Validates whether current time falls within staff shift window (format 'HH:MM').
        """
        if not current_time_str:
            current_time_str = datetime.now().strftime("%H:%M")
        try:
            cur = datetime.strptime(current_time_str, "%H:%M").time()
            start = datetime.strptime(shift_start, "%H:%M").time()
            end = datetime.strptime(shift_end, "%H:%M").time()
            if start <= end:
                return start <= cur <= end
            else:  # Overnight shift
                return cur >= start or cur <= end
        except Exception:
            return True

    @staticmethod
    def recommend_technicians(
        db: Session,
        work_order: WorkOrder,
        limit: int = 5
    ) -> List[StaffRecommendationResponse]:
        """
        Ranks available technicians by skill relevance, availability, active workload, and shift window.
        """
        all_staff = db.query(Staff).all()
        complaint = work_order.complaint
        category_name = complaint.category.value if complaint and complaint.category else ""
        desc_lower = work_order.description.lower()

        recommendations = []
        for staff in all_staff:
            if not staff.is_available:
                continue

            score = 50.0  # Base eligibility
            reasons = []

            # 1. Skill Match
            staff_skills = [s.lower() for s in (staff.skills or [])]
            skill_matched = False
            if category_name.lower() in staff_skills:
                score += 35.0
                skill_matched = True
                reasons.append(f"Certified for {category_name}")
            elif any(s in desc_lower for s in staff_skills):
                score += 25.0
                skill_matched = True
                reasons.append("Relevant diagnostic skill matched")

            # 2. Shift timing check
            on_shift = AssignmentService.is_within_shift(staff.shift_start, staff.shift_end)
            if on_shift:
                score += 15.0
                reasons.append("Currently on active shift")
            else:
                score -= 20.0
                reasons.append(f"Off shift window ({staff.shift_start}-{staff.shift_end})")

            # 3. Workload Penalty
            workload_penalty = min(30.0, staff.current_workload * 6.0)
            score -= workload_penalty
            if staff.current_workload == 0:
                score += 10.0
                reasons.append("Zero active queue load")
            else:
                reasons.append(f"{staff.current_workload} active work orders in queue")

            # 4. Priority handling
            if work_order.priority in [PriorityLevel.CRITICAL, PriorityLevel.HIGH]:
                if skill_matched and staff.current_workload < 3:
                    score += 10.0
                    reasons.append("High priority emergency readiness")

            final_score = max(5.0, min(99.0, round(score, 1)))

            full_name = staff.user.full_name if staff.user else staff.employee_code
            recommendations.append(StaffRecommendationResponse(
                staff_id=staff.id,
                employee_code=staff.employee_code,
                name=full_name,
                department=staff.department,
                skills=staff.skills or [],
                current_workload=staff.current_workload,
                is_available=staff.is_available,
                shift=f"{staff.shift_start}-{staff.shift_end}",
                score=final_score,
                recommendation_reason="; ".join(reasons)
            ))

        recommendations.sort(key=lambda x: x.score, reverse=True)
        return recommendations[:limit]

assignment_service = AssignmentService()
