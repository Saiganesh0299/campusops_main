from datetime import datetime
from typing import Optional, Tuple, List
from sqlalchemy.orm import Session
from app.models.complaint import Complaint
from app.models.work_order import WorkOrder
from app.models.building import Building
from app.models.room import Room
from app.schemas.complaint import ComplaintCreate, DuplicateComplaintCandidate
from app.services.ai_service import ai_service
from app.services.duplicate_service import duplicate_service
from app.services.notification_service import notification_service
from app.utils.enums import ComplaintStatus, WorkOrderStatus, NotificationType

class ComplaintService:
    @staticmethod
    async def process_and_create_complaint(
        db: Session,
        data: ComplaintCreate,
        submitted_by: Optional[int] = None
    ) -> Tuple[Complaint, Optional[WorkOrder], List[DuplicateComplaintCandidate]]:
        # Fetch building & room details
        building = db.query(Building).filter(Building.id == data.building_id).first()
        room = db.query(Room).filter(Room.id == data.room_id).first() if data.room_id else None

        building_name = building.building_name if building else "Campus"
        room_num = room.room_number if room else None

        # AI Extraction & Categorization
        ai_res = await ai_service.analyze_complaint(
            description=data.description,
            building_code_or_name=building_name,
            room_number=room_num
        )

        category = data.category or ai_res.category
        priority = data.priority or ai_res.priority

        # Duplicate scan
        duplicates = duplicate_service.find_potential_duplicates(
            db=db,
            description=data.description,
            building_id=data.building_id,
            room_id=data.room_id,
            asset_id=data.asset_id,
            category=category.value
        )

        # Generate unique code
        count = db.query(Complaint).count() + 1
        code = f"CMP-{datetime.now().strftime('%y%m%d')}-{count:04d}"

        # Check if missing vital information
        is_missing = len(ai_res.missing_fields) > 0 and not data.room_id
        initial_status = ComplaintStatus.AWAITING_CLARIFICATION if is_missing else ComplaintStatus.SUBMITTED

        complaint = Complaint(
            complaint_code=code,
            submitted_by=submitted_by,
            building_id=data.building_id,
            room_id=data.room_id,
            asset_id=data.asset_id,
            description=data.description,
            category=category,
            priority=priority,
            status=initial_status,
            source=data.source,
            ai_summary=ai_res.summary,
            ai_confidence=ai_res.confidence,
            missing_information=ai_res.clarification_question if is_missing else None
        )
        db.add(complaint)
        db.commit()
        db.refresh(complaint)

        work_order = None
        # If complete (not missing vital info), create work order
        if not is_missing:
            wo_count = db.query(WorkOrder).count() + 1
            wo_code = f"WO-{datetime.now().strftime('%y%m%d')}-{wo_count:04d}"
            work_order = WorkOrder(
                work_order_code=wo_code,
                complaint_id=complaint.id,
                description=f"Resolve: {complaint.ai_summary or complaint.description}",
                priority=complaint.priority,
                status=WorkOrderStatus.CATEGORISED
            )
            db.add(work_order)
            complaint.status = ComplaintStatus.WORK_ORDER_CREATED
            db.commit()
            db.refresh(work_order)

        # Log activity
        notification_service.log_activity(
            db=db,
            action="CREATE_COMPLAINT",
            entity_type="Complaint",
            entity_id=str(complaint.id),
            description=f"Complaint #{complaint.complaint_code} filed: {complaint.ai_summary or complaint.description[:60]}",
            user_id=submitted_by
        )

        return complaint, work_order, duplicates

complaint_service = ComplaintService()
