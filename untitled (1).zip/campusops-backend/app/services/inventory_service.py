from datetime import datetime, timezone
from typing import Optional
from sqlalchemy.orm import Session
from app.core.exceptions import ConflictException, NotFoundException
from app.models.inventory import Inventory
from app.models.reservation import InventoryReservation
from app.models.work_order import WorkOrder
from app.utils.enums import InventoryReservationStatus, WorkOrderStatus

class InventoryService:
    @staticmethod
    def reserve_parts_for_work_order(
        db: Session,
        work_order_id: int,
        inventory_id: int,
        quantity: int
    ) -> InventoryReservation:
        """
        Concurrency-safe stock reservation using row-level locking.
        If stock is insufficient, updates work order status to WAITING_FOR_PARTS.
        """
        work_order = db.query(WorkOrder).filter(WorkOrder.id == work_order_id).first()
        if not work_order:
            raise NotFoundException(f"Work order #{work_order_id} not found")

        # Lock inventory row for update
        item = db.query(Inventory).filter(Inventory.id == inventory_id).with_for_update().first()
        if not item:
            raise NotFoundException(f"Inventory item #{inventory_id} not found")

        if item.available_quantity < quantity:
            # Mark work order as waiting for parts
            work_order.status = WorkOrderStatus.WAITING_FOR_PARTS
            db.commit()
            raise ConflictException(
                f"Insufficient stock for '{item.item_name}'. Required: {quantity}, Available: {item.available_quantity}. Work Order #{work_order.work_order_code} marked as WAITING_FOR_PARTS."
            )

        # Update inventory stock atomically
        item.available_quantity -= quantity
        item.reserved_quantity += quantity

        reservation = InventoryReservation(
            inventory_id=inventory_id,
            work_order_id=work_order_id,
            quantity=quantity,
            status=InventoryReservationStatus.RESERVED
        )
        db.add(reservation)
        db.commit()
        db.refresh(reservation)
        return reservation

    @staticmethod
    def release_reservation(
        db: Session,
        reservation_id: int
    ) -> InventoryReservation:
        """
        Releases reserved parts back into available stock.
        """
        reservation = db.query(InventoryReservation).filter(InventoryReservation.id == reservation_id).first()
        if not reservation:
            raise NotFoundException(f"Reservation #{reservation_id} not found")

        if reservation.status != InventoryReservationStatus.RESERVED:
            raise ConflictException(f"Reservation is already {reservation.status.value}")

        item = db.query(Inventory).filter(Inventory.id == reservation.inventory_id).with_for_update().first()
        if item:
            item.reserved_quantity = max(0, item.reserved_quantity - reservation.quantity)
            item.available_quantity += reservation.quantity

        reservation.status = InventoryReservationStatus.RELEASED
        reservation.released_at = datetime.now(timezone.utc)
        db.commit()
        db.refresh(reservation)
        return reservation

    @staticmethod
    def consume_reservations_for_work_order(
        db: Session,
        work_order_id: int
    ):
        """
        Finalizes reserved parts into consumed when work order is completed.
        Reduces total_quantity and reserved_quantity.
        """
        reservations = db.query(InventoryReservation).filter(
            InventoryReservation.work_order_id == work_order_id,
            InventoryReservation.status == InventoryReservationStatus.RESERVED
        ).all()

        for res in reservations:
            item = db.query(Inventory).filter(Inventory.id == res.inventory_id).with_for_update().first()
            if item:
                item.total_quantity = max(0, item.total_quantity - res.quantity)
                item.reserved_quantity = max(0, item.reserved_quantity - res.quantity)
            res.status = InventoryReservationStatus.CONSUMED

        db.commit()

    @staticmethod
    def restock_item(
        db: Session,
        inventory_id: int,
        added_quantity: int
    ) -> Inventory:
        item = db.query(Inventory).filter(Inventory.id == inventory_id).with_for_update().first()
        if not item:
            raise NotFoundException(f"Inventory item #{inventory_id} not found")

        item.total_quantity += added_quantity
        item.available_quantity += added_quantity
        db.commit()
        db.refresh(item)
        return item

inventory_service = InventoryService()
