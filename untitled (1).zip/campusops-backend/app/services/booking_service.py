from datetime import date, time, datetime
from typing import List, Optional, Tuple
from sqlalchemy import and_, or_
from sqlalchemy.orm import Session
from app.core.exceptions import ConflictException, ValidationException
from app.models.booking import Booking
from app.models.room import Room
from app.schemas.booking import AlternativeRoomOption, AlternativeBookingsResponse
from app.utils.enums import BookingStatus

def parse_time_str(val: str) -> time:
    parts = val.split(":")
    return time(hour=int(parts[0]), minute=int(parts[1]))

class BookingService:
    @staticmethod
    def check_room_conflict(
        db: Session,
        room_id: int,
        booking_date: date,
        start_t: time,
        end_t: time,
        exclude_booking_id: Optional[int] = None,
        lock_row: bool = False
    ) -> Optional[Booking]:
        """
        Detects if an existing confirmed booking overlaps with the requested interval:
        (new_start < existing_end) and (new_end > existing_start)
        """
        query = db.query(Booking).filter(
            Booking.room_id == room_id,
            Booking.booking_date == booking_date,
            Booking.status == BookingStatus.CONFIRMED,
            Booking.start_time < end_t,
            Booking.end_time > start_t
        )

        if exclude_booking_id:
            query = query.filter(Booking.id != exclude_booking_id)

        if lock_row:
            # Row-level locking for concurrency safety in MySQL/Postgres
            query = query.with_for_update()

        return query.first()

    @staticmethod
    def find_alternatives(
        db: Session,
        room_id: int,
        booking_date: date,
        start_t: time,
        end_t: time,
        required_capacity: int = 1
    ) -> AlternativeBookingsResponse:
        original_room = db.query(Room).filter(Room.id == room_id).first()
        conflict = BookingService.check_room_conflict(db, room_id, booking_date, start_t, end_t)

        conflict_reason = None
        if conflict:
            conflict_reason = f"Room {original_room.room_number if original_room else room_id} is already reserved from {conflict.start_time.strftime('%H:%M')} to {conflict.end_time.strftime('%H:%M')}."

        # 1. Alternative slots in same room
        all_bookings_today = db.query(Booking).filter(
            Booking.room_id == room_id,
            Booking.booking_date == booking_date,
            Booking.status == BookingStatus.CONFIRMED
        ).order_by(Booking.start_time).all()

        possible_slots = ["09:00 - 10:30", "11:00 - 12:30", "13:00 - 14:30", "15:00 - 16:30", "17:00 - 18:30"]
        free_slots = []
        for slot in possible_slots:
            s_str, e_str = slot.split(" - ")
            s_val = parse_time_str(s_str)
            e_val = parse_time_str(e_str)
            overlap = any(b.start_time < e_val and b.end_time > s_val for b in all_bookings_today)
            if not overlap:
                free_slots.append(slot)

        # 2. Alternative rooms with adequate capacity and open status
        alt_rooms = db.query(Room).filter(
            Room.id != room_id,
            Room.capacity >= required_capacity,
            Room.availability_status == "available"
        ).all()

        recommended_alt_rooms: List[AlternativeRoomOption] = []
        for r in alt_rooms:
            room_conflict = BookingService.check_room_conflict(db, r.id, booking_date, start_t, end_t)
            if not room_conflict:
                bldg_name = r.building.building_name if r.building else f"Building {r.building_id}"
                recommended_alt_rooms.append(AlternativeRoomOption(
                    room_id=r.id,
                    room_number=r.room_number,
                    room_name=r.room_name,
                    building_name=bldg_name,
                    capacity=r.capacity,
                    available_slot=f"{start_t.strftime('%H:%M')} - {end_t.strftime('%H:%M')}",
                    reason=f"Optimal match in {bldg_name} with capacity for {r.capacity} attendees"
                ))
            if len(recommended_alt_rooms) >= 4:
                break

        return AlternativeBookingsResponse(
            original_room_id=room_id,
            original_date=booking_date,
            original_time_slot=f"{start_t.strftime('%H:%M')} - {end_t.strftime('%H:%M')}",
            conflict_detected=bool(conflict),
            conflict_reason=conflict_reason,
            alternative_rooms=recommended_alt_rooms,
            alternative_slots_in_same_room=free_slots[:3]
        )

booking_service = BookingService()
