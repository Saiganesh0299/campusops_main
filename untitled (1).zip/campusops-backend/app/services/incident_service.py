from datetime import datetime, timedelta, timezone
from typing import List, Optional
from collections import defaultdict
from sqlalchemy.orm import Session
from app.models.complaint import Complaint
from app.models.incident import Incident
from app.schemas.incident import CorrelatedGroup, IncidentCorrelateResponse
from app.utils.enums import PriorityLevel, IncidentStatus, ComplaintStatus

class IncidentService:
    @staticmethod
    def correlate_complaints(
        db: Session,
        building_id: Optional[int] = None,
        category: Optional[str] = None,
        timeframe_hours: int = 48
    ) -> IncidentCorrelateResponse:
        """
        Analyzes active complaints within the timeframe to identify clusters
        sharing common failure roots (e.g., building-wide electrical or Wi-Fi outages).
        """
        since_time = datetime.now(timezone.utc) - timedelta(hours=timeframe_hours)
        query = db.query(Complaint).filter(
            Complaint.created_at >= since_time,
            Complaint.status != ComplaintStatus.RESOLVED
        )

        if building_id:
            query = query.filter(Complaint.building_id == building_id)
        if category:
            query = query.filter(Complaint.category == category)

        complaints = query.all()
        total_analyzed = len(complaints)

        # Cluster by building and category
        clusters = defaultdict(list)
        for c in complaints:
            key = (c.building_id, c.category.value)
            clusters[key].append(c)

        recommended_groups: List[CorrelatedGroup] = []

        for (bldg_id, cat_val), group in clusters.items():
            # If 2 or more complaints exist in same building with same category within window
            if len(group) >= 2:
                complaint_ids = [c.id for c in group]
                bldg_name = group[0].building.building_name if group[0].building else f"Building {bldg_id}"
                locations = list(set([f"{bldg_name} - Room {c.room.room_number}" if c.room else bldg_name for c in group]))

                # Check highest priority among complaints
                has_critical = any(c.priority == PriorityLevel.CRITICAL for c in group)
                has_high = any(c.priority == PriorityLevel.HIGH for c in group)
                group_prio = PriorityLevel.CRITICAL if has_critical else (PriorityLevel.HIGH if has_high else PriorityLevel.MEDIUM)

                common_cause = f"Multiple synchronized {cat_val} reports detected across {len(locations)} zones in {bldg_name}."
                confidence = min(0.95, 0.60 + (len(group) * 0.10))

                recommended_groups.append(CorrelatedGroup(
                    group_title=f"Widespread {cat_val.replace('_', ' ').title()} Issue in {bldg_name}",
                    category=cat_val,
                    priority=group_prio,
                    common_cause_hypothesis=common_cause,
                    affected_locations=locations,
                    complaint_ids=complaint_ids,
                    confidence=round(confidence, 2)
                ))

        return IncidentCorrelateResponse(
            total_analyzed=total_analyzed,
            correlated_incidents_found=len(recommended_groups),
            recommended_groups=recommended_groups
        )

    @staticmethod
    def create_incident_from_correlation(
        db: Session,
        group: CorrelatedGroup
    ) -> Incident:
        count = db.query(Incident).count() + 1
        code = f"INC-{datetime.now().strftime('%y%m%d')}-{count:03d}"

        complaints = db.query(Complaint).filter(Complaint.id.in_(group.complaint_ids)).all()

        incident = Incident(
            incident_code=code,
            title=group.group_title,
            description=group.common_cause_hypothesis,
            category=group.category,
            priority=group.priority,
            status=IncidentStatus.INVESTIGATING,
            affected_locations=group.affected_locations,
            complaints=complaints
        )
        db.add(incident)
        db.commit()
        db.refresh(incident)
        return incident

incident_service = IncidentService()
