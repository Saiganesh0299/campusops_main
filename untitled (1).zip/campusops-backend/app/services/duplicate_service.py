import re
from typing import List, Optional
from sqlalchemy.orm import Session
from app.models.complaint import Complaint
from app.schemas.complaint import DuplicateComplaintCandidate
from app.utils.enums import ComplaintStatus

def calculate_word_similarity(text1: str, text2: str) -> float:
    """
    Computes Jaccard word-level similarity between two text snippets.
    """
    words1 = set(re.findall(r"\b\w{3,}\b", text1.lower()))
    words2 = set(re.findall(r"\b\w{3,}\b", text2.lower()))
    if not words1 or not words2:
        return 0.0
    intersection = words1.intersection(words2)
    union = words1.union(words2)
    return len(intersection) / len(union)

class DuplicateService:
    @staticmethod
    def find_potential_duplicates(
        db: Session,
        description: str,
        building_id: int,
        room_id: Optional[int] = None,
        asset_id: Optional[int] = None,
        category: Optional[str] = None,
        exclude_complaint_id: Optional[int] = None
    ) -> List[DuplicateComplaintCandidate]:
        """
        Scans active/unresolved complaints for matches across building, room, asset, category, and text similarity.
        """
        query = db.query(Complaint).filter(
            Complaint.status.in_([
                ComplaintStatus.SUBMITTED,
                ComplaintStatus.IN_REVIEW,
                ComplaintStatus.WORK_ORDER_CREATED,
                ComplaintStatus.AWAITING_CLARIFICATION
            ]),
            Complaint.building_id == building_id
        )

        if exclude_complaint_id:
            query = query.filter(Complaint.id != exclude_complaint_id)

        candidates: List[DuplicateComplaintCandidate] = []
        open_complaints = query.all()

        for c in open_complaints:
            score = 0.0
            reasons = []

            # Exact Asset match
            if asset_id and c.asset_id == asset_id:
                score += 0.50
                reasons.append("Same equipment/asset ID")

            # Same Room match
            if room_id and c.room_id == room_id:
                score += 0.35
                reasons.append(f"Same room (#{c.room_id})")

            # Same Category match
            if category and str(c.category) == str(category):
                score += 0.20
                reasons.append(f"Same category ({c.category.value})")

            # Textual description similarity
            text_sim = calculate_word_similarity(description, c.description)
            score += text_sim * 0.40

            if text_sim > 0.4:
                reasons.append(f"High text similarity ({int(text_sim * 100)}%)")

            # Normalize to max 1.0
            normalized_score = min(1.0, round(score, 2))

            if normalized_score >= 0.45:
                candidates.append(DuplicateComplaintCandidate(
                    complaint_id=c.id,
                    complaint_code=c.complaint_code,
                    description=c.description,
                    status=c.status,
                    similarity_score=normalized_score,
                    reason=", ".join(reasons) if reasons else "Similar active report in building"
                ))

        candidates.sort(key=lambda x: x.similarity_score, reverse=True)
        return candidates

duplicate_service = DuplicateService()
