from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.core.config import settings
from app.core.exceptions import CampusOpsException
from app.database.connection import engine
from app.database.base import Base
import app.models  # ensure models are registered

# Routers
from app.routers.auth import router as auth_router
from app.routers.users import router as users_router
from app.routers.purchases import router as purchases_router
from app.routers.departments import router as departments_router
from app.routers.buildings import router as buildings_router
from app.routers.rooms import router as rooms_router
from app.routers.staff import router as staff_router
from app.routers.complaints import router as complaints_router
from app.routers.incidents import router as incidents_router
from app.routers.work_orders import router as work_orders_router
from app.routers.bookings import router as bookings_router
from app.routers.inventory import router as inventory_router
from app.routers.notifications import router as notifications_router
from app.routers.dashboard import router as dashboard_router
from app.routers.ai import router as ai_router
from app.services.permission_service import permission_service
from app.database.session import SessionLocal

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Auto-initialize tables if running against SQLite in testing/development
    if "sqlite" in settings.resolved_database_url:
        Base.metadata.create_all(bind=engine)
    try:
        db = SessionLocal()
        permission_service.ensure_default_permissions(db)
        db.close()
    except Exception:
        pass
    yield

app = FastAPI(
    title="CampusOps – Intelligent Campus Operations Platform",
    description="Scalable REST API backend powered by FastAPI, MySQL Server 8.x, SQLAlchemy 2.0, and Gemini AI.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# CORS Configuration for React/Vite development and production
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------------------------------------------------
# GLOBAL EXCEPTION HANDLERS (Standard JSON responses)
# -------------------------------------------------------------

@app.exception_handler(CampusOpsException)
async def campusops_exception_handler(request: Request, exc: CampusOpsException):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "success": False,
            "message": exc.message,
            "errors": exc.errors
        }
    )

@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    error_list = []
    for err in exc.errors():
        field = " -> ".join([str(x) for x in err.get("loc", [])])
        msg = err.get("msg")
        error_list.append(f"{field}: {msg}")

    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={
            "success": False,
            "message": "Input validation error",
            "errors": error_list
        }
    )

@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "success": False,
            "message": exc.detail if isinstance(exc.detail, str) else "HTTP Exception",
            "errors": [str(exc.detail)] if not isinstance(exc.detail, str) else []
        }
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "success": False,
            "message": "An unexpected internal server error occurred",
            "errors": [str(exc)] if settings.DEBUG else []
        }
    )

# -------------------------------------------------------------
# ROUTER REGISTRATION
# -------------------------------------------------------------

api_prefix = settings.API_V1_PREFIX  # /api

app.include_router(auth_router, prefix=api_prefix)
app.include_router(users_router, prefix=api_prefix)
app.include_router(purchases_router, prefix=api_prefix)
app.include_router(departments_router, prefix=api_prefix)
app.include_router(buildings_router, prefix=api_prefix)
app.include_router(rooms_router, prefix=api_prefix)
app.include_router(staff_router, prefix=api_prefix)
app.include_router(complaints_router, prefix=api_prefix)
app.include_router(incidents_router, prefix=api_prefix)
app.include_router(work_orders_router, prefix=api_prefix)
app.include_router(bookings_router, prefix=api_prefix)
app.include_router(inventory_router, prefix=api_prefix)
app.include_router(notifications_router, prefix=api_prefix)
app.include_router(dashboard_router, prefix=api_prefix)
app.include_router(ai_router, prefix=api_prefix)

@app.get("/health", tags=["Health"])
def health_check():
    return {
        "status": "healthy",
        "service": settings.APP_NAME,
        "environment": settings.ENVIRONMENT
    }

@app.get("/", tags=["Root"])
def root():
    return {
        "name": settings.APP_NAME,
        "version": "1.0.0",
        "docs_url": "/docs",
        "api_v1": settings.API_V1_PREFIX
    }
