from datetime import datetime, timezone
from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, get_current_user
from app.core.exceptions import NotFoundException, ForbiddenException, ConflictException
from app.models.purchase import PurchaseRequest, PurchaseApproval
from app.models.work_order import WorkOrder
from app.models.user import User
from app.models.department import Department
from app.schemas.purchase import (
    PurchaseRequestCreate,
    PurchaseApprovalAction,
    PurchaseRequestResponse,
    PurchaseApprovalHistoryItem
)
from app.schemas.common import DataResponse
from app.services.permission_service import permission_service
from app.services.notification_service import notification_service
from app.utils.enums import UserRole, PurchaseStatus, AccessScope, NotificationType

router = APIRouter(prefix="/purchases", tags=["Purchasing & Procurement"])

def format_purchase_res(p: PurchaseRequest) -> PurchaseRequestResponse:
    approvals_list = [
        PurchaseApprovalHistoryItem(
            id=a.id,
            approver_id=a.approver_id,
            approver_name=a.approver.full_name if a.approver else "System",
            approver_role=a.approver.role.value if a.approver else "PROCUREMENT",
            action=a.action,
            comments=a.comments,
            created_at=a.created_at
        )
        for a in p.approvals
    ]
    return PurchaseRequestResponse(
        id=p.id,
        request_code=p.request_code,
        requester_id=p.requester_id,
        requester_name=p.requester.full_name if p.requester else "Unknown",
        requester_role=p.requester.role.value if p.requester else "STUDENT_FACULTY",
        department_id=p.department_id,
        department_name=p.department.name if p.department else None,
        work_order_id=p.work_order_id,
        work_order_code=p.work_order.work_order_code if p.work_order else None,
        item_name=p.item_name,
        category=p.category,
        quantity=p.quantity,
        estimated_unit_cost=p.estimated_unit_cost,
        total_estimated_cost=p.total_estimated_cost,
        justification=p.justification,
        status=p.status,
        created_at=p.created_at,
        updated_at=p.updated_at,
        approvals=approvals_list
    )

@router.get("", response_model=DataResponse[List[PurchaseRequestResponse]])
def get_purchase_requests(
    status_filter: Optional[str] = Query(None, alias="status"),
    department_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(PurchaseRequest)

    # Apply Scope Restrictions based on Role and Permissions
    if current_user.role == UserRole.SYSTEM_ADMIN or current_user.role == UserRole.PROCUREMENT:
        # Full campus visibility
        pass
    elif current_user.role == UserRole.FACILITIES_ADMIN:
        # Campus-wide facilities view
        pass
    elif current_user.role == UserRole.DEPT_MANAGER:
        # Restricted strictly to their own department
        if current_user.department_id:
            query = query.filter(PurchaseRequest.department_id == current_user.department_id)
        else:
            query = query.filter(PurchaseRequest.requester_id == current_user.id)
    elif current_user.role in [UserRole.TECHNICIAN, UserRole.STUDENT_FACULTY]:
        # Restricted strictly to their own submitted requests
        query = query.filter(PurchaseRequest.requester_id == current_user.id)

    if status_filter:
        query = query.filter(PurchaseRequest.status == status_filter)
    if department_id:
        query = query.filter(PurchaseRequest.department_id == department_id)

    requests = query.order_by(PurchaseRequest.created_at.desc()).all()
    results = [format_purchase_res(p) for p in requests]

    return DataResponse(
        success=True,
        message=f"Retrieved {len(results)} purchase requests",
        data=results
    )

@router.get("/{purchase_id}", response_model=DataResponse[PurchaseRequestResponse])
def get_purchase_request(
    purchase_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    purchase = db.query(PurchaseRequest).filter(PurchaseRequest.id == purchase_id).first()
    if not purchase:
        raise NotFoundException(f"Purchase request #{purchase_id} not found")

    # Scope check
    if current_user.role not in [UserRole.SYSTEM_ADMIN, UserRole.PROCUREMENT, UserRole.FACILITIES_ADMIN]:
        if current_user.role == UserRole.DEPT_MANAGER:
            if purchase.department_id != current_user.department_id and purchase.requester_id != current_user.id:
                raise ForbiddenException("You cannot view purchase requests outside your department")
        elif purchase.requester_id != current_user.id:
            raise ForbiddenException("You can only view your own purchase requests")

    return DataResponse(
        success=True,
        message="Purchase request retrieved",
        data=format_purchase_res(purchase)
    )

@router.post("", response_model=DataResponse[PurchaseRequestResponse], status_code=status.HTTP_201_CREATED)
def create_purchase_request(
    data: PurchaseRequestCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Verify permission to request purchases
    authorized, scope = permission_service.user_has_permission(
        db=db,
        user=current_user,
        module="PURCHASES",
        action="REQUEST"
    )
    if not authorized:
        raise ForbiddenException("Your role does not have permission to request purchases")

    # Associate department
    dept_id = data.department_id or current_user.department_id

    count = db.query(PurchaseRequest).count() + 1
    code = f"PR-{datetime.now().strftime('%y%m%d')}-{count:04d}"
    total_cost = round(data.quantity * data.estimated_unit_cost, 2)

    purchase = PurchaseRequest(
        request_code=code,
        requester_id=current_user.id,
        department_id=dept_id,
        work_order_id=data.work_order_id,
        item_name=data.item_name,
        category=data.category,
        quantity=data.quantity,
        estimated_unit_cost=data.estimated_unit_cost,
        total_estimated_cost=total_cost,
        justification=data.justification,
        status=PurchaseStatus.PENDING_REVIEW
    )
    db.add(purchase)
    db.commit()
    db.refresh(purchase)

    notification_service.log_activity(
        db=db,
        action="CREATE_PURCHASE_REQUEST",
        entity_type="PurchaseRequest",
        entity_id=str(purchase.id),
        description=f"Submitted purchase request #{purchase.request_code} for {data.quantity}x {data.item_name} (${total_cost})",
        user_id=current_user.id
    )

    return DataResponse(
        success=True,
        message=f"Purchase request #{purchase.request_code} submitted for review",
        data=format_purchase_res(purchase)
    )

@router.patch("/{purchase_id}/approve", response_model=DataResponse[PurchaseRequestResponse])
def approve_purchase_request(
    purchase_id: int,
    action_data: PurchaseApprovalAction,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    purchase = db.query(PurchaseRequest).filter(PurchaseRequest.id == purchase_id).first()
    if not purchase:
        raise NotFoundException(f"Purchase request #{purchase_id} not found")

    # Anti-self-approval rule
    if purchase.requester_id == current_user.id and current_user.role != UserRole.SYSTEM_ADMIN:
        raise ForbiddenException("Users cannot approve their own purchase requests")

    # Authorization verification: Procurement by default, or separately authorized managers/facilities admin
    can_approve, scope = permission_service.user_has_permission(
        db=db,
        user=current_user,
        module="PURCHASES",
        action="APPROVE"
    )

    if not can_approve:
        raise ForbiddenException(
            f"You are not authorized to approve purchase requests. Role '{current_user.role.value}' requires explicit purchase approval delegation from System Admin."
        )

    # Department scope check for Department Managers
    if current_user.role == UserRole.DEPT_MANAGER:
        if purchase.department_id != current_user.department_id:
            raise ForbiddenException("Department Managers can only approve requests within their own department")

    purchase.status = PurchaseStatus.APPROVED

    approval = PurchaseApproval(
        purchase_request_id=purchase.id,
        approver_id=current_user.id,
        action="APPROVED",
        comments=action_data.comments or "Approved by authorized officer"
    )
    db.add(approval)
    db.commit()
    db.refresh(purchase)

    # Notify requester
    notification_service.notify_user(
        db=db,
        user_id=purchase.requester_id,
        title=f"Purchase Request #{purchase.request_code} Approved",
        message=f"Your purchase request for '{purchase.item_name}' was approved by {current_user.full_name}.",
        notification_type=NotificationType.PURCHASE
    )

    notification_service.log_activity(
        db=db,
        action="APPROVE_PURCHASE",
        entity_type="PurchaseRequest",
        entity_id=str(purchase.id),
        description=f"Approved purchase request #{purchase.request_code} (${purchase.total_estimated_cost})",
        user_id=current_user.id
    )

    return DataResponse(
        success=True,
        message=f"Purchase request #{purchase.request_code} approved successfully",
        data=format_purchase_res(purchase)
    )

@router.patch("/{purchase_id}/reject", response_model=DataResponse[PurchaseRequestResponse])
def reject_purchase_request(
    purchase_id: int,
    action_data: PurchaseApprovalAction,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    purchase = db.query(PurchaseRequest).filter(PurchaseRequest.id == purchase_id).first()
    if not purchase:
        raise NotFoundException(f"Purchase request #{purchase_id} not found")

    can_approve, scope = permission_service.user_has_permission(
        db=db,
        user=current_user,
        module="PURCHASES",
        action="APPROVE"
    )
    if not can_approve:
        raise ForbiddenException("You are not authorized to reject purchase requests")

    purchase.status = PurchaseStatus.REJECTED

    approval = PurchaseApproval(
        purchase_request_id=purchase.id,
        approver_id=current_user.id,
        action="REJECTED",
        comments=action_data.comments or "Rejected by reviewing authority"
    )
    db.add(approval)
    db.commit()
    db.refresh(purchase)

    notification_service.notify_user(
        db=db,
        user_id=purchase.requester_id,
        title=f"Purchase Request #{purchase.request_code} Rejected",
        message=f"Your purchase request for '{purchase.item_name}' was rejected. Reason: {action_data.comments or 'None'}",
        notification_type=NotificationType.PURCHASE
    )

    notification_service.log_activity(
        db=db,
        action="REJECT_PURCHASE",
        entity_type="PurchaseRequest",
        entity_id=str(purchase.id),
        description=f"Rejected purchase request #{purchase.request_code}. Comments: {action_data.comments or 'None'}",
        user_id=current_user.id
    )

    return DataResponse(
        success=True,
        message=f"Purchase request #{purchase.request_code} rejected",
        data=format_purchase_res(purchase)
    )
