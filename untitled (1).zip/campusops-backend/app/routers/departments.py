from typing import List, Optional
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, get_current_user, require_role
from app.core.exceptions import NotFoundException, ConflictException, ForbiddenException
from app.models.department import Department
from app.models.complaint import Complaint
from app.models.user import User
from app.schemas.department import DepartmentCreate, DepartmentUpdate, DepartmentResponse
from app.schemas.complaint import ComplaintResponse
from app.schemas.common import DataResponse
from app.utils.enums import UserRole

router = APIRouter(prefix="/departments", tags=["Departments"])

@router.get("", response_model=DataResponse[List[DepartmentResponse]])
def get_departments(db: Session = Depends(get_db)):
    depts = db.query(Department).order_by(Department.name.asc()).all()
    results = []
    for d in depts:
        res = DepartmentResponse.model_validate(d)
        res.users_count = len(d.users)
        results.append(res)
    return DataResponse(
        success=True,
        message=f"Retrieved {len(results)} departments",
        data=results
    )

@router.get("/{department_id}", response_model=DataResponse[DepartmentResponse])
def get_department(department_id: int, db: Session = Depends(get_db)):
    dept = db.query(Department).filter(Department.id == department_id).first()
    if not dept:
        raise NotFoundException(f"Department #{department_id} not found")
    res = DepartmentResponse.model_validate(dept)
    res.users_count = len(dept.users)
    return DataResponse(
        success=True,
        message="Department retrieved",
        data=res
    )

@router.get("/{department_id}/complaints", response_model=DataResponse[List[ComplaintResponse]])
def get_department_complaints(
    department_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    dept = db.query(Department).filter(Department.id == department_id).first()
    if not dept:
        raise NotFoundException(f"Department #{department_id} not found")

    # Scope verification: Must be System Admin, Facilities Admin, or Manager of THIS department
    if current_user.role not in [UserRole.SYSTEM_ADMIN, UserRole.FACILITIES_ADMIN]:
        if current_user.role != UserRole.DEPT_MANAGER or current_user.department_id != department_id:
            raise ForbiddenException("Access denied: You are only authorized to view complaints for your assigned department")

    dept_user_ids = [u.id for u in dept.users]
    complaints = db.query(Complaint).filter(Complaint.submitted_by.in_(dept_user_ids)).all()

    from app.routers.complaints import format_complaint_res
    results = [format_complaint_res(c) for c in complaints]

    return DataResponse(
        success=True,
        message=f"Retrieved {len(results)} department-level complaints for '{dept.name}'",
        data=results
    )

@router.post("", response_model=DataResponse[DepartmentResponse], status_code=status.HTTP_201_CREATED)
def create_department(
    data: DepartmentCreate,
    db: Session = Depends(get_db),
    admin: User = Depends(require_role(UserRole.SYSTEM_ADMIN))
):
    existing = db.query(Department).filter(Department.code == data.code).first()
    if existing:
        raise ConflictException(f"Department code '{data.code}' already exists")

    dept = Department(
        code=data.code.upper(),
        name=data.name,
        description=data.description
    )
    db.add(dept)
    db.commit()
    db.refresh(dept)

    return DataResponse(
        success=True,
        message=f"Department '{dept.name}' created",
        data=DepartmentResponse.model_validate(dept)
    )
