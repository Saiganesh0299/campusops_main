from datetime import datetime, timezone
from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, get_current_user, require_role
from app.core.exceptions import NotFoundException, ValidationException, ConflictException
from app.models.work_order import WorkOrder
from app.models.complaint import Complaint
from app.models.staff import Staff
from app.models.activity_log import ActivityLog
from app.models.reservation import InventoryReservation
from app.models.user import User
from app.schemas.work_order import (
    WorkOrderCreate,
    WorkOrderUpdate,
    WorkOrderStatusUpdate,
    WorkOrderAssignRequest,
    WorkOrderReassignRequest,
    WorkOrderResponse,
    WorkOrderHistoryItem
)
from app.schemas.staff import StaffRecommendationResponse
from app.schemas.inventory import PartReservationRequest, ReservationResponse
from app.schemas.common import DataResponse
from app.services.assignment_service import assignment_service
from app.services.inventory_service import inventory_service
from app.services.notification_service import notification_service
from app.utils.enums import UserRole, WorkOrderStatus, NotificationType

router = APIRouter(prefix="/work-orders", tags=["Work Orders"])

VALID_TRANSITIONS = {
    WorkOrderStatus.NEW: [WorkOrderStatus.AWAITING_CLARIFICATION, WorkOrderStatus.CATEGORISED, WorkOrderStatus.ASSIGNED],
    WorkOrderStatus.AWAITING_CLARIFICATION: [WorkOrderStatus.CATEGORISED, WorkOrderStatus.CLOSED],
    WorkOrderStatus.CATEGORISED: [WorkOrderStatus.ASSIGNED, WorkOrderStatus.IN_PROGRESS, WorkOrderStatus.CLOSED],
    WorkOrderStatus.ASSIGNED: [WorkOrderStatus.IN_PROGRESS, WorkOrderStatus.WAITING_FOR_PARTS, WorkOrderStatus.CLOSED],
    WorkOrderStatus.IN_PROGRESS: [WorkOrderStatus.WAITING_FOR_PARTS, WorkOrderStatus.RESOLVED, WorkOrderStatus.ASSIGNED],
    WorkOrderStatus.WAITING_FOR_PARTS: [WorkOrderStatus.IN_PROGRESS, WorkOrderStatus.ASSIGNED, WorkOrderStatus.RESOLVED],
    WorkOrderStatus.RESOLVED: [WorkOrderStatus.CLOSED, WorkOrderStatus.IN_PROGRESS],
    WorkOrderStatus.CLOSED: []
}

def format_work_order_res(wo: WorkOrder) -> WorkOrderResponse:
    res = WorkOrderResponse.model_validate(wo)
    if wo.complaint:
        res.complaint_code = wo.complaint.complaint_code
        res.building_name = wo.complaint.building.building_name if wo.complaint.building else None
        res.room_number = wo.complaint.room.room_number if wo.complaint.room else None
    if wo.assigned_staff:
        res.assigned_staff_name = wo.assigned_staff.user.full_name if wo.assigned_staff.user else wo.assigned_staff.employee_code
    res.reserved_parts_count = len(wo.reservations)
    return res

@router.post("", response_model=DataResponse[WorkOrderResponse], status_code=status.HTTP_201_CREATED)
def create_work_order(
    data: WorkOrderCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER, UserRole.STAFF))
):
    complaint = db.query(Complaint).filter(Complaint.id == data.complaint_id).first()
    if not complaint:
        raise NotFoundException(f"Complaint #{data.complaint_id} not found")

    count = db.query(WorkOrder).count() + 1
    code = f"WO-{datetime.now().strftime('%y%m%d')}-{count:04d}"

    wo = WorkOrder(
        work_order_code=code,
        complaint_id=data.complaint_id,
        assigned_staff_id=data.assigned_staff_id,
        description=data.description,
        priority=data.priority,
        status=data.status,
        estimated_completion=data.estimated_completion
    )
    db.add(wo)
    db.commit()
    db.refresh(wo)

    notification_service.log_activity(
        db=db,
        action="CREATE_WORK_ORDER",
        entity_type="WorkOrder",
        entity_id=str(wo.id),
        description=f"Work Order #{wo.work_order_code} created for Complaint #{complaint.complaint_code}",
        user_id=current_user.id
    )

    return DataResponse(
        success=True,
        message=f"Work order #{wo.work_order_code} created",
        data=format_work_order_res(wo)
    )

@router.get("", response_model=DataResponse[List[WorkOrderResponse]])
def get_work_orders(
    status_filter: Optional[str] = Query(None, alias="status"),
    priority: Optional[str] = None,
    assigned_staff_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user)
):
    query = db.query(WorkOrder)

    if current_user:
        if current_user.role == UserRole.TECHNICIAN:
            # Technicians view only assigned jobs
            if current_user.staff_profile:
                query = query.filter(WorkOrder.assigned_staff_id == current_user.staff_profile.id)
            else:
                query = query.filter(WorkOrder.id == -1)
        elif current_user.role == UserRole.STUDENT_FACULTY:
            # Students view work orders related to their own submitted complaints
            query = query.join(Complaint).filter(Complaint.submitted_by == current_user.id)
        elif current_user.role == UserRole.DEPT_MANAGER:
            # Department managers view work orders from their department
            if current_user.department_id:
                query = query.join(Complaint).join(User, Complaint.submitted_by == User.id).filter(
                    User.department_id == current_user.department_id
                )

    if status_filter:
        query = query.filter(WorkOrder.status == status_filter)
    if priority:
        query = query.filter(WorkOrder.priority == priority)
    if assigned_staff_id:
        query = query.filter(WorkOrder.assigned_staff_id == assigned_staff_id)

    work_orders = query.order_by(WorkOrder.created_at.desc()).all()
    results = [format_work_order_res(wo) for wo in work_orders]

    return DataResponse(
        success=True,
        message=f"Retrieved {len(results)} work orders",
        data=results
    )

@router.get("/{work_order_id}", response_model=DataResponse[WorkOrderResponse])
def get_work_order(
    work_order_id: int,
    db: Session = Depends(get_db),
    current_user: Optional[User] = Depends(get_current_user)
):
    wo = db.query(WorkOrder).filter(WorkOrder.id == work_order_id).first()
    if not wo:
        raise NotFoundException(f"Work order #{work_order_id} not found")

    if current_user:
        if current_user.role == UserRole.TECHNICIAN:
            if not current_user.staff_profile or wo.assigned_staff_id != current_user.staff_profile.id:
                raise ForbiddenException("Technicians can only access work orders assigned to them")
        elif current_user.role == UserRole.STUDENT_FACULTY:
            if not wo.complaint or wo.complaint.submitted_by != current_user.id:
                raise ForbiddenException("Access denied to work order")

    return DataResponse(
        success=True,
        message="Work order retrieved",
        data=format_work_order_res(wo)
    )

@router.put("/{work_order_id}", response_model=DataResponse[WorkOrderResponse])
def update_work_order(
    work_order_id: int,
    data: WorkOrderUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER, UserRole.STAFF))
):
    wo = db.query(WorkOrder).filter(WorkOrder.id == work_order_id).first()
    if not wo:
        raise NotFoundException(f"Work order #{work_order_id} not found")

    if data.description is not None:
        wo.description = data.description
    if data.priority is not None:
        wo.priority = data.priority
    if data.estimated_completion is not None:
        wo.estimated_completion = data.estimated_completion
    if data.assigned_staff_id is not None:
        wo.assigned_staff_id = data.assigned_staff_id

    db.commit()
    db.refresh(wo)

    return DataResponse(
        success=True,
        message="Work order updated",
        data=format_work_order_res(wo)
    )

@router.patch("/{work_order_id}/status", response_model=DataResponse[WorkOrderResponse])
def update_work_order_status(
    work_order_id: int,
    data: WorkOrderStatusUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.SYSTEM_ADMIN, UserRole.FACILITIES_ADMIN, UserRole.DEPT_MANAGER, UserRole.TECHNICIAN))
):
    wo = db.query(WorkOrder).filter(WorkOrder.id == work_order_id).first()
    if not wo:
        raise NotFoundException(f"Work order #{work_order_id} not found")

    # If technician, must be assigned to this work order
    if current_user.role == UserRole.TECHNICIAN:
        if not current_user.staff_profile or wo.assigned_staff_id != current_user.staff_profile.id:
            raise ForbiddenException("Technicians can only update the status of work orders assigned to them")

    # If department manager, must belong to their department
    if current_user.role == UserRole.DEPT_MANAGER and current_user.department_id:
        if wo.complaint and wo.complaint.submitter and wo.complaint.submitter.department_id != current_user.department_id:
            raise ForbiddenException("Department Managers can only manage work orders within their department")

    # Validate transition
    allowed = VALID_TRANSITIONS.get(wo.status, [])
    if current_user.role not in [UserRole.SYSTEM_ADMIN, UserRole.FACILITIES_ADMIN] and data.status not in allowed:
        raise ValidationException(
            f"Invalid status transition from {wo.status.value} to {data.status.value}. Allowed next states: {[s.value for s in allowed]}"
        )

    previous_status = wo.status
    wo.status = data.status

    if data.status == WorkOrderStatus.RESOLVED:
        wo.actual_completion = data.actual_completion or datetime.now(timezone.utc)
        inventory_service.consume_reservations_for_work_order(db, wo.id)
        if wo.complaint:
            wo.complaint.status = "RESOLVED"
            if wo.complaint.room:
                wo.complaint.room.availability_status = "available"

    db.commit()
    db.refresh(wo)

    # Activity log
    notification_service.log_activity(
        db=db,
        action="STATUS_CHANGE",
        entity_type="WorkOrder",
        entity_id=str(wo.id),
        description=f"Status transitioned from {previous_status.value} to {data.status.value}. Notes: {data.resolution_notes or 'None'}",
        user_id=current_user.id
    )

    return DataResponse(
        success=True,
        message=f"Work order status updated to {wo.status.value}",
        data=format_work_order_res(wo)
    )

@router.get("/{work_order_id}/history", response_model=DataResponse[List[WorkOrderHistoryItem]])
def get_work_order_history(work_order_id: int, db: Session = Depends(get_db)):
    wo = db.query(WorkOrder).filter(WorkOrder.id == work_order_id).first()
    if not wo:
        raise NotFoundException(f"Work order #{work_order_id} not found")

    logs = db.query(ActivityLog).filter(
        ActivityLog.entity_type == "WorkOrder",
        ActivityLog.entity_id == str(work_order_id)
    ).order_by(ActivityLog.created_at.desc()).all()

    items = [
        WorkOrderHistoryItem(
            id=log.id,
            action=log.action,
            description=log.description,
            user_name=log.user.full_name if log.user else "System",
            created_at=log.created_at
        )
        for log in logs
    ]

    return DataResponse(
        success=True,
        message=f"Work order #{wo.work_order_code} audit history retrieved",
        data=items
    )

@router.post("/{work_order_id}/recommend-staff", response_model=DataResponse[List[StaffRecommendationResponse]])
def recommend_staff(
    work_order_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.SYSTEM_ADMIN, UserRole.FACILITIES_ADMIN, UserRole.DEPT_MANAGER))
):
    wo = db.query(WorkOrder).filter(WorkOrder.id == work_order_id).first()
    if not wo:
        raise NotFoundException(f"Work order #{work_order_id} not found")

    recs = assignment_service.recommend_technicians(db, wo)
    return DataResponse(
        success=True,
        message=f"Found {len(recs)} ranked technician recommendations",
        data=recs
    )

@router.post("/{work_order_id}/assign", response_model=DataResponse[WorkOrderResponse])
def assign_staff(
    work_order_id: int,
    payload: WorkOrderAssignRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.SYSTEM_ADMIN, UserRole.FACILITIES_ADMIN, UserRole.DEPT_MANAGER))
):
    wo = db.query(WorkOrder).filter(WorkOrder.id == work_order_id).first()
    if not wo:
        raise NotFoundException(f"Work order #{work_order_id} not found")

    # If department manager, check department ownership
    if current_user.role == UserRole.DEPT_MANAGER and current_user.department_id:
        if wo.complaint and wo.complaint.submitter and wo.complaint.submitter.department_id != current_user.department_id:
            raise ForbiddenException("Department Managers can only assign work orders within their department")

    staff = db.query(Staff).filter(Staff.id == payload.staff_id).first()
    if not staff:
        raise NotFoundException(f"Staff member #{payload.staff_id} not found")

    if not staff.is_available:
        raise ConflictException(f"Technician {staff.user.full_name if staff.user else staff.employee_code} is currently marked unavailable")

    wo.assigned_staff_id = staff.id
    wo.status = WorkOrderStatus.ASSIGNED
    staff.current_workload += 1

    db.commit()
    db.refresh(wo)

    notification_service.notify_user(
        db=db,
        user_id=staff.user_id,
        title=f"New Assignment: Work Order #{wo.work_order_code}",
        message=f"You have been assigned to: {wo.description[:100]}",
        notification_type=NotificationType.WORK_ORDER
    )

    notification_service.log_activity(
        db=db,
        action="ASSIGN_STAFF",
        entity_type="WorkOrder",
        entity_id=str(wo.id),
        description=f"Assigned to {staff.user.full_name if staff.user else staff.employee_code}",
        user_id=current_user.id
    )

    return DataResponse(
        success=True,
        message=f"Work order assigned to technician successfully",
        data=format_work_order_res(wo)
    )

@router.post("/{work_order_id}/reassign", response_model=DataResponse[WorkOrderResponse])
def reassign_staff(
    work_order_id: int,
    payload: WorkOrderReassignRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.SYSTEM_ADMIN, UserRole.FACILITIES_ADMIN, UserRole.DEPT_MANAGER))
):
    wo = db.query(WorkOrder).filter(WorkOrder.id == work_order_id).first()
    if not wo:
        raise NotFoundException(f"Work order #{work_order_id} not found")

    if current_user.role == UserRole.DEPT_MANAGER and current_user.department_id:
        if wo.complaint and wo.complaint.submitter and wo.complaint.submitter.department_id != current_user.department_id:
            raise ForbiddenException("Department Managers can only reassign work orders within their department")

    new_staff = db.query(Staff).filter(Staff.id == payload.new_staff_id).first()
    if not new_staff:
        raise NotFoundException(f"Target staff member #{payload.new_staff_id} not found")

    old_staff = wo.assigned_staff
    if old_staff:
        old_staff.current_workload = max(0, old_staff.current_workload - 1)

    wo.assigned_staff_id = new_staff.id
    new_staff.current_workload += 1
    db.commit()
    db.refresh(wo)

    notification_service.log_activity(
        db=db,
        action="REASSIGN_STAFF",
        entity_type="WorkOrder",
        entity_id=str(wo.id),
        description=f"Reassigned to {new_staff.user.full_name if new_staff.user else new_staff.employee_code}. Reason: {payload.reassignment_reason}",
        user_id=current_user.id
    )

    return DataResponse(
        success=True,
        message="Work order successfully reassigned",
        data=format_work_order_res(wo)
    )

@router.post("/{work_order_id}/reserve-parts", response_model=DataResponse[ReservationResponse], status_code=status.HTTP_201_CREATED)
def reserve_parts(
    work_order_id: int,
    payload: PartReservationRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER, UserRole.STAFF))
):
    reservation = inventory_service.reserve_parts_for_work_order(
        db=db,
        work_order_id=work_order_id,
        inventory_id=payload.inventory_id,
        quantity=payload.quantity
    )

    res = ReservationResponse(
        id=reservation.id,
        inventory_id=reservation.inventory_id,
        item_code=reservation.inventory_item.item_code,
        item_name=reservation.inventory_item.item_name,
        work_order_id=reservation.work_order_id,
        quantity=reservation.quantity,
        status=reservation.status,
        reserved_at=reservation.reserved_at,
        released_at=reservation.released_at
    )

    return DataResponse(
        success=True,
        message="Parts successfully reserved for work order",
        data=res
    )

@router.get("/{work_order_id}/reservations", response_model=DataResponse[List[ReservationResponse]])
def get_work_order_reservations(work_order_id: int, db: Session = Depends(get_db)):
    wo = db.query(WorkOrder).filter(WorkOrder.id == work_order_id).first()
    if not wo:
        raise NotFoundException(f"Work order #{work_order_id} not found")

    res_list = []
    for r in wo.reservations:
        res_list.append(ReservationResponse(
            id=r.id,
            inventory_id=r.inventory_id,
            item_code=r.inventory_item.item_code,
            item_name=r.inventory_item.item_name,
            work_order_id=r.work_order_id,
            quantity=r.quantity,
            status=r.status,
            reserved_at=r.reserved_at,
            released_at=r.released_at
        ))

    return DataResponse(
        success=True,
        message="Active reservations retrieved",
        data=res_list
    )
