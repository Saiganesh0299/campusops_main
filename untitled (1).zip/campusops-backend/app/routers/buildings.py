from typing import List, Optional
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, require_role
from app.core.exceptions import NotFoundException, ConflictException
from app.models.building import Building
from app.models.room import Room
from app.models.user import User
from app.schemas.building import BuildingCreate, BuildingUpdate, BuildingResponse
from app.schemas.room import RoomResponse
from app.schemas.common import DataResponse
from app.utils.enums import UserRole

router = APIRouter(prefix="/buildings", tags=["Buildings"])

@router.get("", response_model=DataResponse[List[BuildingResponse]])
def get_buildings(db: Session = Depends(get_db)):
    buildings = db.query(Building).all()
    results = []
    for b in buildings:
        res = BuildingResponse.model_validate(b)
        res.rooms_count = len(b.rooms)
        results.append(res)
    return DataResponse(
        success=True,
        message="Buildings fetched successfully",
        data=results
    )

@router.get("/{building_id}", response_model=DataResponse[BuildingResponse])
def get_building(building_id: int, db: Session = Depends(get_db)):
    building = db.query(Building).filter(Building.id == building_id).first()
    if not building:
        raise NotFoundException(f"Building #{building_id} not found")
    res = BuildingResponse.model_validate(building)
    res.rooms_count = len(building.rooms)
    return DataResponse(
        success=True,
        message="Building details fetched",
        data=res
    )

@router.get("/{building_id}/rooms", response_model=DataResponse[List[RoomResponse]])
def get_building_rooms(building_id: int, db: Session = Depends(get_db)):
    building = db.query(Building).filter(Building.id == building_id).first()
    if not building:
        raise NotFoundException(f"Building #{building_id} not found")
    rooms = db.query(Room).filter(Room.building_id == building_id).all()
    results = []
    for r in rooms:
        rm = RoomResponse.model_validate(r)
        rm.building_name = building.building_name
        results.append(rm)
    return DataResponse(
        success=True,
        message=f"Rooms for building '{building.building_name}' fetched",
        data=results
    )

@router.post("", response_model=DataResponse[BuildingResponse], status_code=status.HTTP_201_CREATED)
def create_building(
    data: BuildingCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER))
):
    existing = db.query(Building).filter(Building.building_code == data.building_code).first()
    if existing:
        raise ConflictException(f"Building with code '{data.building_code}' already exists")

    building = Building(
        building_code=data.building_code,
        building_name=data.building_name,
        description=data.description,
        total_floors=data.total_floors
    )
    db.add(building)
    db.commit()
    db.refresh(building)
    return DataResponse(
        success=True,
        message="Building created successfully",
        data=BuildingResponse.model_validate(building)
    )

@router.put("/{building_id}", response_model=DataResponse[BuildingResponse])
def update_building(
    building_id: int,
    data: BuildingUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER))
):
    building = db.query(Building).filter(Building.id == building_id).first()
    if not building:
        raise NotFoundException(f"Building #{building_id} not found")

    if data.building_code and data.building_code != building.building_code:
        conflict = db.query(Building).filter(Building.building_code == data.building_code).first()
        if conflict:
            raise ConflictException(f"Building code '{data.building_code}' already in use")
        building.building_code = data.building_code

    if data.building_name is not None:
        building.building_name = data.building_name
    if data.description is not None:
        building.description = data.description
    if data.total_floors is not None:
        building.total_floors = data.total_floors

    db.commit()
    db.refresh(building)
    res = BuildingResponse.model_validate(building)
    res.rooms_count = len(building.rooms)
    return DataResponse(
        success=True,
        message="Building updated successfully",
        data=res
    )
