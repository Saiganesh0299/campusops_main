from typing import List, Optional
from datetime import date
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, require_role
from app.core.exceptions import NotFoundException, ConflictException
from app.models.room import Room
from app.models.building import Building
from app.models.booking import Booking
from app.models.user import User
from app.schemas.room import RoomCreate, RoomUpdate, RoomResponse, RoomAvailabilityResponse
from app.schemas.common import DataResponse
from app.utils.enums import UserRole, BookingStatus

router = APIRouter(prefix="/rooms", tags=["Rooms"])

@router.get("", response_model=DataResponse[List[RoomResponse]])
def get_rooms(
    building_id: Optional[int] = None,
    floor: Optional[int] = None,
    room_type: Optional[str] = None,
    status_filter: Optional[str] = Query(None, alias="status"),
    db: Session = Depends(get_db)
):
    query = db.query(Room)
    if building_id:
        query = query.filter(Room.building_id == building_id)
    if floor is not None:
        query = query.filter(Room.floor_number == floor)
    if room_type:
        query = query.filter(Room.room_type.ilike(f"%{room_type}%"))
    if status_filter:
        query = query.filter(Room.availability_status == status_filter)

    rooms = query.all()
    results = []
    for r in rooms:
        res = RoomResponse.model_validate(r)
        res.building_name = r.building.building_name if r.building else None
        results.append(res)

    return DataResponse(
        success=True,
        message="Rooms retrieved successfully",
        data=results
    )

@router.get("/{room_id}", response_model=DataResponse[RoomResponse])
def get_room(room_id: int, db: Session = Depends(get_db)):
    room = db.query(Room).filter(Room.id == room_id).first()
    if not room:
        raise NotFoundException(f"Room #{room_id} not found")
    res = RoomResponse.model_validate(room)
    res.building_name = room.building.building_name if room.building else None
    return DataResponse(
        success=True,
        message="Room details retrieved",
        data=res
    )

@router.get("/{room_id}/availability", response_model=DataResponse[RoomAvailabilityResponse])
def get_room_availability(
    room_id: int,
    check_date: Optional[date] = None,
    db: Session = Depends(get_db)
):
    room = db.query(Room).filter(Room.id == room_id).first()
    if not room:
        raise NotFoundException(f"Room #{room_id} not found")

    target_date = check_date or date.today()
    bookings_count = db.query(Booking).filter(
        Booking.room_id == room_id,
        Booking.booking_date == target_date,
        Booking.status == BookingStatus.CONFIRMED
    ).count()

    is_avail = room.availability_status == "available"
    reason = None
    if not is_avail:
        reason = f"Room is currently designated as '{room.availability_status}' (e.g. under maintenance)."

    return DataResponse(
        success=True,
        message="Room availability evaluated",
        data=RoomAvailabilityResponse(
            room_id=room.id,
            room_number=room.room_number,
            room_name=room.room_name,
            is_available=is_avail,
            status=room.availability_status,
            existing_bookings_count=bookings_count,
            reason=reason
        )
    )

@router.post("", response_model=DataResponse[RoomResponse], status_code=status.HTTP_201_CREATED)
def create_room(
    data: RoomCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER))
):
    bldg = db.query(Building).filter(Building.id == data.building_id).first()
    if not bldg:
        raise NotFoundException(f"Building #{data.building_id} does not exist")

    # Check unique room_number within building
    existing = db.query(Room).filter(
        Room.building_id == data.building_id,
        Room.room_number == data.room_number
    ).first()
    if existing:
        raise ConflictException(f"Room number '{data.room_number}' already exists in {bldg.building_name}")

    room = Room(
        room_number=data.room_number,
        building_id=data.building_id,
        floor_number=data.floor_number,
        room_name=data.room_name,
        room_type=data.room_type,
        capacity=data.capacity,
        availability_status=data.availability_status
    )
    db.add(room)
    db.commit()
    db.refresh(room)

    res = RoomResponse.model_validate(room)
    res.building_name = bldg.building_name
    return DataResponse(
        success=True,
        message="Room registered successfully",
        data=res
    )

@router.put("/{room_id}", response_model=DataResponse[RoomResponse])
def update_room(
    room_id: int,
    data: RoomUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER))
):
    room = db.query(Room).filter(Room.id == room_id).first()
    if not room:
        raise NotFoundException(f"Room #{room_id} not found")

    if data.room_number is not None:
        room.room_number = data.room_number
    if data.room_name is not None:
        room.room_name = data.room_name
    if data.room_type is not None:
        room.room_type = data.room_type
    if data.capacity is not None:
        room.capacity = data.capacity
    if data.availability_status is not None:
        room.availability_status = data.availability_status

    db.commit()
    db.refresh(room)

    res = RoomResponse.model_validate(room)
    res.building_name = room.building.building_name if room.building else None
    return DataResponse(
        success=True,
        message="Room updated successfully",
        data=res
    )
