from typing import List, Optional
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, get_current_user
from app.core.exceptions import NotFoundException, ForbiddenException
from app.models.notification import Notification
from app.models.activity_log import ActivityLog
from app.models.user import User
from app.schemas.notification import NotificationResponse, ActivityLogResponse
from app.schemas.common import DataResponse
from app.utils.enums import UserRole

router = APIRouter(tags=["Notifications & Audit"])

@router.get("/notifications", response_model=DataResponse[List[NotificationResponse]])
def get_user_notifications(
    unread_only: bool = False,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(Notification).filter(Notification.user_id == current_user.id)
    if unread_only:
        query = query.filter(Notification.is_read == False)

    notifs = query.order_by(Notification.created_at.desc()).all()
    results = [NotificationResponse.model_validate(n) for n in notifs]
    return DataResponse(
        success=True,
        message=f"Retrieved {len(results)} notifications",
        data=results
    )

@router.patch("/notifications/{notification_id}/read", response_model=DataResponse[NotificationResponse])
def mark_notification_as_read(
    notification_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    notif = db.query(Notification).filter(Notification.id == notification_id).first()
    if not notif:
        raise NotFoundException(f"Notification #{notification_id} not found")

    if notif.user_id != current_user.id:
        raise ForbiddenException("You cannot mark another user's notification as read")

    notif.is_read = True
    db.commit()
    db.refresh(notif)

    return DataResponse(
        success=True,
        message="Notification marked as read",
        data=NotificationResponse.model_validate(notif)
    )

@router.get("/activity-logs", response_model=DataResponse[List[ActivityLogResponse]])
def get_activity_logs(
    entity_type: Optional[str] = None,
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(ActivityLog)
    if entity_type:
        query = query.filter(ActivityLog.entity_type == entity_type)

    # Regular students only see logs related to their own actions
    if current_user.role == UserRole.STUDENT:
        query = query.filter(ActivityLog.user_id == current_user.id)

    logs = query.order_by(ActivityLog.created_at.desc()).limit(limit).all()
    results = []
    for l in logs:
        r = ActivityLogResponse.model_validate(l)
        r.user_name = l.user.full_name if l.user else "System"
        results.append(r)

    return DataResponse(
        success=True,
        message=f"Retrieved {len(results)} audit log entries",
        data=results
    )
