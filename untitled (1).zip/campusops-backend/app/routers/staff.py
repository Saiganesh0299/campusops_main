from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, get_current_user
from app.core.exceptions import NotFoundException
from app.models.staff import Staff
from app.models.user import User
from app.schemas.staff import StaffResponse
from app.schemas.common import DataResponse

router = APIRouter(prefix="/staff", tags=["Staff"])

@router.get("", response_model=DataResponse[List[StaffResponse]])
def get_all_staff(db: Session = Depends(get_db)):
    staff_members = db.query(Staff).all()
    results = []
    for s in staff_members:
        res = StaffResponse.model_validate(s)
        res.full_name = s.user.full_name if s.user else None
        res.email = s.user.email if s.user else None
        results.append(res)
    return DataResponse(
        success=True,
        message="Staff list retrieved",
        data=results
    )

@router.get("/available", response_model=DataResponse[List[StaffResponse]])
def get_available_staff(db: Session = Depends(get_db)):
    available = db.query(Staff).filter(Staff.is_available == True).all()
    results = []
    for s in available:
        res = StaffResponse.model_validate(s)
        res.full_name = s.user.full_name if s.user else None
        res.email = s.user.email if s.user else None
        results.append(res)
    return DataResponse(
        success=True,
        message=f"Found {len(results)} available staff technicians",
        data=results
    )

@router.get("/{staff_id}", response_model=DataResponse[StaffResponse])
def get_staff_detail(staff_id: int, db: Session = Depends(get_db)):
    staff = db.query(Staff).filter(Staff.id == staff_id).first()
    if not staff:
        raise NotFoundException(f"Staff member #{staff_id} not found")
    res = StaffResponse.model_validate(staff)
    res.full_name = staff.user.full_name if staff.user else None
    res.email = staff.user.email if staff.user else None
    return DataResponse(
        success=True,
        message="Staff details retrieved",
        data=res
    )
