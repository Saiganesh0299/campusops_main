from typing import List, Optional
from collections import defaultdict
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, require_role
from app.core.exceptions import NotFoundException, ConflictException, ForbiddenException, ValidationException
from app.core.security import get_password_hash
from app.models.user import User
from app.models.department import Department
from app.models.permission import Permission, UserPermissionOverride
from app.schemas.user_management import (
    AdminCreateUserRequest,
    AdminUpdateUserRequest,
    AdminChangeRoleRequest,
    AdminAssignDepartmentRequest,
    AdminResetPasswordRequest,
    PermissionOverrideRequest,
    UserDetailResponse,
    UserManagementSummary,
    PermissionItemResponse
)
from app.schemas.common import DataResponse
from app.services.permission_service import permission_service
from app.services.notification_service import notification_service
from app.utils.enums import UserRole, AccessScope

router = APIRouter(prefix="/users", tags=["Admin User Management"])

def format_user_detail(u: User, db: Session) -> UserDetailResponse:
    effective_perms = permission_service.get_user_effective_permissions(db, u)
    perm_items = [
        PermissionItemResponse(
            module=p["module"],
            action=p["action"],
            scope=AccessScope(p["scope"]),
            is_granted=p["is_granted"]
        )
        for p in effective_perms
    ]
    return UserDetailResponse(
        id=u.id,
        full_name=u.full_name,
        email=u.email,
        role=u.role,
        department_id=u.department_id,
        department_name=u.department.name if u.department else None,
        is_active=u.is_active,
        is_primary_admin=u.is_primary_admin,
        created_at=u.created_at,
        updated_at=u.updated_at,
        permissions=perm_items
    )

@router.get("", response_model=DataResponse[List[UserDetailResponse]])
def get_users(
    role: Optional[str] = None,
    department_id: Optional[int] = None,
    is_active: Optional[bool] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db),
    admin: User = Depends(require_role(UserRole.SYSTEM_ADMIN))
):
    query = db.query(User)
    if role:
        query = query.filter(User.role == role)
    if department_id:
        query = query.filter(User.department_id == department_id)
    if is_active is not None:
        query = query.filter(User.is_active == is_active)
    if search:
        s = f"%{search}%"
        query = query.filter((User.full_name.ilike(s)) | (User.email.ilike(s)))

    users = query.order_by(User.id.asc()).all()
    results = [format_user_detail(u, db) for u in users]
    return DataResponse(
        success=True,
        message=f"Retrieved {len(results)} users",
        data=results
    )

@router.get("/summary", response_model=DataResponse[UserManagementSummary])
def get_user_management_summary(
    db: Session = Depends(get_db),
    admin: User = Depends(require_role(UserRole.SYSTEM_ADMIN))
):
    all_users = db.query(User).all()
    by_role = defaultdict(int)
    by_dept = defaultdict(int)
    active_count = 0
    inactive_count = 0

    for u in all_users:
        if u.is_active:
            active_count += 1
        else:
            inactive_count += 1
        by_role[u.role.value] += 1
        dept_name = u.department.name if u.department else "Unassigned / General"
        by_dept[dept_name] += 1

    summary = UserManagementSummary(
        total_users=len(all_users),
        active_users=active_count,
        inactive_users=inactive_count,
        users_by_role=dict(by_role),
        users_by_department=dict(by_dept)
    )
    return DataResponse(
        success=True,
        message="User management metrics compiled",
        data=summary
    )

@router.post("", response_model=DataResponse[UserDetailResponse], status_code=status.HTTP_201_CREATED)
def create_user(
    data: AdminCreateUserRequest,
    db: Session = Depends(get_db),
    admin: User = Depends(require_role(UserRole.SYSTEM_ADMIN))
):
    # Check duplicate email
    existing = db.query(User).filter(User.email == data.email).first()
    if existing:
        raise ConflictException(f"User with email '{data.email}' already exists")

    if data.department_id:
        dept = db.query(Department).filter(Department.id == data.department_id).first()
        if not dept:
            raise NotFoundException(f"Department #{data.department_id} not found")

    hashed_pw = get_password_hash(data.password)
    new_user = User(
        full_name=data.full_name,
        email=data.email,
        password_hash=hashed_pw,
        role=data.role,
        department_id=data.department_id,
        is_active=data.is_active,
        is_primary_admin=False
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    notification_service.log_activity(
        db=db,
        action="CREATE_USER",
        entity_type="User",
        entity_id=str(new_user.id),
        description=f"Created user '{new_user.email}' with role '{new_user.role.value}'",
        user_id=admin.id
    )

    return DataResponse(
        success=True,
        message=f"User '{new_user.email}' created successfully with role '{new_user.role.value}'",
        data=format_user_detail(new_user, db)
    )

@router.get("/{user_id}", response_model=DataResponse[UserDetailResponse])
def get_user(
    user_id: int,
    db: Session = Depends(get_db),
    admin: User = Depends(require_role(UserRole.SYSTEM_ADMIN))
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise NotFoundException(f"User #{user_id} not found")
    return DataResponse(
        success=True,
        message="User details retrieved",
        data=format_user_detail(user, db)
    )

@router.patch("/{user_id}", response_model=DataResponse[UserDetailResponse])
def update_user(
    user_id: int,
    data: AdminUpdateUserRequest,
    db: Session = Depends(get_db),
    admin: User = Depends(require_role(UserRole.SYSTEM_ADMIN))
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise NotFoundException(f"User #{user_id} not found")

    if user.is_primary_admin:
        if data.is_active is False:
            raise ForbiddenException("The primary System Admin account cannot be deactivated")
        if data.role is not None and data.role != UserRole.SYSTEM_ADMIN:
            raise ForbiddenException("The primary System Admin role cannot be demoted")

    if data.full_name is not None:
        user.full_name = data.full_name
    if data.role is not None:
        user.role = data.role
    if data.department_id is not None:
        user.department_id = data.department_id
    if data.is_active is not None:
        user.is_active = data.is_active

    db.commit()
    db.refresh(user)

    notification_service.log_activity(
        db=db,
        action="UPDATE_USER",
        entity_type="User",
        entity_id=str(user.id),
        description=f"Admin updated user profile for '{user.email}'",
        user_id=admin.id
    )

    return DataResponse(
        success=True,
        message="User updated successfully",
        data=format_user_detail(user, db)
    )

@router.patch("/{user_id}/role", response_model=DataResponse[UserDetailResponse])
def change_user_role(
    user_id: int,
    data: AdminChangeRoleRequest,
    db: Session = Depends(get_db),
    admin: User = Depends(require_role(UserRole.SYSTEM_ADMIN))
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise NotFoundException(f"User #{user_id} not found")

    if user.is_primary_admin and data.role != UserRole.SYSTEM_ADMIN:
        raise ForbiddenException("The primary System Admin role cannot be altered")

    old_role = user.role
    user.role = data.role
    db.commit()
    db.refresh(user)

    notification_service.log_activity(
        db=db,
        action="CHANGE_ROLE",
        entity_type="User",
        entity_id=str(user.id),
        description=f"Changed role of '{user.email}' from {old_role.value} to {data.role.value}",
        user_id=admin.id
    )

    return DataResponse(
        success=True,
        message=f"User role changed to {data.role.value}",
        data=format_user_detail(user, db)
    )

@router.patch("/{user_id}/status", response_model=DataResponse[UserDetailResponse])
def toggle_user_status(
    user_id: int,
    is_active: bool = Query(...),
    db: Session = Depends(get_db),
    admin: User = Depends(require_role(UserRole.SYSTEM_ADMIN))
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise NotFoundException(f"User #{user_id} not found")

    if user.is_primary_admin and not is_active:
        raise ForbiddenException("The primary System Admin account cannot be deactivated")

    user.is_active = is_active
    db.commit()
    db.refresh(user)

    notification_service.log_activity(
        db=db,
        action="STATUS_CHANGE",
        entity_type="User",
        entity_id=str(user.id),
        description=f"{'Activated' if is_active else 'Deactivated'} account for '{user.email}'",
        user_id=admin.id
    )

    return DataResponse(
        success=True,
        message=f"User account {'activated' if is_active else 'deactivated'} successfully",
        data=format_user_detail(user, db)
    )

@router.post("/{user_id}/reset-password", response_model=DataResponse[dict])
def reset_user_password(
    user_id: int,
    data: AdminResetPasswordRequest,
    db: Session = Depends(get_db),
    admin: User = Depends(require_role(UserRole.SYSTEM_ADMIN))
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise NotFoundException(f"User #{user_id} not found")

    user.password_hash = get_password_hash(data.new_password)
    db.commit()

    notification_service.log_activity(
        db=db,
        action="RESET_PASSWORD",
        entity_type="User",
        entity_id=str(user.id),
        description=f"Admin reset password for '{user.email}'",
        user_id=admin.id
    )

    return DataResponse(
        success=True,
        message=f"Password for user '{user.email}' has been reset successfully",
        data={"user_id": user.id, "email": user.email}
    )

@router.post("/{user_id}/permissions", response_model=DataResponse[UserDetailResponse])
def configure_user_permission(
    user_id: int,
    data: PermissionOverrideRequest,
    db: Session = Depends(get_db),
    admin: User = Depends(require_role(UserRole.SYSTEM_ADMIN))
):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise NotFoundException(f"User #{user_id} not found")

    perm = db.query(Permission).filter(
        Permission.module == data.module.upper(),
        Permission.action == data.action.upper()
    ).first()

    if not perm:
        perm = Permission(
            module=data.module.upper(),
            action=data.action.upper(),
            default_scope=data.scope,
            description=f"Custom permission for {data.module}:{data.action}"
        )
        db.add(perm)
        db.flush()

    override = db.query(UserPermissionOverride).filter(
        UserPermissionOverride.user_id == user.id,
        UserPermissionOverride.permission_id == perm.id
    ).first()

    if not override:
        override = UserPermissionOverride(
            user_id=user.id,
            permission_id=perm.id,
            scope=data.scope,
            is_granted=data.is_granted
        )
        db.add(override)
    else:
        override.scope = data.scope
        override.is_granted = data.is_granted

    db.commit()
    db.refresh(user)

    notification_service.log_activity(
        db=db,
        action="CONFIGURE_PERMISSION",
        entity_type="User",
        entity_id=str(user.id),
        description=f"Configured permission '{data.module}:{data.action}' (granted: {data.is_granted}, scope: {data.scope.value}) for '{user.email}'",
        user_id=admin.id
    )

    return DataResponse(
        success=True,
        message=f"Permission '{data.module}:{data.action}' updated for user",
        data=format_user_detail(user, db)
    )
