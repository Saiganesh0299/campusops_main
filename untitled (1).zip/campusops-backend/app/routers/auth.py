import uuid
from datetime import timedelta
from typing import List, Optional
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from app.core.config import settings
from app.core.dependencies import get_db, get_current_user
from app.core.exceptions import (
    ConflictException,
    UnauthorizedException,
    NotFoundException,
    ForbiddenException,
    ValidationException
)
from app.core.security import (
    verify_password,
    get_password_hash,
    create_access_token,
    create_refresh_token,
    decode_refresh_token
)
from app.models.user import User
from app.models.department import Department
from app.schemas.auth import (
    UserRegister,
    UserLogin,
    GoogleLoginRequest,
    CaptchaVerifyRequest,
    CaptchaVerifyResponse,
    TokenResponse,
    RefreshTokenRequest,
    UserResponse,
    UserPermissionSummary,
    UserPermissionItem
)
from app.schemas.common import DataResponse
from app.services.permission_service import permission_service
from app.utils.enums import UserRole, AccessScope

router = APIRouter(prefix="/auth", tags=["Authentication & Access Control"])

@router.post("/register", response_model=DataResponse[dict], status_code=status.HTTP_403_FORBIDDEN)
def register_disabled():
    """
    Public self-registration is permanently disabled as per security requirements.
    All accounts must be provisioned by the System Administrator.
    """
    raise ForbiddenException(
        "Public self-registration is disabled for campus security compliance. Only the System Administrator can create new accounts. Please contact operations administration."
    )

@router.post("/verify-captcha", response_model=DataResponse[CaptchaVerifyResponse])
def verify_captcha(data: CaptchaVerifyRequest):
    """
    Verifies human presence verification token before granting authentication.
    """
    if not data.captcha_token or len(data.captcha_token) < 3:
        raise ValidationException("Invalid or missing CAPTCHA challenge token")

    session_key = f"cap-sec-{uuid.uuid4().hex[:16]}"
    return DataResponse(
        success=True,
        message="Human verification challenge completed successfully",
        data=CaptchaVerifyResponse(
            verified=True,
            captcha_session=session_key
        )
    )

@router.post("/login", response_model=DataResponse[TokenResponse])
def login(credentials: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == credentials.email).first()
    if not user or not verify_password(credentials.password, user.password_hash):
        raise UnauthorizedException("Invalid email or password")

    if not user.is_active:
        raise UnauthorizedException("Your account is currently deactivated. Please contact the System Administrator.")

    access_token = create_access_token(
        data={"sub": str(user.id), "email": user.email, "role": user.role.value}
    )
    refresh_token = create_refresh_token(
        data={"sub": str(user.id), "email": user.email}
    )

    token_data = TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        user_id=user.id,
        email=user.email,
        full_name=user.full_name,
        role=user.role,
        department_id=user.department_id,
        department_name=user.department.name if user.department else None,
        is_primary_admin=user.is_primary_admin
    )

    return DataResponse(
        success=True,
        message="Authentication successful",
        data=token_data
    )

@router.post("/google-login", response_model=DataResponse[TokenResponse])
def google_login(payload: GoogleLoginRequest, db: Session = Depends(get_db)):
    """
    Authenticates a user via Google OAuth identity.
    Enforces that the email must be pre-provisioned by the System Administrator.
    """
    email_clean = payload.email.strip().lower()
    user = db.query(User).filter(User.email.ilike(email_clean)).first()

    if not user:
        raise UnauthorizedException(
            f"Google account '{email_clean}' is not provisioned in CampusOps. Public self-registration is disabled. Please request access from the System Administrator."
        )

    if not user.is_active:
        raise UnauthorizedException("Your account is currently deactivated. Please contact the System Administrator.")

    access_token = create_access_token(
        data={"sub": str(user.id), "email": user.email, "role": user.role.value}
    )
    refresh_token = create_refresh_token(
        data={"sub": str(user.id), "email": user.email}
    )

    token_data = TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        user_id=user.id,
        email=user.email,
        full_name=user.full_name,
        role=user.role,
        department_id=user.department_id,
        department_name=user.department.name if user.department else None,
        is_primary_admin=user.is_primary_admin
    )

    return DataResponse(
        success=True,
        message="Authenticated via Google single sign-on",
        data=token_data
    )

@router.post("/refresh", response_model=DataResponse[TokenResponse])
def refresh_token(payload: RefreshTokenRequest, db: Session = Depends(get_db)):
    token_payload = decode_refresh_token(payload.refresh_token)
    if not token_payload:
        raise UnauthorizedException("Invalid or expired refresh token")

    user_id = token_payload.get("sub")
    user = db.query(User).filter(User.id == int(user_id)).first()
    if not user or not user.is_active:
        raise UnauthorizedException("User account not found or inactive")

    new_access_token = create_access_token(
        data={"sub": str(user.id), "email": user.email, "role": user.role.value}
    )
    new_refresh_token = create_refresh_token(
        data={"sub": str(user.id), "email": user.email}
    )

    token_data = TokenResponse(
        access_token=new_access_token,
        refresh_token=new_refresh_token,
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        user_id=user.id,
        email=user.email,
        full_name=user.full_name,
        role=user.role,
        department_id=user.department_id,
        department_name=user.department.name if user.department else None,
        is_primary_admin=user.is_primary_admin
    )

    return DataResponse(
        success=True,
        message="Token refreshed successfully",
        data=token_data
    )

@router.get("/me", response_model=DataResponse[UserResponse])
def get_current_user_profile(current_user: User = Depends(get_current_user)):
    res = UserResponse.model_validate(current_user)
    res.department_name = current_user.department.name if current_user.department else None
    return DataResponse(
        success=True,
        message="User profile retrieved",
        data=res
    )

@router.get("/permissions", response_model=DataResponse[UserPermissionSummary])
def get_current_user_permissions(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Returns the resolved permissions and operational scopes for the logged-in user.
    """
    raw_perms = permission_service.get_user_effective_permissions(db, current_user)
    perm_items = [
        UserPermissionItem(
            module=p["module"],
            action=p["action"],
            scope=AccessScope(p["scope"])
        )
        for p in raw_perms
    ]

    summary = UserPermissionSummary(
        user_id=current_user.id,
        role=current_user.role,
        department_id=current_user.department_id,
        department_name=current_user.department.name if current_user.department else None,
        is_primary_admin=current_user.is_primary_admin,
        permissions=perm_items
    )

    return DataResponse(
        success=True,
        message="Effective permissions calculated",
        data=summary
    )
