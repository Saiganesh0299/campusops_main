from datetime import date, datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, get_current_user
from app.core.exceptions import NotFoundException, ConflictException, ForbiddenException
from app.models.booking import Booking
from app.models.room import Room
from app.models.user import User
from app.schemas.booking import (
    BookingCreate,
    BookingUpdate,
    BookingResponse,
    AlternativeBookingsResponse
)
from app.schemas.common import DataResponse
from app.services.booking_service import booking_service, parse_time_str
from app.services.notification_service import notification_service
from app.utils.enums import UserRole, BookingStatus, NotificationType

router = APIRouter(prefix="/bookings", tags=["Bookings"])

def format_booking_res(b: Booking) -> BookingResponse:
    res = BookingResponse.model_validate(b)
    res.start_time = b.start_time.strftime("%H:%M")
    res.end_time = b.end_time.strftime("%H:%M")
    if b.room:
        res.room_number = b.room.room_number
        res.room_name = b.room.room_name
        res.building_name = b.room.building.building_name if b.room.building else None
    if b.user:
        res.requester_name = b.user.full_name
    return res

@router.post("", response_model=DataResponse[BookingResponse], status_code=status.HTTP_201_CREATED)
def create_booking(
    data: BookingCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    room = db.query(Room).filter(Room.id == data.room_id).first()
    if not room:
        raise NotFoundException(f"Room #{data.room_id} not found")

    if room.availability_status != "available":
        raise ConflictException(f"Room {room.room_number} is currently marked as '{room.availability_status}' and cannot be booked")

    if data.attendees_count and data.attendees_count > room.capacity:
        raise ConflictException(f"Requested attendees ({data.attendees_count}) exceeds room capacity ({room.capacity})")

    start_t = parse_time_str(data.start_time)
    end_t = parse_time_str(data.end_time)
    if start_t >= end_t:
        raise ConflictException("Start time must precede end time")

    # Concurrency safe conflict check
    conflict = booking_service.check_room_conflict(
        db=db,
        room_id=data.room_id,
        booking_date=data.booking_date,
        start_t=start_t,
        end_t=end_t,
        lock_row=True
    )
    if conflict:
        raise ConflictException(
            f"Room booking conflict: Room {room.room_number} is already booked from {conflict.start_time.strftime('%H:%M')} to {conflict.end_time.strftime('%H:%M')} on {data.booking_date}"
        )

    count = db.query(Booking).count() + 1
    code = f"BK-{datetime.now().strftime('%y%m%d')}-{count:04d}"

    booking = Booking(
        booking_code=code,
        room_id=data.room_id,
        requested_by=current_user.id,
        purpose=data.purpose,
        booking_date=data.booking_date,
        start_time=start_t,
        end_time=end_t,
        status=BookingStatus.CONFIRMED
    )
    db.add(booking)
    db.commit()
    db.refresh(booking)

    notification_service.log_activity(
        db=db,
        action="CREATE_BOOKING",
        entity_type="Booking",
        entity_id=str(booking.id),
        description=f"Confirmed reservation #{booking.booking_code} for {room.room_name} on {data.booking_date}",
        user_id=current_user.id
    )

    return DataResponse(
        success=True,
        message=f"Booking #{booking.booking_code} confirmed successfully",
        data=format_booking_res(booking)
    )

@router.get("", response_model=DataResponse[List[BookingResponse]])
def get_bookings(
    room_id: Optional[int] = None,
    booking_date: Optional[date] = None,
    status_filter: Optional[str] = Query(None, alias="status"),
    db: Session = Depends(get_db)
):
    query = db.query(Booking)
    if room_id:
        query = query.filter(Booking.room_id == room_id)
    if booking_date:
        query = query.filter(Booking.booking_date == booking_date)
    if status_filter:
        query = query.filter(Booking.status == status_filter)

    bookings = query.order_by(Booking.booking_date.asc(), Booking.start_time.asc()).all()
    results = [format_booking_res(b) for b in bookings]
    return DataResponse(
        success=True,
        message=f"Retrieved {len(results)} bookings",
        data=results
    )

@router.get("/alternatives", response_model=DataResponse[AlternativeBookingsResponse])
def get_booking_alternatives(
    room_id: int,
    booking_date: date,
    start_time: str,
    end_time: str,
    capacity: int = 1,
    db: Session = Depends(get_db)
):
    start_t = parse_time_str(start_time)
    end_t = parse_time_str(end_time)

    res = booking_service.find_alternatives(
        db=db,
        room_id=room_id,
        booking_date=booking_date,
        start_t=start_t,
        end_t=end_t,
        required_capacity=capacity
    )

    return DataResponse(
        success=True,
        message="Alternative slots and rooms calculated",
        data=res
    )

@router.get("/{booking_id}", response_model=DataResponse[BookingResponse])
def get_booking(booking_id: int, db: Session = Depends(get_db)):
    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    if not booking:
        raise NotFoundException(f"Booking #{booking_id} not found")
    return DataResponse(
        success=True,
        message="Booking retrieved",
        data=format_booking_res(booking)
    )

@router.put("/{booking_id}", response_model=DataResponse[BookingResponse])
def update_booking(
    booking_id: int,
    data: BookingUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    if not booking:
        raise NotFoundException(f"Booking #{booking_id} not found")

    if current_user.role not in [UserRole.ADMIN, UserRole.FACILITY_MANAGER] and booking.requested_by != current_user.id:
        raise ForbiddenException("You are only permitted to edit your own room reservations")

    if data.purpose is not None:
        booking.purpose = data.purpose
    if data.status is not None:
        booking.status = data.status
    if data.booking_date is not None or data.start_time is not None or data.end_time is not None:
        new_date = data.booking_date or booking.booking_date
        new_start = parse_time_str(data.start_time) if data.start_time else booking.start_time
        new_end = parse_time_str(data.end_time) if data.end_time else booking.end_time

        conflict = booking_service.check_room_conflict(
            db=db,
            room_id=booking.room_id,
            booking_date=new_date,
            start_t=new_start,
            end_t=new_end,
            exclude_booking_id=booking.id,
            lock_row=True
        )
        if conflict:
            raise ConflictException("Requested schedule modification conflicts with an existing reservation")

        booking.booking_date = new_date
        booking.start_time = new_start
        booking.end_time = new_end

    db.commit()
    db.refresh(booking)

    return DataResponse(
        success=True,
        message="Booking updated successfully",
        data=format_booking_res(booking)
    )

@router.delete("/{booking_id}", response_model=DataResponse[dict])
def cancel_booking(
    booking_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    if not booking:
        raise NotFoundException(f"Booking #{booking_id} not found")

    if current_user.role not in [UserRole.ADMIN, UserRole.FACILITY_MANAGER] and booking.requested_by != current_user.id:
        raise ForbiddenException("You can only cancel your own bookings")

    booking.status = BookingStatus.CANCELLED
    db.commit()

    return DataResponse(
        success=True,
        message=f"Booking #{booking.booking_code} cancelled successfully",
        data={"cancelled_id": booking_id}
    )
