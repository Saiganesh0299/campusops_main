from typing import Optional, Dict, Any, List
from fastapi import APIRouter, Depends, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, get_current_user, oauth2_scheme
from app.core.security import decode_access_token
from app.models.building import Building
from app.models.room import Room
from app.models.complaint import Complaint
from app.models.staff import Staff
from app.models.inventory import Inventory
from app.models.user import User
from app.schemas.common import DataResponse
from app.services.ai_service import ai_service
from app.utils.enums import ComplaintStatus, UserRole

router = APIRouter(prefix="/ai", tags=["AI Copilot"])

class AIChatRequest(BaseModel):
    message: str = Field(..., min_length=1)
    context_building_id: Optional[int] = None

class AIChatResponse(BaseModel):
    reply: str
    action_type: str = "chat"
    action_payload: Optional[Dict[str, Any]] = None

def get_optional_chat_user(
    token: Optional[str] = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> Optional[User]:
    if not token:
        return None
    payload = decode_access_token(token)
    if not payload:
        return None
    try:
        user_id = int(payload.get("sub", 0))
        return db.query(User).filter(User.id == user_id).first()
    except Exception:
        return None

@router.post("/chat", response_model=DataResponse[AIChatResponse])
async def campus_copilot_chat(
    payload: AIChatRequest,
    db: Session = Depends(get_db),
    user: Optional[User] = Depends(get_optional_chat_user)
):
    # Retrieve authorized real campus operational context from database
    buildings = db.query(Building).all()
    available_rooms = db.query(Room).filter(Room.availability_status == "available").limit(10).all()
    open_complaints = db.query(Complaint).filter(Complaint.status != ComplaintStatus.RESOLVED).all()
    available_staff = db.query(Staff).filter(Staff.is_available == True).all()
    inventory_shortages = db.query(Inventory).filter(
        Inventory.available_quantity <= Inventory.minimum_stock_level
    ).all()

    campus_context = {
        "user_role": user.role.value if user else "GUEST",
        "open_complaints_count": len(open_complaints),
        "critical_count": sum(1 for c in open_complaints if c.priority == "CRITICAL"),
        "recent_complaints": [
            {
                "code": c.complaint_code,
                "building": c.building.building_name if c.building else "Campus",
                "category": c.category.value,
                "priority": c.priority.value,
                "description": c.description
            }
            for c in open_complaints[:5]
        ],
        "available_rooms": [
            {
                "id": r.id,
                "number": r.room_number,
                "name": r.room_name,
                "building": r.building.building_name if r.building else "Campus",
                "capacity": r.capacity
            }
            for r in available_rooms[:6]
        ],
        "available_staff": [
            {
                "name": s.user.full_name if s.user else s.employee_code,
                "department": s.department,
                "skills": s.skills or []
            }
            for s in available_staff[:6]
        ],
        "inventory_shortages": [
            {
                "name": i.item_name,
                "available": i.available_quantity,
                "min": i.minimum_stock_level
            }
            for i in inventory_shortages
        ]
    }

    reply_text = await ai_service.answer_copilot_query(
        query=payload.message,
        campus_context=campus_context
    )

    return DataResponse(
        success=True,
        message="AI Copilot response generated",
        data=AIChatResponse(
            reply=reply_text,
            action_type="chat",
            action_payload={"analyzed_context_nodes": len(buildings) + len(open_complaints)}
        )
    )
