from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, require_role
from app.core.exceptions import NotFoundException, ConflictException
from app.models.inventory import Inventory
from app.models.user import User
from app.schemas.inventory import (
    InventoryCreate,
    InventoryUpdate,
    InventoryResponse,
    InventoryRestockRequest,
    ReservationResponse
)
from app.schemas.common import DataResponse
from app.services.inventory_service import inventory_service
from app.services.notification_service import notification_service
from app.utils.enums import UserRole

router = APIRouter(tags=["Inventory"])

def format_inv_res(item: Inventory) -> InventoryResponse:
    res = InventoryResponse.model_validate(item)
    res.is_low_stock = item.available_quantity <= item.minimum_stock_level
    res.active_reservations_count = len(item.reservations)
    return res

@router.get("/inventory", response_model=DataResponse[List[InventoryResponse]])
def get_inventory(
    category: Optional[str] = None,
    low_stock_only: bool = False,
    db: Session = Depends(get_db)
):
    query = db.query(Inventory)
    if category:
        query = query.filter(Inventory.category == category)
    if low_stock_only:
        query = query.filter(Inventory.available_quantity <= Inventory.minimum_stock_level)

    items = query.order_by(Inventory.item_name.asc()).all()
    results = [format_inv_res(i) for i in items]
    return DataResponse(
        success=True,
        message=f"Retrieved {len(results)} inventory items",
        data=results
    )

@router.get("/inventory/{item_id}", response_model=DataResponse[InventoryResponse])
def get_inventory_item(item_id: int, db: Session = Depends(get_db)):
    item = db.query(Inventory).filter(Inventory.id == item_id).first()
    if not item:
        raise NotFoundException(f"Inventory item #{item_id} not found")
    return DataResponse(
        success=True,
        message="Inventory item retrieved",
        data=format_inv_res(item)
    )

@router.post("/inventory", response_model=DataResponse[InventoryResponse], status_code=status.HTTP_201_CREATED)
def create_inventory_item(
    data: InventoryCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER))
):
    existing = db.query(Inventory).filter(Inventory.item_code == data.item_code).first()
    if existing:
        raise ConflictException(f"Item code '{data.item_code}' already exists")

    item = Inventory(
        item_code=data.item_code,
        item_name=data.item_name,
        category=data.category,
        description=data.description,
        total_quantity=data.total_quantity,
        available_quantity=data.available_quantity,
        reserved_quantity=data.reserved_quantity,
        minimum_stock_level=data.minimum_stock_level,
        storage_location=data.storage_location
    )
    db.add(item)
    db.commit()
    db.refresh(item)

    return DataResponse(
        success=True,
        message="Inventory item created",
        data=format_inv_res(item)
    )

@router.put("/inventory/{item_id}", response_model=DataResponse[InventoryResponse])
def update_inventory_item(
    item_id: int,
    data: InventoryUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER))
):
    item = db.query(Inventory).filter(Inventory.id == item_id).first()
    if not item:
        raise NotFoundException(f"Inventory item #{item_id} not found")

    if data.item_name is not None:
        item.item_name = data.item_name
    if data.category is not None:
        item.category = data.category
    if data.description is not None:
        item.description = data.description
    if data.minimum_stock_level is not None:
        item.minimum_stock_level = data.minimum_stock_level
    if data.storage_location is not None:
        item.storage_location = data.storage_location

    db.commit()
    db.refresh(item)

    return DataResponse(
        success=True,
        message="Inventory item updated",
        data=format_inv_res(item)
    )

@router.post("/inventory/{item_id}/restock", response_model=DataResponse[InventoryResponse])
def restock_inventory(
    item_id: int,
    payload: InventoryRestockRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER, UserRole.STAFF))
):
    item = inventory_service.restock_item(
        db=db,
        inventory_id=item_id,
        added_quantity=payload.quantity
    )

    notification_service.log_activity(
        db=db,
        action="RESTOCK_INVENTORY",
        entity_type="Inventory",
        entity_id=str(item.id),
        description=f"Restocked {payload.quantity} units of {item.item_name}. New stock: {item.available_quantity}. Notes: {payload.notes or 'None'}",
        user_id=current_user.id
    )

    return DataResponse(
        success=True,
        message=f"Added {payload.quantity} units to '{item.item_name}'",
        data=format_inv_res(item)
    )

@router.post("/reservations/{reservation_id}/release", response_model=DataResponse[ReservationResponse])
def release_reservation(
    reservation_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER, UserRole.STAFF))
):
    res = inventory_service.release_reservation(db=db, reservation_id=reservation_id)
    return DataResponse(
        success=True,
        message=f"Reservation #{reservation_id} released back into available inventory",
        data=ReservationResponse(
            id=res.id,
            inventory_id=res.inventory_id,
            item_code=res.inventory_item.item_code,
            item_name=res.inventory_item.item_name,
            work_order_id=res.work_order_id,
            quantity=res.quantity,
            status=res.status,
            reserved_at=res.reserved_at,
            released_at=res.released_at
        )
    )
