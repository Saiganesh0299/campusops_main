from typing import List, Optional
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, require_role
from app.core.exceptions import NotFoundException
from app.models.incident import Incident
from app.models.complaint import Complaint
from app.models.user import User
from app.schemas.incident import (
    IncidentCreate,
    IncidentUpdate,
    IncidentResponse,
    IncidentCorrelateRequest,
    IncidentCorrelateResponse,
    CorrelatedGroup
)
from app.schemas.complaint import ComplaintResponse
from app.schemas.common import DataResponse
from app.services.incident_service import incident_service
from app.utils.enums import UserRole

router = APIRouter(prefix="/incidents", tags=["Incidents"])

def format_incident_res(inc: Incident) -> IncidentResponse:
    res = IncidentResponse.model_validate(inc)
    res.complaint_ids = [c.id for c in inc.complaints]
    res.complaints_count = len(inc.complaints)
    return res

@router.post("/correlate", response_model=DataResponse[IncidentCorrelateResponse])
def correlate_incidents(
    data: IncidentCorrelateRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER, UserRole.STAFF))
):
    correlation = incident_service.correlate_complaints(
        db=db,
        building_id=data.building_id,
        category=data.category,
        timeframe_hours=data.timeframe_hours
    )
    return DataResponse(
        success=True,
        message=f"Incident correlation complete: {correlation.correlated_incidents_found} correlated incident patterns identified",
        data=correlation
    )

@router.post("/correlate/confirm-group", response_model=DataResponse[IncidentResponse], status_code=status.HTTP_201_CREATED)
def confirm_correlated_incident(
    group: CorrelatedGroup,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER))
):
    incident = incident_service.create_incident_from_correlation(db, group)
    return DataResponse(
        success=True,
        message=f"Correlated Incident #{incident.incident_code} instantiated from {len(group.complaint_ids)} complaints",
        data=format_incident_res(incident)
    )

@router.get("", response_model=DataResponse[List[IncidentResponse]])
def get_incidents(db: Session = Depends(get_db)):
    incidents = db.query(Incident).order_by(Incident.created_at.desc()).all()
    results = [format_incident_res(i) for i in incidents]
    return DataResponse(
        success=True,
        message=f"Fetched {len(results)} campus incidents",
        data=results
    )

@router.get("/{incident_id}", response_model=DataResponse[IncidentResponse])
def get_incident(incident_id: int, db: Session = Depends(get_db)):
    incident = db.query(Incident).filter(Incident.id == incident_id).first()
    if not incident:
        raise NotFoundException(f"Incident #{incident_id} not found")
    return DataResponse(
        success=True,
        message="Incident retrieved",
        data=format_incident_res(incident)
    )

@router.get("/{incident_id}/complaints", response_model=DataResponse[List[ComplaintResponse]])
def get_incident_complaints(incident_id: int, db: Session = Depends(get_db)):
    incident = db.query(Incident).filter(Incident.id == incident_id).first()
    if not incident:
        raise NotFoundException(f"Incident #{incident_id} not found")

    complaints_data = []
    for c in incident.complaints:
        cr = ComplaintResponse.model_validate(c)
        cr.building_name = c.building.building_name if c.building else None
        cr.room_number = c.room.room_number if c.room else None
        complaints_data.append(cr)

    return DataResponse(
        success=True,
        message=f"Retrieved {len(complaints_data)} linked complaints for incident #{incident.incident_code}",
        data=complaints_data
    )

@router.post("", response_model=DataResponse[IncidentResponse], status_code=status.HTTP_201_CREATED)
def create_incident(
    data: IncidentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER))
):
    from datetime import datetime
    count = db.query(Incident).count() + 1
    code = f"INC-{datetime.now().strftime('%y%m%d')}-{count:03d}"

    complaints = []
    if data.complaint_ids:
        complaints = db.query(Complaint).filter(Complaint.id.in_(data.complaint_ids)).all()

    incident = Incident(
        incident_code=code,
        title=data.title,
        description=data.description,
        category=data.category,
        priority=data.priority,
        status=data.status,
        affected_locations=data.affected_locations,
        complaints=complaints
    )
    db.add(incident)
    db.commit()
    db.refresh(incident)

    return DataResponse(
        success=True,
        message=f"Incident #{incident.incident_code} created successfully",
        data=format_incident_res(incident)
    )
