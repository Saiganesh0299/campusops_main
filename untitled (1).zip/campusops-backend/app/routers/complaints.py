from typing import List, Optional
from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.orm import Session
from app.core.dependencies import get_db, get_current_user, require_role, oauth2_scheme
from app.core.exceptions import NotFoundException, ForbiddenException
from app.core.security import decode_access_token
from app.models.complaint import Complaint
from app.models.building import Building
from app.models.room import Room
from app.models.user import User
from app.schemas.complaint import (
    ComplaintCreate,
    ComplaintUpdate,
    ComplaintResponse,
    EmailIngestRequest,
    DuplicateComplaintCandidate
)
from app.schemas.common import DataResponse
from app.services.complaint_service import complaint_service
from app.utils.enums import UserRole, ComplaintSource, ComplaintStatus

router = APIRouter(prefix="/complaints", tags=["Complaints"])

def get_optional_user(
    token: Optional[str] = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> Optional[User]:
    if not token:
        return None
    payload = decode_access_token(token)
    if not payload:
        return None
    try:
        user_id = int(payload.get("sub", 0))
        return db.query(User).filter(User.id == user_id).first()
    except Exception:
        return None

def format_complaint_res(c: Complaint, duplicates: Optional[List[DuplicateComplaintCandidate]] = None) -> ComplaintResponse:
    res = ComplaintResponse.model_validate(c)
    res.submitter_name = c.submitter.full_name if c.submitter else "Anonymous / Campus Member"
    res.building_name = c.building.building_name if c.building else None
    res.room_number = c.room.room_number if c.room else None
    res.asset_name = c.asset.asset_name if c.asset else None
    res.duplicate_candidates = duplicates or []
    return res

@router.post("", response_model=DataResponse[ComplaintResponse], status_code=status.HTTP_201_CREATED)
async def create_complaint(
    data: ComplaintCreate,
    db: Session = Depends(get_db),
    user: Optional[User] = Depends(get_optional_user)
):
    sub_id = user.id if user else None
    complaint, work_order, duplicates = await complaint_service.process_and_create_complaint(
        db=db,
        data=data,
        submitted_by=sub_id
    )

    msg = f"Complaint #{complaint.complaint_code} submitted successfully."
    if complaint.status == ComplaintStatus.AWAITING_CLARIFICATION:
        msg = f"Complaint submitted, but missing information: {complaint.missing_information}"
    elif work_order:
        msg += f" Work order #{work_order.work_order_code} dispatched."

    return DataResponse(
        success=True,
        message=msg,
        data=format_complaint_res(complaint, duplicates)
    )

@router.get("", response_model=DataResponse[List[ComplaintResponse]])
def get_complaints(
    building_id: Optional[int] = None,
    category: Optional[str] = None,
    priority: Optional[str] = None,
    status_filter: Optional[str] = Query(None, alias="status"),
    db: Session = Depends(get_db),
    user: Optional[User] = Depends(get_optional_user)
):
    query = db.query(Complaint)

    # Enforce role scope filtering if authenticated
    if user:
        if user.role == UserRole.STUDENT_FACULTY:
            # Student/Faculty: Only OWN submitted reports
            query = query.filter(Complaint.submitted_by == user.id)
        elif user.role == UserRole.TECHNICIAN:
            # Technician: Assigned work orders complaints
            if user.staff_profile:
                from app.models.work_order import WorkOrder
                assigned_c_ids = db.query(WorkOrder.complaint_id).filter(
                    WorkOrder.assigned_staff_id == user.staff_profile.id
                ).all()
                c_ids = [c[0] for c in assigned_c_ids]
                query = query.filter(Complaint.id.in_(c_ids))
        elif user.role == UserRole.DEPT_MANAGER:
            # Department Manager: Complaints from their department members
            if user.department_id:
                dept_users = db.query(User.id).filter(User.department_id == user.department_id).all()
                dept_uids = [u[0] for u in dept_users]
                query = query.filter(Complaint.submitted_by.in_(dept_uids))

    if building_id:
        query = query.filter(Complaint.building_id == building_id)
    if category:
        query = query.filter(Complaint.category == category)
    if priority:
        query = query.filter(Complaint.priority == priority)
    if status_filter:
        query = query.filter(Complaint.status == status_filter)

    complaints = query.order_by(Complaint.created_at.desc()).all()
    results = [format_complaint_res(c) for c in complaints]

    return DataResponse(
        success=True,
        message=f"Retrieved {len(results)} complaints",
        data=results
    )

@router.get("/{complaint_id}", response_model=DataResponse[ComplaintResponse])
def get_complaint(
    complaint_id: int,
    db: Session = Depends(get_db),
    user: Optional[User] = Depends(get_optional_user)
):
    complaint = db.query(Complaint).filter(Complaint.id == complaint_id).first()
    if not complaint:
        raise NotFoundException(f"Complaint #{complaint_id} not found")

    # Scope check
    if user:
        if user.role == UserRole.STUDENT_FACULTY and complaint.submitted_by != user.id:
            raise ForbiddenException("Access denied: You can only view your own submitted complaints")
        elif user.role == UserRole.DEPT_MANAGER and user.department_id:
            sub = complaint.submitter
            if sub and sub.department_id != user.department_id:
                raise ForbiddenException("Access denied: You can only view complaints from your department")

    return DataResponse(
        success=True,
        message="Complaint details retrieved",
        data=format_complaint_res(complaint)
    )

@router.put("/{complaint_id}", response_model=DataResponse[ComplaintResponse])
def update_complaint(
    complaint_id: int,
    data: ComplaintUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER, UserRole.STAFF))
):
    complaint = db.query(Complaint).filter(Complaint.id == complaint_id).first()
    if not complaint:
        raise NotFoundException(f"Complaint #{complaint_id} not found")

    if data.description is not None:
        complaint.description = data.description
    if data.category is not None:
        complaint.category = data.category
    if data.priority is not None:
        complaint.priority = data.priority
    if data.status is not None:
        complaint.status = data.status
    if data.room_id is not None:
        complaint.room_id = data.room_id
    if data.asset_id is not None:
        complaint.asset_id = data.asset_id
    if data.missing_information is not None:
        complaint.missing_information = data.missing_information

    db.commit()
    db.refresh(complaint)

    return DataResponse(
        success=True,
        message="Complaint updated successfully",
        data=format_complaint_res(complaint)
    )

@router.delete("/{complaint_id}", response_model=DataResponse[dict])
def delete_complaint(
    complaint_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role(UserRole.ADMIN, UserRole.FACILITY_MANAGER))
):
    complaint = db.query(Complaint).filter(Complaint.id == complaint_id).first()
    if not complaint:
        raise NotFoundException(f"Complaint #{complaint_id} not found")

    db.delete(complaint)
    db.commit()

    return DataResponse(
        success=True,
        message=f"Complaint #{complaint.complaint_code} deleted successfully",
        data={"deleted_id": complaint_id}
    )

@router.post("/ingest-email", response_model=DataResponse[ComplaintResponse], status_code=status.HTTP_201_CREATED)
async def ingest_simulated_email(
    payload: EmailIngestRequest,
    db: Session = Depends(get_db)
):
    """
    Simulated email intake webhook. Automatically finds or defaults campus building,
    parses email subject + body using AI, and registers the complaint under EMAIL source.
    """
    # Attempt to match building
    bldg = None
    if payload.building_code_or_name:
        bldg = db.query(Building).filter(
            (Building.building_code.ilike(f"%{payload.building_code_or_name}%")) |
            (Building.building_name.ilike(f"%{payload.building_code_or_name}%"))
        ).first()

    if not bldg:
        # Default to first building if not matched
        bldg = db.query(Building).first()

    if not bldg:
        raise NotFoundException("No campus buildings registered to assign email issue")

    room = None
    if payload.room_number:
        room = db.query(Room).filter(
            Room.building_id == bldg.id,
            Room.room_number.ilike(f"%{payload.room_number}%")
        ).first()

    complaint_in = ComplaintCreate(
        description=f"[From: {payload.sender_name} <{payload.sender_email}>] Subject: {payload.subject} - {payload.body}",
        building_id=bldg.id,
        room_id=room.id if room else None,
        source=ComplaintSource.EMAIL
    )

    complaint, work_order, duplicates = await complaint_service.process_and_create_complaint(
        db=db,
        data=complaint_in
    )

    return DataResponse(
        success=True,
        message=f"Email from {payload.sender_email} ingested into Complaint #{complaint.complaint_code}",
        data=format_complaint_res(complaint, duplicates)
    )
