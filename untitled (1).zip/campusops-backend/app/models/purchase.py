from datetime import datetime
from typing import List, Optional, TYPE_CHECKING
from sqlalchemy import String, Integer, Float, Text, ForeignKey, Enum, func, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database.base import Base, TimestampMixin
from app.utils.enums import PurchaseStatus

if TYPE_CHECKING:
    from app.models.user import User
    from app.models.department import Department
    from app.models.work_order import WorkOrder

class PurchaseRequest(Base, TimestampMixin):
    __tablename__ = "purchase_requests"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    request_code: Mapped[str] = mapped_column(String(50), unique=True, index=True, nullable=False)
    requester_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)
    department_id: Mapped[Optional[int]] = mapped_column(ForeignKey("departments.id", ondelete="SET NULL"), index=True, nullable=True)
    work_order_id: Mapped[Optional[int]] = mapped_column(ForeignKey("work_orders.id", ondelete="SET NULL"), index=True, nullable=True)
    item_name: Mapped[str] = mapped_column(String(150), index=True, nullable=False)
    category: Mapped[str] = mapped_column(String(100), default="Equipment", nullable=False)
    quantity: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    estimated_unit_cost: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    total_estimated_cost: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    justification: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[PurchaseStatus] = mapped_column(
        Enum(PurchaseStatus, native_enum=False, length=50),
        default=PurchaseStatus.PENDING_REVIEW,
        nullable=False
    )

    # Relationships
    requester: Mapped["User"] = relationship("User", foreign_keys=[requester_id], back_populates="purchase_requests")
    department: Mapped[Optional["Department"]] = relationship("Department", back_populates="purchase_requests")
    work_order: Mapped[Optional["WorkOrder"]] = relationship("WorkOrder")
    approvals: Mapped[List["PurchaseApproval"]] = relationship("PurchaseApproval", back_populates="purchase_request", cascade="all, delete-orphan")

class PurchaseApproval(Base):
    __tablename__ = "purchase_approvals"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    purchase_request_id: Mapped[int] = mapped_column(ForeignKey("purchase_requests.id", ondelete="CASCADE"), index=True, nullable=False)
    approver_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)
    action: Mapped[str] = mapped_column(String(50), nullable=False)  # APPROVED or REJECTED
    comments: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    purchase_request: Mapped["PurchaseRequest"] = relationship("PurchaseRequest", back_populates="approvals")
    approver: Mapped["User"] = relationship("User", foreign_keys=[approver_id], back_populates="purchase_approvals")
