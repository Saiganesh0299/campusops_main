from datetime import datetime
from typing import List, Optional, TYPE_CHECKING
from sqlalchemy import String, Integer, Text, DateTime, ForeignKey, Enum
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database.base import Base, TimestampMixin
from app.utils.enums import PriorityLevel, WorkOrderStatus

if TYPE_CHECKING:
    from app.models.complaint import Complaint
    from app.models.staff import Staff
    from app.models.reservation import InventoryReservation

class WorkOrder(Base, TimestampMixin):
    __tablename__ = "work_orders"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    work_order_code: Mapped[str] = mapped_column(String(50), unique=True, index=True, nullable=False)
    complaint_id: Mapped[int] = mapped_column(ForeignKey("complaints.id", ondelete="CASCADE"), nullable=False, index=True)
    assigned_staff_id: Mapped[Optional[int]] = mapped_column(ForeignKey("staff.id", ondelete="SET NULL"), nullable=True, index=True)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    priority: Mapped[PriorityLevel] = mapped_column(
        Enum(PriorityLevel, native_enum=False, length=50),
        default=PriorityLevel.MEDIUM,
        nullable=False
    )
    status: Mapped[WorkOrderStatus] = mapped_column(
        Enum(WorkOrderStatus, native_enum=False, length=50),
        default=WorkOrderStatus.NEW,
        nullable=False
    )
    estimated_completion: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    actual_completion: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Relationships
    complaint: Mapped["Complaint"] = relationship("Complaint", back_populates="work_orders")
    assigned_staff: Mapped[Optional["Staff"]] = relationship("Staff", back_populates="work_orders")
    reservations: Mapped[List["InventoryReservation"]] = relationship("InventoryReservation", back_populates="work_order", cascade="all, delete-orphan")
