from datetime import datetime
from typing import Optional, TYPE_CHECKING
from sqlalchemy import Integer, DateTime, ForeignKey, Enum, func
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database.base import Base
from app.utils.enums import InventoryReservationStatus

if TYPE_CHECKING:
    from app.models.inventory import Inventory
    from app.models.work_order import WorkOrder

class InventoryReservation(Base):
    __tablename__ = "inventory_reservations"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    inventory_id: Mapped[int] = mapped_column(ForeignKey("inventory.id", ondelete="CASCADE"), nullable=False, index=True)
    work_order_id: Mapped[int] = mapped_column(ForeignKey("work_orders.id", ondelete="CASCADE"), nullable=False, index=True)
    quantity: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    status: Mapped[InventoryReservationStatus] = mapped_column(
        Enum(InventoryReservationStatus, native_enum=False, length=50),
        default=InventoryReservationStatus.RESERVED,
        nullable=False
    )
    reserved_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    released_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Relationships
    inventory_item: Mapped["Inventory"] = relationship("Inventory", back_populates="reservations")
    work_order: Mapped["WorkOrder"] = relationship("WorkOrder", back_populates="reservations")
