from datetime import datetime
from typing import List, Optional, TYPE_CHECKING
from sqlalchemy import String, Boolean, Enum, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database.base import Base, TimestampMixin
from app.utils.enums import UserRole

if TYPE_CHECKING:
    from app.models.department import Department
    from app.models.staff import Staff
    from app.models.complaint import Complaint
    from app.models.booking import Booking
    from app.models.notification import Notification
    from app.models.activity_log import ActivityLog
    from app.models.permission import UserPermissionOverride
    from app.models.purchase import PurchaseRequest, PurchaseApproval

class User(Base, TimestampMixin):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    full_name: Mapped[str] = mapped_column(String(150), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[UserRole] = mapped_column(
        Enum(UserRole, native_enum=False, length=50),
        default=UserRole.STUDENT_FACULTY,
        nullable=False
    )
    department_id: Mapped[Optional[int]] = mapped_column(ForeignKey("departments.id", ondelete="SET NULL"), nullable=True, index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_primary_admin: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # Relationships
    department: Mapped[Optional["Department"]] = relationship("Department", back_populates="users")
    staff_profile: Mapped[Optional["Staff"]] = relationship("Staff", back_populates="user", uselist=False, cascade="all, delete-orphan")
    complaints: Mapped[List["Complaint"]] = relationship("Complaint", back_populates="submitter")
    bookings: Mapped[List["Booking"]] = relationship("Booking", back_populates="user")
    notifications: Mapped[List["Notification"]] = relationship("Notification", back_populates="user", cascade="all, delete-orphan")
    activity_logs: Mapped[List["ActivityLog"]] = relationship("ActivityLog", back_populates="user")
    permission_overrides: Mapped[List["UserPermissionOverride"]] = relationship("UserPermissionOverride", back_populates="user", cascade="all, delete-orphan")
    purchase_requests: Mapped[List["PurchaseRequest"]] = relationship("PurchaseRequest", foreign_keys="[PurchaseRequest.requester_id]", back_populates="requester")
    purchase_approvals: Mapped[List["PurchaseApproval"]] = relationship("PurchaseApproval", foreign_keys="[PurchaseApproval.approver_id]", back_populates="approver")
