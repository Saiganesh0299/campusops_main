from datetime import datetime
from typing import List, Optional, TYPE_CHECKING
from sqlalchemy import String, Integer, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database.base import Base

if TYPE_CHECKING:
    from app.models.building import Building
    from app.models.asset import Asset
    from app.models.complaint import Complaint
    from app.models.booking import Booking

class Room(Base):
    __tablename__ = "rooms"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    room_number: Mapped[str] = mapped_column(String(50), index=True, nullable=False)
    building_id: Mapped[int] = mapped_column(ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False, index=True)
    floor_number: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    room_name: Mapped[str] = mapped_column(String(150), nullable=False)
    room_type: Mapped[str] = mapped_column(String(100), default="Classroom", nullable=False)
    capacity: Mapped[int] = mapped_column(Integer, default=30, nullable=False)
    availability_status: Mapped[str] = mapped_column(String(50), default="available", nullable=False)

    # Relationships
    building: Mapped["Building"] = relationship("Building", back_populates="rooms")
    assets: Mapped[List["Asset"]] = relationship("Asset", back_populates="room")
    complaints: Mapped[List["Complaint"]] = relationship("Complaint", back_populates="room")
    bookings: Mapped[List["Booking"]] = relationship("Booking", back_populates="room")
