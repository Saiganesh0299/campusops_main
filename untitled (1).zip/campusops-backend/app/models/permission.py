from datetime import datetime
from typing import Optional, TYPE_CHECKING
from sqlalchemy import String, Integer, Boolean, ForeignKey, Enum, UniqueConstraint, func, DateTime
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database.base import Base
from app.utils.enums import UserRole, AccessScope

if TYPE_CHECKING:
    from app.models.user import User

class Permission(Base):
    __tablename__ = "permissions"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    module: Mapped[str] = mapped_column(String(100), index=True, nullable=False)  # e.g., COMPLAINTS, WORK_ORDERS, PURCHASES, USERS
    action: Mapped[str] = mapped_column(String(50), index=True, nullable=False)   # e.g., READ, CREATE, UPDATE, DELETE, ASSIGN, APPROVE
    default_scope: Mapped[AccessScope] = mapped_column(
        Enum(AccessScope, native_enum=False, length=50),
        default=AccessScope.OWN,
        nullable=False
    )
    description: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    __table_args__ = (
        UniqueConstraint("module", "action", name="uq_module_action"),
    )

class RolePermission(Base):
    __tablename__ = "role_permissions"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    role: Mapped[UserRole] = mapped_column(
        Enum(UserRole, native_enum=False, length=50),
        index=True,
        nullable=False
    )
    permission_id: Mapped[int] = mapped_column(ForeignKey("permissions.id", ondelete="CASCADE"), nullable=False)
    scope: Mapped[AccessScope] = mapped_column(
        Enum(AccessScope, native_enum=False, length=50),
        default=AccessScope.OWN,
        nullable=False
    )
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    permission: Mapped["Permission"] = relationship("Permission")

    __table_args__ = (
        UniqueConstraint("role", "permission_id", name="uq_role_permission"),
    )

class UserPermissionOverride(Base):
    __tablename__ = "user_permission_overrides"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)
    permission_id: Mapped[int] = mapped_column(ForeignKey("permissions.id", ondelete="CASCADE"), nullable=False)
    scope: Mapped[AccessScope] = mapped_column(
        Enum(AccessScope, native_enum=False, length=50),
        default=AccessScope.DEPARTMENT,
        nullable=False
    )
    is_granted: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    granted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    user: Mapped["User"] = relationship("User", back_populates="permission_overrides")
    permission: Mapped["Permission"] = relationship("Permission")

    __table_args__ = (
        UniqueConstraint("user_id", "permission_id", name="uq_user_permission"),
    )
