from typing import List, Optional, TYPE_CHECKING
from sqlalchemy import String, Integer, Text, CheckConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database.base import Base

if TYPE_CHECKING:
    from app.models.reservation import InventoryReservation

class Inventory(Base):
    __tablename__ = "inventory"
    __table_args__ = (
        CheckConstraint("total_quantity >= 0", name="chk_inv_total_non_negative"),
        CheckConstraint("available_quantity >= 0", name="chk_inv_avail_non_negative"),
        CheckConstraint("reserved_quantity >= 0", name="chk_inv_reserved_non_negative"),
    )

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    item_code: Mapped[str] = mapped_column(String(50), unique=True, index=True, nullable=False)
    item_name: Mapped[str] = mapped_column(String(150), index=True, nullable=False)
    category: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    total_quantity: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    available_quantity: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    reserved_quantity: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    minimum_stock_level: Mapped[int] = mapped_column(Integer, default=5, nullable=False)
    storage_location: Mapped[str] = mapped_column(String(150), nullable=False)

    # Relationships
    reservations: Mapped[List["InventoryReservation"]] = relationship("InventoryReservation", back_populates="inventory_item", cascade="all, delete-orphan")
