from typing import List, Optional, TYPE_CHECKING
from sqlalchemy import String, Integer, Text, Float, ForeignKey, Enum
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database.base import Base, TimestampMixin
from app.utils.enums import ComplaintCategory, PriorityLevel, ComplaintStatus, ComplaintSource

if TYPE_CHECKING:
    from app.models.user import User
    from app.models.building import Building
    from app.models.room import Room
    from app.models.asset import Asset
    from app.models.work_order import WorkOrder
    from app.models.incident import Incident

class Complaint(Base, TimestampMixin):
    __tablename__ = "complaints"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    complaint_code: Mapped[str] = mapped_column(String(50), unique=True, index=True, nullable=False)
    submitted_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    building_id: Mapped[int] = mapped_column(ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False, index=True)
    room_id: Mapped[Optional[int]] = mapped_column(ForeignKey("rooms.id", ondelete="SET NULL"), nullable=True, index=True)
    asset_id: Mapped[Optional[int]] = mapped_column(ForeignKey("assets.id", ondelete="SET NULL"), nullable=True, index=True)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    category: Mapped[ComplaintCategory] = mapped_column(
        Enum(ComplaintCategory, native_enum=False, length=50),
        default=ComplaintCategory.OTHER,
        nullable=False
    )
    priority: Mapped[PriorityLevel] = mapped_column(
        Enum(PriorityLevel, native_enum=False, length=50),
        default=PriorityLevel.MEDIUM,
        nullable=False
    )
    status: Mapped[ComplaintStatus] = mapped_column(
        Enum(ComplaintStatus, native_enum=False, length=50),
        default=ComplaintStatus.SUBMITTED,
        nullable=False
    )
    source: Mapped[ComplaintSource] = mapped_column(
        Enum(ComplaintSource, native_enum=False, length=50),
        default=ComplaintSource.FORM,
        nullable=False
    )
    ai_summary: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    ai_confidence: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    missing_information: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Relationships
    submitter: Mapped[Optional["User"]] = relationship("User", back_populates="complaints")
    building: Mapped["Building"] = relationship("Building", back_populates="complaints")
    room: Mapped[Optional["Room"]] = relationship("Room", back_populates="complaints")
    asset: Mapped[Optional["Asset"]] = relationship("Asset", back_populates="complaints")
    work_orders: Mapped[List["WorkOrder"]] = relationship("WorkOrder", back_populates="complaint", cascade="all, delete-orphan")
    incidents: Mapped[List["Incident"]] = relationship(
        "Incident",
        secondary="incident_complaints",
        back_populates="complaints"
    )
