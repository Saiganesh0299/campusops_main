from typing import List, Optional, TYPE_CHECKING
from sqlalchemy import String, Integer, Boolean, ForeignKey, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database.base import Base

if TYPE_CHECKING:
    from app.models.user import User
    from app.models.work_order import WorkOrder

class Staff(Base):
    __tablename__ = "staff"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    employee_code: Mapped[str] = mapped_column(String(50), unique=True, index=True, nullable=False)
    department: Mapped[str] = mapped_column(String(100), nullable=False)
    skills: Mapped[Optional[dict]] = mapped_column(JSON, default=list, nullable=True)
    shift_start: Mapped[str] = mapped_column(String(10), default="08:00", nullable=False)
    shift_end: Mapped[str] = mapped_column(String(10), default="17:00", nullable=False)
    is_available: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    current_workload: Mapped[int] = mapped_column(Integer, default=0, nullable=False)

    # Relationships
    user: Mapped["User"] = relationship("User", back_populates="staff_profile")
    work_orders: Mapped[List["WorkOrder"]] = relationship("WorkOrder", back_populates="assigned_staff")
