from datetime import date
from typing import List, Optional, TYPE_CHECKING
from sqlalchemy import String, Integer, Date, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database.base import Base

if TYPE_CHECKING:
    from app.models.building import Building
    from app.models.room import Room
    from app.models.complaint import Complaint

class Asset(Base):
    __tablename__ = "assets"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    asset_code: Mapped[str] = mapped_column(String(50), unique=True, index=True, nullable=False)
    asset_name: Mapped[str] = mapped_column(String(150), nullable=False)
    category: Mapped[str] = mapped_column(String(100), nullable=False)
    building_id: Mapped[int] = mapped_column(ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False, index=True)
    room_id: Mapped[Optional[int]] = mapped_column(ForeignKey("rooms.id", ondelete="SET NULL"), nullable=True, index=True)
    condition: Mapped[str] = mapped_column(String(50), default="GOOD", nullable=False)
    status: Mapped[str] = mapped_column(String(50), default="OPERATIONAL", nullable=False)
    purchase_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    last_maintenance_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)

    # Relationships
    building: Mapped["Building"] = relationship("Building", back_populates="assets")
    room: Mapped[Optional["Room"]] = relationship("Room", back_populates="assets")
    complaints: Mapped[List["Complaint"]] = relationship("Complaint", back_populates="asset")
