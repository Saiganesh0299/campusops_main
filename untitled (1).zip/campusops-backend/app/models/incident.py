from typing import List, Optional, TYPE_CHECKING
from sqlalchemy import Table, Column, Integer, String, Text, ForeignKey, Enum, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database.base import Base, TimestampMixin
from app.utils.enums import PriorityLevel, IncidentStatus

if TYPE_CHECKING:
    from app.models.complaint import Complaint

# Association table between incidents and complaints
incident_complaints = Table(
    "incident_complaints",
    Base.metadata,
    Column("incident_id", Integer, ForeignKey("incidents.id", ondelete="CASCADE"), primary_key=True),
    Column("complaint_id", Integer, ForeignKey("complaints.id", ondelete="CASCADE"), primary_key=True)
)

class Incident(Base, TimestampMixin):
    __tablename__ = "incidents"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    incident_code: Mapped[str] = mapped_column(String(50), unique=True, index=True, nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    category: Mapped[str] = mapped_column(String(100), nullable=False)
    priority: Mapped[PriorityLevel] = mapped_column(
        Enum(PriorityLevel, native_enum=False, length=50),
        default=PriorityLevel.MEDIUM,
        nullable=False
    )
    status: Mapped[IncidentStatus] = mapped_column(
        Enum(IncidentStatus, native_enum=False, length=50),
        default=IncidentStatus.INVESTIGATING,
        nullable=False
    )
    affected_locations: Mapped[Optional[dict]] = mapped_column(JSON, default=list, nullable=True)

    # Relationships
    complaints: Mapped[List["Complaint"]] = relationship(
        "Complaint",
        secondary=incident_complaints,
        back_populates="incidents"
    )
