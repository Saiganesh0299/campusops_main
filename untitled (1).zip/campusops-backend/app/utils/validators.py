import re
from typing import Optional

def validate_building_code(code: str) -> bool:
    """Checks format e.g. OAB, CS-101, BLDG-A"""
    return bool(re.match(r"^[A-Z0-9_\-]{2,20}$", code.upper()))

def validate_time_format(time_str: str) -> bool:
    """Validates HH:MM format (24 hour)"""
    return bool(re.match(r"^([01]\d|2[0-3]):([0-5]\d)$", time_str))
