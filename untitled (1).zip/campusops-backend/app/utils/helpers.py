from datetime import datetime, timezone

def generate_timestamp_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def sanitize_string(val: str, max_length: int = 500) -> str:
    if not val:
        return ""
    clean = val.strip()
    return clean[:max_length]
