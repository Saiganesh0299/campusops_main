from sqlalchemy import create_engine
from app.core.config import settings

# Engine configuration for MySQL 8.x with PyMySQL
# SQLite fallback for test suites or when testing in memory
db_url = settings.resolved_database_url

connect_args = {}
if "sqlite" in db_url:
    connect_args = {"check_same_thread": False}
    engine = create_engine(
        db_url,
        connect_args=connect_args,
        echo=settings.DEBUG
    )
else:
    engine = create_engine(
        db_url,
        pool_pre_ping=True,
        pool_recycle=3600,
        pool_size=10,
        max_overflow=20,
        echo=settings.DEBUG
    )
