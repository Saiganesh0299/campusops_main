from typing import Any, List, Optional
from fastapi import HTTPException, status

class CampusOpsException(HTTPException):
    def __init__(
        self,
        status_code: int = status.HTTP_400_BAD_REQUEST,
        message: str = "An error occurred",
        errors: Optional[List[Any]] = None
    ):
        self.message = message
        self.errors = errors or []
        super().__init__(status_code=status_code, detail=message)

class NotFoundException(CampusOpsException):
    def __init__(self, message: str = "Resource not found"):
        super().__init__(status_code=status.HTTP_404_NOT_FOUND, message=message)

class ConflictException(CampusOpsException):
    def __init__(self, message: str = "Resource conflict detected", errors: Optional[List[Any]] = None):
        super().__init__(status_code=status.HTTP_409_CONFLICT, message=message, errors=errors)

class UnauthorizedException(CampusOpsException):
    def __init__(self, message: str = "Could not validate credentials"):
        super().__init__(status_code=status.HTTP_401_UNAUTHORIZED, message=message)

class ForbiddenException(CampusOpsException):
    def __init__(self, message: str = "Operation not permitted for your role"):
        super().__init__(status_code=status.HTTP_403_FORBIDDEN, message=message)

class ValidationException(CampusOpsException):
    def __init__(self, message: str = "Validation failed", errors: Optional[List[Any]] = None):
        super().__init__(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, message=message, errors=errors)
