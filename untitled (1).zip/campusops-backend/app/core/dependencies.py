from typing import List, Optional, Callable
from fastapi import Depends, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from app.core.exceptions import UnauthorizedException, ForbiddenException
from app.core.security import decode_access_token
from app.database.session import get_db
from app.models.user import User
from app.utils.enums import UserRole, AccessScope
from app.services.permission_service import permission_service

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login", auto_error=False)

def get_current_user(
    token: Optional[str] = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> User:
    if not token:
        raise UnauthorizedException("Authentication token is missing. Please sign in.")

    payload = decode_access_token(token)
    if not payload:
        raise UnauthorizedException("Invalid or expired authentication token")

    user_id: Optional[str] = payload.get("sub")
    if not user_id:
        raise UnauthorizedException("Token payload missing user identifier")

    try:
        uid = int(user_id)
    except ValueError:
        raise UnauthorizedException("Invalid user identifier in token")

    user = db.query(User).filter(User.id == uid).first()
    if not user:
        raise UnauthorizedException("User associated with this token no longer exists")

    if not user.is_active:
        raise ForbiddenException("Your account has been deactivated. Please contact the System Administrator.")

    return user

def get_current_active_user(
    current_user: User = Depends(get_current_user)
) -> User:
    if not current_user.is_active:
        raise ForbiddenException("User account is inactive")
    return current_user

def require_role(*allowed_roles: UserRole):
    def role_checker(current_user: User = Depends(get_current_user)) -> User:
        if current_user.role == UserRole.SYSTEM_ADMIN:
            return current_user
        if current_user.role not in allowed_roles:
            raise ForbiddenException(
                f"Access denied. Requires one of roles: {[r.value for r in allowed_roles]}. Current role: {current_user.role.value}"
            )
        return current_user
    return role_checker

def require_permission(module: str, action: str):
    """
    Dependency that enforces permission and attaches the granted scope to the user context.
    """
    def permission_checker(
        current_user: User = Depends(get_current_user),
        db: Session = Depends(get_db)
    ) -> User:
        authorized, scope = permission_service.user_has_permission(
            db=db,
            user=current_user,
            module=module,
            action=action
        )
        if not authorized:
            raise ForbiddenException(
                f"Permission denied: Missing '{action}' permission on module '{module}' for role '{current_user.role.value}'"
            )
        # Store resolved scope on user object for router filtering
        setattr(current_user, "_current_scope", scope)
        return current_user
    return permission_checker
