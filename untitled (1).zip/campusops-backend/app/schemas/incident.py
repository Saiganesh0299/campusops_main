from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field
from app.utils.enums import PriorityLevel, IncidentStatus

class IncidentBase(BaseModel):
    title: str = Field(..., min_length=3, max_length=200)
    description: str = Field(..., min_length=5)
    category: str = Field(..., min_length=2, max_length=100)
    priority: PriorityLevel = PriorityLevel.MEDIUM
    status: IncidentStatus = IncidentStatus.INVESTIGATING
    affected_locations: List[str] = Field(default_factory=list)

class IncidentCreate(IncidentBase):
    complaint_ids: Optional[List[int]] = Field(default_factory=list)

class IncidentUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    priority: Optional[PriorityLevel] = None
    status: Optional[IncidentStatus] = None
    affected_locations: Optional[List[str]] = None

class IncidentResponse(IncidentBase):
    id: int
    incident_code: str
    complaint_ids: List[int] = Field(default_factory=list)
    complaints_count: int = 0
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class IncidentCorrelateRequest(BaseModel):
    building_id: Optional[int] = None
    category: Optional[str] = None
    timeframe_hours: int = Field(default=48, ge=1, le=168)

class CorrelatedGroup(BaseModel):
    group_title: str
    category: str
    priority: PriorityLevel
    common_cause_hypothesis: str
    affected_locations: List[str]
    complaint_ids: List[int]
    confidence: float

class IncidentCorrelateResponse(BaseModel):
    total_analyzed: int
    correlated_incidents_found: int
    recommended_groups: List[CorrelatedGroup]
