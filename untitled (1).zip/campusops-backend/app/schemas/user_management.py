from datetime import datetime
from typing import Optional, List, Dict
from pydantic import BaseModel, EmailStr, Field
from app.utils.enums import UserRole, AccessScope

class AdminCreateUserRequest(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=150)
    email: EmailStr
    password: str = Field(..., min_length=6, max_length=100)
    role: UserRole = UserRole.STUDENT_FACULTY
    department_id: Optional[int] = None
    is_active: bool = True

class AdminUpdateUserRequest(BaseModel):
    full_name: Optional[str] = None
    role: Optional[UserRole] = None
    department_id: Optional[int] = None
    is_active: Optional[bool] = None

class AdminChangeRoleRequest(BaseModel):
    role: UserRole

class AdminAssignDepartmentRequest(BaseModel):
    department_id: Optional[int] = None

class AdminResetPasswordRequest(BaseModel):
    new_password: str = Field(..., min_length=6, max_length=100)

class PermissionOverrideRequest(BaseModel):
    module: str
    action: str
    scope: AccessScope = AccessScope.DEPARTMENT
    is_granted: bool = True

class PermissionItemResponse(BaseModel):
    module: str
    action: str
    scope: AccessScope
    is_granted: bool

class UserDetailResponse(BaseModel):
    id: int
    full_name: str
    email: str
    role: UserRole
    department_id: Optional[int] = None
    department_name: Optional[str] = None
    is_active: bool
    is_primary_admin: bool
    created_at: datetime
    updated_at: datetime
    permissions: List[PermissionItemResponse] = Field(default_factory=list)

    class Config:
        from_attributes = True

class UserManagementSummary(BaseModel):
    total_users: int
    active_users: int
    inactive_users: int
    users_by_role: Dict[str, int]
    users_by_department: Dict[str, int]
