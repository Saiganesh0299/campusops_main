from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field
from app.utils.enums import InventoryReservationStatus

class InventoryBase(BaseModel):
    item_code: str = Field(..., min_length=2, max_length=50)
    item_name: str = Field(..., min_length=2, max_length=150)
    category: str = Field(..., min_length=2, max_length=100)
    description: Optional[str] = None
    total_quantity: int = Field(default=0, ge=0)
    available_quantity: int = Field(default=0, ge=0)
    reserved_quantity: int = Field(default=0, ge=0)
    minimum_stock_level: int = Field(default=5, ge=0)
    storage_location: str = Field(..., min_length=2, max_length=150)

class InventoryCreate(InventoryBase):
    pass

class InventoryUpdate(BaseModel):
    item_name: Optional[str] = None
    category: Optional[str] = None
    description: Optional[str] = None
    minimum_stock_level: Optional[int] = Field(default=None, ge=0)
    storage_location: Optional[str] = None

class InventoryRestockRequest(BaseModel):
    quantity: int = Field(..., gt=0)
    notes: Optional[str] = None

class PartReservationRequest(BaseModel):
    inventory_id: int
    quantity: int = Field(..., gt=0)
    notes: Optional[str] = None

class ReservationResponse(BaseModel):
    id: int
    inventory_id: int
    item_code: str
    item_name: str
    work_order_id: int
    quantity: int
    status: InventoryReservationStatus
    reserved_at: datetime
    released_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class InventoryResponse(InventoryBase):
    id: int
    is_low_stock: bool = False
    active_reservations_count: int = 0

    class Config:
        from_attributes = True
