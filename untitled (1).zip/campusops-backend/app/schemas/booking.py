from datetime import date, time, datetime
from typing import Optional, List
from pydantic import BaseModel, Field
from app.utils.enums import BookingStatus

class BookingCreate(BaseModel):
    room_id: int
    purpose: str = Field(..., min_length=3, max_length=500)
    booking_date: date
    start_time: str = Field(..., pattern=r"^\d{2}:\d{2}(:\d{2})?$")
    end_time: str = Field(..., pattern=r"^\d{2}:\d{2}(:\d{2})?$")
    attendees_count: Optional[int] = Field(default=1, ge=1)

class BookingUpdate(BaseModel):
    purpose: Optional[str] = None
    booking_date: Optional[date] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    status: Optional[BookingStatus] = None

class BookingResponse(BaseModel):
    id: int
    booking_code: str
    room_id: int
    room_number: Optional[str] = None
    room_name: Optional[str] = None
    building_name: Optional[str] = None
    requested_by: int
    requester_name: Optional[str] = None
    purpose: str
    booking_date: date
    start_time: str
    end_time: str
    status: BookingStatus
    created_at: datetime

    class Config:
        from_attributes = True

class AlternativeRoomOption(BaseModel):
    room_id: int
    room_number: str
    room_name: str
    building_name: str
    capacity: int
    available_slot: str
    reason: str

class AlternativeBookingsResponse(BaseModel):
    original_room_id: int
    original_date: date
    original_time_slot: str
    conflict_detected: bool
    conflict_reason: Optional[str] = None
    alternative_rooms: List[AlternativeRoomOption]
    alternative_slots_in_same_room: List[str]
