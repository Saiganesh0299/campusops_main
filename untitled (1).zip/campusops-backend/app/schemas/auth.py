from datetime import datetime
from typing import Optional, List, Dict
from pydantic import BaseModel, EmailStr, Field
from app.utils.enums import UserRole, AccessScope

class UserRegister(BaseModel):
    full_name: str = Field(..., min_length=2, max_length=150)
    email: EmailStr
    password: str = Field(..., min_length=6, max_length=100)
    role: UserRole = UserRole.STUDENT_FACULTY
    department_id: Optional[int] = None

class UserLogin(BaseModel):
    email: EmailStr
    password: str
    captcha_token: Optional[str] = None

class GoogleLoginRequest(BaseModel):
    credential: Optional[str] = None
    email: EmailStr
    name: Optional[str] = None
    captcha_token: Optional[str] = None

class CaptchaVerifyRequest(BaseModel):
    captcha_token: str
    solution: Optional[str] = None

class CaptchaVerifyResponse(BaseModel):
    verified: bool
    captcha_session: str

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    user_id: int
    email: str
    full_name: str
    role: UserRole
    department_id: Optional[int] = None
    department_name: Optional[str] = None
    is_primary_admin: bool = False

class RefreshTokenRequest(BaseModel):
    refresh_token: str

class UserResponse(BaseModel):
    id: int
    full_name: str
    email: str
    role: UserRole
    department_id: Optional[int] = None
    department_name: Optional[str] = None
    is_active: bool
    is_primary_admin: bool = False
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class UserPermissionItem(BaseModel):
    module: str
    action: str
    scope: AccessScope

class UserPermissionSummary(BaseModel):
    user_id: int
    role: UserRole
    department_id: Optional[int] = None
    department_name: Optional[str] = None
    is_primary_admin: bool
    permissions: List[UserPermissionItem]
