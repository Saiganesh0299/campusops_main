from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field
from app.utils.enums import PriorityLevel, WorkOrderStatus

class WorkOrderCreate(BaseModel):
    complaint_id: int
    assigned_staff_id: Optional[int] = None
    description: str = Field(..., min_length=5)
    priority: PriorityLevel = PriorityLevel.MEDIUM
    status: WorkOrderStatus = WorkOrderStatus.NEW
    estimated_completion: Optional[datetime] = None

class WorkOrderUpdate(BaseModel):
    assigned_staff_id: Optional[int] = None
    description: Optional[str] = None
    priority: Optional[PriorityLevel] = None
    estimated_completion: Optional[datetime] = None

class WorkOrderStatusUpdate(BaseModel):
    status: WorkOrderStatus
    resolution_notes: Optional[str] = None
    actual_completion: Optional[datetime] = None

class WorkOrderAssignRequest(BaseModel):
    staff_id: int
    notes: Optional[str] = None

class WorkOrderReassignRequest(BaseModel):
    new_staff_id: int
    reassignment_reason: str

class WorkOrderResponse(BaseModel):
    id: int
    work_order_code: str
    complaint_id: int
    complaint_code: Optional[str] = None
    building_name: Optional[str] = None
    room_number: Optional[str] = None
    assigned_staff_id: Optional[int] = None
    assigned_staff_name: Optional[str] = None
    description: str
    priority: PriorityLevel
    status: WorkOrderStatus
    estimated_completion: Optional[datetime] = None
    actual_completion: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    reserved_parts_count: int = 0

    class Config:
        from_attributes = True

class WorkOrderHistoryItem(BaseModel):
    id: int
    action: str
    description: str
    user_name: Optional[str] = None
    created_at: datetime
