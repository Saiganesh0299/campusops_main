from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field

class BuildingBase(BaseModel):
    building_code: str = Field(..., min_length=2, max_length=50)
    building_name: str = Field(..., min_length=2, max_length=150)
    description: Optional[str] = None
    total_floors: int = Field(default=1, ge=1, le=50)

class BuildingCreate(BuildingBase):
    pass

class BuildingUpdate(BaseModel):
    building_code: Optional[str] = None
    building_name: Optional[str] = None
    description: Optional[str] = None
    total_floors: Optional[int] = Field(default=None, ge=1, le=50)

class BuildingResponse(BuildingBase):
    id: int
    created_at: datetime
    rooms_count: Optional[int] = 0

    class Config:
        from_attributes = True
