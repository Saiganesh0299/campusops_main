from typing import Any, Generic, List, Optional, TypeVar
from pydantic import BaseModel

T = TypeVar("T")

class BaseResponse(BaseModel):
    success: bool = True
    message: str = "Operation completed successfully"
    errors: Optional[List[Any]] = None

class DataResponse(BaseResponse, Generic[T]):
    data: Optional[T] = None

class PaginatedData(BaseModel, Generic[T]):
    items: List[T]
    total: int
    page: int
    page_size: int
    total_pages: int
