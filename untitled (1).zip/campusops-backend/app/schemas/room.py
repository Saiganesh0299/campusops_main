from typing import Optional, List
from pydantic import BaseModel, Field

class RoomBase(BaseModel):
    room_number: str = Field(..., min_length=1, max_length=50)
    building_id: int
    floor_number: int = Field(default=0, ge=0)
    room_name: str = Field(..., min_length=2, max_length=150)
    room_type: str = Field(default="Classroom", max_length=100)
    capacity: int = Field(default=30, ge=1)
    availability_status: str = Field(default="available", max_length=50)

class RoomCreate(RoomBase):
    pass

class RoomUpdate(BaseModel):
    room_number: Optional[str] = None
    building_id: Optional[int] = None
    floor_number: Optional[int] = None
    room_name: Optional[str] = None
    room_type: Optional[str] = None
    capacity: Optional[int] = None
    availability_status: Optional[str] = None

class RoomResponse(RoomBase):
    id: int
    building_name: Optional[str] = None

    class Config:
        from_attributes = True

class RoomAvailabilityResponse(BaseModel):
    room_id: int
    room_number: str
    room_name: str
    is_available: bool
    status: str
    existing_bookings_count: int
    reason: Optional[str] = None
