from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field
from app.utils.enums import PurchaseStatus

class PurchaseRequestCreate(BaseModel):
    item_name: str = Field(..., min_length=2, max_length=150)
    category: str = Field(default="Equipment", max_length=100)
    quantity: int = Field(default=1, ge=1)
    estimated_unit_cost: float = Field(default=0.0, ge=0.0)
    department_id: Optional[int] = None
    work_order_id: Optional[int] = None
    justification: str = Field(..., min_length=5)

class PurchaseApprovalAction(BaseModel):
    comments: Optional[str] = None

class PurchaseApprovalHistoryItem(BaseModel):
    id: int
    approver_id: int
    approver_name: str
    approver_role: str
    action: str
    comments: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True

class PurchaseRequestResponse(BaseModel):
    id: int
    request_code: str
    requester_id: int
    requester_name: str
    requester_role: str
    department_id: Optional[int] = None
    department_name: Optional[str] = None
    work_order_id: Optional[int] = None
    work_order_code: Optional[str] = None
    item_name: str
    category: str
    quantity: int
    estimated_unit_cost: float
    total_estimated_cost: float
    justification: str
    status: PurchaseStatus
    created_at: datetime
    updated_at: datetime
    approvals: List[PurchaseApprovalHistoryItem] = Field(default_factory=list)

    class Config:
        from_attributes = True
