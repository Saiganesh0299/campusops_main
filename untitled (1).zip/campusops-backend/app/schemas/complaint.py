from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field, EmailStr
from app.utils.enums import ComplaintCategory, PriorityLevel, ComplaintStatus, ComplaintSource

class ComplaintCreate(BaseModel):
    description: str = Field(..., min_length=5)
    building_id: int
    room_id: Optional[int] = None
    asset_id: Optional[int] = None
    source: ComplaintSource = ComplaintSource.FORM
    category: Optional[ComplaintCategory] = None
    priority: Optional[PriorityLevel] = None

class EmailIngestRequest(BaseModel):
    sender_email: EmailStr
    sender_name: Optional[str] = "Campus Member"
    subject: str = Field(..., min_length=2)
    body: str = Field(..., min_length=5)
    building_code_or_name: Optional[str] = None
    room_number: Optional[str] = None

class ComplaintUpdate(BaseModel):
    description: Optional[str] = None
    category: Optional[ComplaintCategory] = None
    priority: Optional[PriorityLevel] = None
    status: Optional[ComplaintStatus] = None
    room_id: Optional[int] = None
    asset_id: Optional[int] = None
    missing_information: Optional[str] = None

class DuplicateComplaintCandidate(BaseModel):
    complaint_id: int
    complaint_code: str
    description: str
    status: ComplaintStatus
    similarity_score: float
    reason: str

class ComplaintResponse(BaseModel):
    id: int
    complaint_code: str
    submitted_by: Optional[int] = None
    submitter_name: Optional[str] = None
    building_id: int
    building_name: Optional[str] = None
    room_id: Optional[int] = None
    room_number: Optional[str] = None
    asset_id: Optional[int] = None
    asset_name: Optional[str] = None
    description: str
    category: ComplaintCategory
    priority: PriorityLevel
    status: ComplaintStatus
    source: ComplaintSource
    ai_summary: Optional[str] = None
    ai_confidence: Optional[float] = None
    missing_information: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    duplicate_candidates: Optional[List[DuplicateComplaintCandidate]] = None

    class Config:
        from_attributes = True

class ComplaintClarificationResponse(BaseModel):
    complaint_id: int
    complaint_code: str
    status: ComplaintStatus
    missing_fields: List[str]
    clarification_question: str
    preliminary_category: ComplaintCategory
    preliminary_priority: PriorityLevel
