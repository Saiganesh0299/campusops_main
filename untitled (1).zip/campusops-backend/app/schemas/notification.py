from datetime import datetime
from typing import Optional
from pydantic import BaseModel
from app.utils.enums import NotificationType

class NotificationResponse(BaseModel):
    id: int
    user_id: int
    title: str
    message: str
    notification_type: NotificationType
    is_read: bool
    created_at: datetime

    class Config:
        from_attributes = True

class ActivityLogResponse(BaseModel):
    id: int
    user_id: Optional[int] = None
    user_name: Optional[str] = None
    action: str
    entity_type: str
    entity_id: str
    description: str
    created_at: datetime

    class Config:
        from_attributes = True
