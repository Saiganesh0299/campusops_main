from typing import Dict, List, Optional
from pydantic import BaseModel

class DashboardSummaryResponse(BaseModel):
    total_complaints: int
    open_complaints: int
    critical_incidents: int
    work_orders_in_progress: int
    resolved_work_orders: int
    available_staff: int
    total_staff: int
    staff_workload_avg: float
    booking_conflicts: int
    inventory_shortages: int
    average_resolution_time_hours: float
    facility_efficiency_rate: float

class ComplaintsAnalyticsItem(BaseModel):
    category: str
    count: int
    open_count: int
    resolved_count: int

class ComplaintsAnalytics(BaseModel):
    by_category: List[ComplaintsAnalyticsItem]
    by_priority: Dict[str, int]
    by_status: Dict[str, int]
    by_building: Dict[str, int]

class WorkOrdersAnalytics(BaseModel):
    by_status: Dict[str, int]
    by_priority: Dict[str, int]
    average_duration_hours: float
    overdue_count: int

class StaffWorkloadItem(BaseModel):
    staff_id: int
    name: str
    department: str
    assigned_work_orders: int
    is_available: bool
    shift: str

class InventoryAlertItem(BaseModel):
    id: int
    item_code: str
    item_name: str
    available_quantity: int
    minimum_stock_level: int
    deficit: int
    storage_location: str
