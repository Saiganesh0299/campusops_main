from typing import List, Optional
from pydantic import BaseModel, Field

class StaffBase(BaseModel):
    user_id: int
    employee_code: str = Field(..., min_length=2, max_length=50)
    department: str = Field(..., min_length=2, max_length=100)
    skills: List[str] = Field(default_factory=list)
    shift_start: str = Field(default="08:00", pattern=r"^\d{2}:\d{2}$")
    shift_end: str = Field(default="17:00", pattern=r"^\d{2}:\d{2}$")
    is_available: bool = True
    current_workload: int = 0

class StaffCreate(StaffBase):
    pass

class StaffUpdate(BaseModel):
    department: Optional[str] = None
    skills: Optional[List[str]] = None
    shift_start: Optional[str] = None
    shift_end: Optional[str] = None
    is_available: Optional[bool] = None
    current_workload: Optional[int] = None

class StaffResponse(StaffBase):
    id: int
    full_name: Optional[str] = None
    email: Optional[str] = None

    class Config:
        from_attributes = True

class StaffRecommendationResponse(BaseModel):
    staff_id: int
    employee_code: str
    name: str
    department: str
    skills: List[str]
    current_workload: int
    is_available: bool
    shift: str
    score: float
    recommendation_reason: str
